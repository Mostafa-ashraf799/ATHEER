package com.binarybeast.chatapp.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.binarybeast.chatapp.call.CallManager
import com.binarybeast.chatapp.call.CallState
import com.binarybeast.chatapp.data.AppSettings
import com.binarybeast.chatapp.data.AuthRepository
import com.binarybeast.chatapp.data.ChatEngine
import com.binarybeast.chatapp.data.Profile
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.status.SessionStatus
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

private enum class Tab(val label: String) { Chats("الشات"), Stories("الستوريز"), Channels("القنوات"), Calls("المكالمات"), Profile("حسابي") }

/** حالة التنقل العامة: بتفضل عايشة حتى لو الشاشة اتشالت من الـComposition (مثلًا وإحنا في اختيار ملف). */
object NavStore {
    var tab by mutableStateOf(0)
    var peer by mutableStateOf<Profile?>(null)
    var channel by mutableStateOf<com.binarybeast.chatapp.data.Channel?>(null)
    /** شاشة البوتات (قايمة) / محادثة بوت مفتوحة */
    var botsOpen by mutableStateOf(false)
    var bot by mutableStateOf<com.binarybeast.chatapp.data.BotInfo?>(null)
    var url by mutableStateOf<String?>(null)
    /** اتسجل دخول قبل كده في العملية دي؟ بنستخدمها علشان حالات التحديث المؤقتة متطلّعش شاشة الدخول. */
    var authed by mutableStateOf(false)
    /** المساحة الخاصة مفتوحة؟ (بتتقفل لما التطبيق يتقفل/يترجع من الخلفية) */
    var spaceOpen by mutableStateOf(false)
    /** لينك دعوة جاي من برّه (atheer://…) مستني يتنفّذ بعد تسجيل الدخول */
    var pendingLink by mutableStateOf<String?>(null)
    /** المكالمة الواردة اتفتحت بشاشة كاملة (بدل البانر الصغير) */
    var callExpanded by mutableStateOf(false)
}

@Composable
fun AppRoot() {
    val status by AuthRepository.sessionStatus.collectAsState(initial = SessionStatus.Initializing)
    val ctx0 = LocalContext.current

    val ctxLink = LocalContext.current
    val linkScope = androidx.compose.runtime.rememberCoroutineScope()
    LaunchedEffect(NavStore.pendingLink, NavStore.authed) {
        val l = NavStore.pendingLink
        if (l != null && NavStore.authed) { NavStore.pendingLink = null; InviteHandler.open(ctxLink, l, linkScope) }
    }

    // المساحة الخاصة بتتقفل أول ما التطبيق يروح للخلفية
    val lifeOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifeOwner) {
        val ob = androidx.lifecycle.LifecycleEventObserver { _, e -> when (e) { androidx.lifecycle.Lifecycle.Event.ON_STOP -> { NavStore.spaceOpen = false; ChatEngine.visible = false }; androidx.lifecycle.Lifecycle.Event.ON_START -> { ChatEngine.visible = true; kotlinx.coroutines.GlobalScope.launch { runCatching { ChatEngine.drainMailbox() } } }; else -> {} } }
        lifeOwner.lifecycle.addObserver(ob)
        onDispose { lifeOwner.lifecycle.removeObserver(ob) }
    }

    // حفظ الجلسة (للتبديل بين الحسابات) كل ما تتجدّد
    LaunchedEffect(status) {
        if (status is SessionStatus.Authenticated) {
            val s = com.binarybeast.chatapp.data.Supa.client.auth.currentSessionOrNull()
            val uid = com.binarybeast.chatapp.data.AuthRepository.currentUserId
            if (s != null && uid != null && com.binarybeast.chatapp.data.Accounts.saveSession(uid, s.accessToken, s.refreshToken)) com.binarybeast.chatapp.data.Accounts.restart(ctx0)
        }
    }
    // بعد إعادة التشغيل على حساب محفوظ: استرجاع جلسته من غير شاشة دخول
    var restoreTried by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var restoring by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    LaunchedEffect(status) {
        if (status is SessionStatus.NotAuthenticated && !restoreTried) {
            restoreTried = true
            val a = com.binarybeast.chatapp.data.Accounts.activeSaved()
            if (a != null) {
                restoring = true
                runCatching { com.binarybeast.chatapp.data.Supa.client.auth.importAuthToken(a.access, a.refresh) }
                kotlinx.coroutines.delay(1500)
                restoring = false
            }
        }
    }

    LaunchedEffect(status) {
        when (status) {
            is SessionStatus.Authenticated -> NavStore.authed = true
            is SessionStatus.NotAuthenticated -> {
                NavStore.authed = false; NavStore.spaceOpen = false; NavStore.peer = null; NavStore.channel = null; NavStore.bot = null; NavStore.botsOpen = false; NavStore.url = null; NavStore.tab = 0
                com.binarybeast.chatapp.KeepAliveService.stop(ctx0); CallManager.stopListening(); ChatEngine.stop(); com.binarybeast.chatapp.data.ChannelRepository.stopListening()
            }
            else -> {}
        }
    }

    // الخروج لشاشة الدخول بس لما المستخدم يكون فعلًا مش مسجّل. حالات Initializing/RefreshFailure مبتشيلش التطبيق لو كان داخل.
    when {
        status is SessionStatus.Authenticated || NavStore.authed -> AuthedApp()
        restoring -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        status is SessionStatus.NotAuthenticated -> LoginScreen()
        status is SessionStatus.Initializing -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        else -> LoginScreen()
    }
}

@Composable
private fun AuthedApp() {
    val session: SessionVm = viewModel()
    val me by session.me.collectAsState()
    val callState by CallManager.state.collectAsState()
    val prefs by AppSettings.prefs.collectAsState()
    val ctx = LocalContext.current

    LaunchedEffect(Unit) {
        session.load()
        CallManager.startListening()
        ChatEngine.start()
        com.binarybeast.chatapp.data.ChannelRepository.startListening(ctx)
        CallManager.checkPending()
        if (prefs.keepAlive) com.binarybeast.chatapp.KeepAliveService.start(ctx)
        // تسجيل FCM token (بيتخطّى لو Firebase مش متفعّل)
        runCatching {
            if (com.google.firebase.FirebaseApp.getApps(ctx).isNotEmpty()) {
                com.google.firebase.messaging.FirebaseMessaging.getInstance().token
                    .addOnSuccessListener { t -> GlobalScope.launch { com.binarybeast.chatapp.data.Push.registerToken(t) } }
            }
        }
    }

    // أول دخول: لازم يختار يوزر نيم قبل ما يكمّل
    if (me != null && me!!.username.isNullOrBlank()) {
        UsernameScreen(defaultName = me!!.displayName, session = session)
        return
    }
    if (me == null) { Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }; return }

    // نسخة محفوظة في الـBundle (لو العملية اتقتلت) + الحالة العامة NavStore (لو الشاشة اتشالت بس)
    var savedPeer by rememberSavedJson(Profile.serializer())
    var savedChannel by rememberSavedJson(com.binarybeast.chatapp.data.Channel.serializer())
    var savedTab by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(0) }
    var savedUrl by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf<String?>(null) }
    androidx.compose.runtime.remember {
        if (NavStore.peer == null) NavStore.peer = savedPeer
        if (NavStore.channel == null) NavStore.channel = savedChannel
        if (NavStore.url == null) NavStore.url = savedUrl
        if (NavStore.tab == 0) NavStore.tab = savedTab
        0
    }
    androidx.compose.runtime.SideEffect { savedPeer = NavStore.peer; savedChannel = NavStore.channel; savedUrl = NavStore.url; savedTab = NavStore.tab }
    val tab = Tab.entries[NavStore.tab.coerceIn(0, Tab.entries.size - 1)]
    val openPeer = NavStore.peer
    val openChannel = NavStore.channel
    val browserUrl = NavStore.url

    // فتح الرابط: في المتصفح المدمج أو الخارجي حسب الإعدادات. بيقبل http/https بس.
    val openLink: (String) -> Unit = { raw ->
        val u = normalizeUrl(raw)
        val scheme = Uri.parse(u).scheme?.lowercase()
        if (scheme == "http" || scheme == "https") {
            if (prefs.browserInApp) NavStore.url = u
            else runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }

    // آخر قيم غير فاضية: علشان شاشة الخروج تفضل شايفة بياناتها أثناء الأنيميشن
    val lastPeer = androidx.compose.runtime.remember { mutableStateOf<Profile?>(null) }
    val lastChannel = androidx.compose.runtime.remember { mutableStateOf<com.binarybeast.chatapp.data.Channel?>(null) }
    val lastUrl = androidx.compose.runtime.remember { mutableStateOf<String?>(null) }
    val lastBot = androidx.compose.runtime.remember { mutableStateOf<com.binarybeast.chatapp.data.BotInfo?>(null) }
    if (NavStore.bot != null) lastBot.value = NavStore.bot
    if (openPeer != null) lastPeer.value = openPeer
    if (openChannel != null) lastChannel.value = openChannel
    if (browserUrl != null) lastUrl.value = browserUrl
    val screenKey = when {
        callState != CallState.Idle && (callState !is CallState.Incoming || NavStore.callExpanded) -> "call"
        browserUrl != null -> "url"
        NavStore.bot != null -> "bot"
        NavStore.botsOpen -> "bots"
        openChannel != null -> "channel"
        openPeer != null -> "peer"
        else -> "tabs"
    }

    androidx.compose.runtime.LaunchedEffect(callState is CallState.Idle) { if (callState is CallState.Idle) NavStore.callExpanded = false }
    // مكالمة واردة وإنت جوه التطبيق: بانر صغير فوق (رد/رفض) بدل ما الشاشة كلها تتقلب
    if (callState is CallState.Incoming && !NavStore.callExpanded) IncomingCallBanner((callState as CallState.Incoming))

    CompositionLocalProvider(LocalOpenLink provides openLink) {
        androidx.compose.animation.AnimatedContent(
            targetState = screenKey,
            transitionSpec = {
                if (targetState == "tabs") {
                    (androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(220)) +
                        androidx.compose.animation.scaleIn(initialScale = 0.96f, animationSpec = androidx.compose.animation.core.tween(220))) togetherWith
                        (androidx.compose.animation.slideOutHorizontally(androidx.compose.animation.core.tween(260)) { it / 3 } + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(200)))
                } else {
                    (androidx.compose.animation.slideInHorizontally(androidx.compose.animation.core.tween(280)) { it / 3 } + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(240))) togetherWith
                        (androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(160)) + androidx.compose.animation.scaleOut(targetScale = 0.96f, animationSpec = androidx.compose.animation.core.tween(220)))
                }
            },
            label = "screen",
        ) { key ->
            when (key) {
                "call" -> CallScreen()
                "url" -> lastUrl.value?.let { BrowserScreen(it, onClose = { NavStore.url = null }) }
                "bot" -> lastBot.value?.let { b -> BotChatScreen(b, onBack = { NavStore.bot = null }) }
                "bots" -> BotsScreen(onBack = { NavStore.botsOpen = false }, onOpen = { NavStore.bot = it })
                "channel" -> lastChannel.value?.let { ChannelView(it, onBack = { NavStore.channel = null }) }
                "peer" -> lastPeer.value?.let { p ->
                    BackHandler { NavStore.peer = null }
                    ChatScreen(peer = p, onBack = { NavStore.peer = null })
                }
                else -> Scaffold(
                    bottomBar = {
                        FloatingNavBar(
                            items = Tab.entries.map { t ->
                                (when (t) {
                                    Tab.Chats -> AIcons.Chat
                                    Tab.Stories -> AIcons.AutoAwesome
                                    Tab.Channels -> AIcons.Campaign
                                    Tab.Calls -> AIcons.Call
                                    Tab.Profile -> AIcons.Person
                                }) to t.label
                            },
                            selected = tab.ordinal,
                            onSelect = { NavStore.tab = it },
                        )
                    },
                ) { pad ->
                    androidx.compose.animation.AnimatedContent(
                        targetState = tab,
                        modifier = Modifier.padding(pad).fillMaxSize(),
                        transitionSpec = {
                            (androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(220)) +
                                androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(240)) { it / 24 }) togetherWith
                                androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120))
                        },
                        label = "tab",
                    ) { t ->
                        Box(Modifier.fillMaxSize()) {
                            when (t) {
                                Tab.Chats -> if (NavStore.spaceOpen) PrivateSpaceScreen(onClose = { NavStore.spaceOpen = false }, onOpen = { NavStore.peer = it }) else ChatListScreen(onOpen = { NavStore.peer = it })
                                Tab.Stories -> StoriesScreen(me = me)
                                Tab.Channels -> ChannelsScreen(onOpen = { NavStore.channel = it })
                                Tab.Calls -> CallsScreen(onOpenChat = { NavStore.peer = it; NavStore.tab = 0 })
                                Tab.Profile -> ProfileScreen(session = session)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** حالة قابلة للحفظ (بتعدّي على إعادة إنشاء الأكتيفتي) لأي كلاس @Serializable. */
@Composable
private fun <T : Any> rememberSavedJson(ser: kotlinx.serialization.KSerializer<T>): androidx.compose.runtime.MutableState<T?> =
    androidx.compose.runtime.saveable.rememberSaveable(
        saver = androidx.compose.runtime.saveable.Saver<androidx.compose.runtime.MutableState<T?>, String>(
            save = { st -> st.value?.let { kotlinx.serialization.json.Json.encodeToString(ser, it) } ?: "" },
            restore = { str -> mutableStateOf(if (str.isEmpty()) null else runCatching { kotlinx.serialization.json.Json.decodeFromString(ser, str) }.getOrNull()) },
        ),
    ) { mutableStateOf<T?>(null) }


@Composable
private fun IncomingCallBanner(st: CallState.Incoming) {
    val prof by androidx.compose.runtime.produceState<Profile?>(null, st.peerId) { value = ChatEngine.profile(st.peerId) }
    androidx.compose.ui.window.Popup(
        alignment = Alignment.TopCenter,
        properties = androidx.compose.ui.window.PopupProperties(focusable = false),
    ) {
        Row(
            Modifier.statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp).fillMaxWidth()
                .glass(androidx.compose.foundation.shape.RoundedCornerShape(28.dp))
                .clickable { NavStore.callExpanded = true }.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Avatar(prof?.avatarFileId, prof?.displayName.orEmpty().ifBlank { prof?.phone.orEmpty() }, 44.dp)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(Lang.raw(prof?.displayName.orEmpty().ifBlank { prof?.phone.orEmpty().ifBlank { "مكالمة واردة" } }), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, maxLines = 1)
                Text(if (st.video) "مكالمة فيديو واردة" else "مكالمة صوت واردة", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            GlassCircleButton(AIcons.Close, { CallManager.reject() }, size = 44.dp, contentDescription = "رفض")
            Spacer(Modifier.width(8.dp))
            GlassCircleButton(AIcons.Call, { CallManager.accept() }, size = 44.dp, accent = true, contentDescription = "رد")
        }
    }
}
