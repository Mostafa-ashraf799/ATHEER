package com.binarybeast.chatapp.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.binarybeast.chatapp.data.AuthRepository
import com.binarybeast.chatapp.data.ChannelRepository
import com.binarybeast.chatapp.data.ChatEngine
import com.binarybeast.chatapp.data.Invites
import com.binarybeast.chatapp.data.Profile
import com.binarybeast.chatapp.data.ProfileRepository
import com.binarybeast.chatapp.data.SpaceStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

fun copyText(ctx: Context, text: String) {
    ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("link", text))
    Toast.makeText(ctx, Lang.trNow("اتنسخ"), Toast.LENGTH_SHORT).show()
}

fun shareText(ctx: Context, text: String) {
    AppLock.skipNext()
    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

/** صف لينك دعوة: نص + نسخ + مشاركة (+ تجديد اختياري). */
@Composable
fun LinkRow(label: String, link: String, onReset: (() -> Unit)? = null) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Text(Lang.raw(link), style = MaterialTheme.typography.bodySmall, maxLines = 2)
        Row {
            TextButton(onClick = { copyText(ctx, link) }) { Text("نسخ") }
            TextButton(onClick = { shareText(ctx, link) }) { Text("مشاركة") }
            if (onReset != null) TextButton(onClick = onReset) { Text("تجديد اللينك") }
        }
    }
}

/** بيفتح لينك دعوة: حساب / قناة / مجموعة / مساحة خاصة. */
object InviteHandler {
    fun open(ctx: Context, raw: String, scope: CoroutineScope) {
        val link = Invites.parse(raw) ?: run { toast(ctx, "لينك الدعوة مش صحيح"); return }
        scope.launch {
            when (link) {
                is Invites.Link.User -> {
                    val p = runCatching { ProfileRepository.byId(link.key) ?: ProfileRepository.findByUsername(link.key) }.getOrNull()
                    if (p == null) toast(ctx, "الحساب مش موجود")
                    else if (p.id == AuthRepository.currentUserId) toast(ctx, "ده حسابك انت 🙂")
                    else { NavStore.tab = 0; NavStore.peer = p }
                }
                is Invites.Link.Channel -> {
                    val c = runCatching { ChannelRepository.byHandle(link.handle) }.getOrNull()
                    if (c == null) toast(ctx, "القناة مش موجودة") else { NavStore.channel = c }
                }
                is Invites.Link.Group -> {
                    val g = ChatEngine.groups.get(link.groupId)
                    if (g != null) ChatEngine.peerProfile("g:" + g.groupId)?.let { NavStore.tab = 0; NavStore.peer = it }
                    else if (ChatEngine.requestJoin(link.groupId, link.adminId, link.token)) toast(ctx, "اتبعت طلب الانضمام. المجموعة هتظهر عندك أول ما الأدمن يفتح التطبيق.")
                    else toast(ctx, "تعذّر إرسال طلب الانضمام")
                }
                is Invites.Link.Space -> {
                    val p = runCatching { ProfileRepository.findBySpace(link.number) }.getOrNull()
                    if (p == null) toast(ctx, "اللينك ده مش شغّال")
                    else if (p.id == AuthRepository.currentUserId) toast(ctx, "ده رقم مساحتك انت")
                    else { SpaceStore.markPeer(p.id); NavStore.tab = 0; NavStore.peer = p }
                }
            }
        }
    }
    private fun toast(ctx: Context, m: String) = Toast.makeText(ctx, Lang.trNow(m), Toast.LENGTH_LONG).show()
}

/** كل المحادثات (أشخاص ومجموعات) من الداتابيز المحلية، من غير محادثات المساحة "s:" ومن غير الرسائل المحفوظة. */
@Composable
fun rememberAllChats(includeGroups: Boolean): List<Profile> {
    var list by remember { mutableStateOf<List<Profile>>(emptyList()) }
    val me = AuthRepository.currentUserId
    LaunchedEffect(Unit) {
        val last = runCatching { ChatEngine.dao.observeLastOnce() }.getOrDefault(emptyList())
        list = last.filter { !SpaceStore.isSpace(it.peerId) && it.peerId != me && (includeGroups || !ChatEngine.isGroup(it.peerId)) }
            .sortedByDescending { it.createdAt }
            .mapNotNull { ChatEngine.peerProfile(it.peerId) }
    }
    return list
}

/** اختيار أكتر من محادثة (أشخاص، واختياريًا مجموعات). */
@Composable
fun PickChatsDialog(
    title: String, includeGroups: Boolean, confirmLabel: String = "تمام",
    exclude: Set<String> = emptySet(), onDone: (List<Profile>) -> Unit, onClose: () -> Unit,
) {
    val all = rememberAllChats(includeGroups).filter { it.id !in exclude }
    val sel = remember { mutableStateListOf<String>() }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title) },
        text = {
            if (all.isEmpty()) Text("مفيش محادثات تتختار منها.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            else LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(all, key = { it.id }) { p ->
                    Row(
                        Modifier.fillMaxWidth().clickable { if (p.id in sel) sel.remove(p.id) else sel.add(p.id) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Checkbox(p.id in sel, { if (it) sel.add(p.id) else sel.remove(p.id) })
                        Avatar(p.avatarFileId, p.displayName.ifBlank { p.phone }, 36.dp)
                        Text(Lang.raw(p.displayName.ifBlank { p.username ?: "مستخدم" }), fontWeight = FontWeight.SemiBold, maxLines = 1)
                    }
                }
            }
        },
        confirmButton = { TextButton(enabled = sel.isNotEmpty(), onClick = { onDone(all.filter { it.id in sel }); onClose() }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } },
    )
}
