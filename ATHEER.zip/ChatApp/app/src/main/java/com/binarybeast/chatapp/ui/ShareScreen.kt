package com.binarybeast.chatapp.ui

import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.binarybeast.chatapp.data.ChatEngine
import com.binarybeast.chatapp.data.TelegramStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** محتوى جاي من «مشاركة» تطبيق تاني (ملفات و/أو نص). */
class SharePayload(val uris: List<Uri>, val text: String?)

/** شاشة اختيار وجهة المشاركة: ستوري + الشات والمجموعات (زي مشاركة واتساب/تليجرام). */
@Composable
fun ShareScreen(payload: SharePayload, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val chats = rememberAllChats(true)
    val stories: StoriesVm = viewModel()
    val sel = remember { mutableStateListOf<String>() }
    var toStory by remember { mutableStateOf(false) }
    var caption by remember { mutableStateOf(payload.text.orEmpty()) }
    var q by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    val hasMedia = payload.uris.isNotEmpty()
    val storyOk = payload.uris.any { (ctx.contentResolver.getType(it) ?: "").let { m -> m.startsWith("image/") || m.startsWith("video/") } }
    val shown = chats.filter { q.isBlank() || it.displayName.contains(q, true) || it.phone.contains(q) }
    val canSend = !busy && (sel.isNotEmpty() || toStory)

    Scaffold(topBar = { GlassTopBar(title = { Text("مشاركة إلى…", fontWeight = FontWeight.Bold) }, navigationIcon = {
        androidx.compose.material3.IconButton(onClick = onClose) { androidx.compose.material3.Icon(AIcons.ArrowBack, "إلغاء") }
    }) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Text(
                (if (hasMedia) "${payload.uris.size} ملف" else "") + (if (hasMedia && !payload.text.isNullOrBlank()) " + " else "") + (if (!payload.text.isNullOrBlank()) "نص" else ""),
                Modifier.padding(horizontal = 16.dp, vertical = 6.dp).enterFade(), color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(caption, { caption = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp), label = { Text(if (hasMedia) "تعليق (اختياري)" else "النص") }, maxLines = 3)
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), label = { Text("بحث") }, singleLine = true)
            LazyColumn(Modifier.weight(1f)) {
                if (storyOk) item(key = "story") {
                    Row(Modifier.fillMaxWidth().enterSlideEnd(key = "sh:story").clickable { toStory = !toStory }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Checkbox(toStory, { toStory = it })
                        Text("✨ ستوريز بتاعتي (٢٤ ساعة)", fontWeight = FontWeight.SemiBold)
                    }
                }
                items(shown, key = { it.id }) { p ->
                    Row(Modifier.fillMaxWidth().enterSlideEnd(key = "sh:" + p.id).clickable { if (p.id in sel) sel.remove(p.id) else sel.add(p.id) }.padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Checkbox(p.id in sel, { if (it) sel.add(p.id) else sel.remove(p.id) })
                        Avatar(p.avatarFileId, p.displayName.ifBlank { p.phone }, 40.dp)
                        Text((if (p.id.startsWith("g:")) "👥 " else "") + p.displayName.ifBlank { p.phone })
                    }
                }
                if (shown.isEmpty() && !storyOk) item { Text("مفيش محادثات لسه.", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            status?.let { Text(it, Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.primary) }
            Button(
                enabled = canSend,
                onClick = {
                    busy = true; status = "بيتبعت…"
                    val targets = chats.filter { it.id in sel }
                    scope.launch {
                        var fail = 0
                        // الملفات تتقرا مرة واحدة وتتبعت لكل الوجهات
                        val files = if (hasMedia) withContext(Dispatchers.IO) { payload.uris.mapNotNull { runCatching { readUri(ctx, it) }.getOrNull() } } else emptyList()
                        if (hasMedia && files.isEmpty()) { status = "تعذّر قراءة الملف"; busy = false; return@launch }
                        if (toStory) files.firstOrNull { it.third.startsWith("image/") || it.third.startsWith("video/") }?.let { (b, n, m) ->
                            stories.post(b, n, m, caption.ifBlank { null }, 24.0)
                        }
                        for ((idx, f) in files.withIndex()) {
                            val (b, n, m) = f
                            val kind = when { m.startsWith("image/") -> "image"; m.startsWith("video/") -> "video"; m.startsWith("audio/") -> "audio"; else -> "file" }
                            val fileId = if (targets.isEmpty()) null else runCatching {
                                val up = if (kind == "image" && com.binarybeast.chatapp.data.AppSettings.now.uploadQuality == "high") "image_hq" else kind
                                TelegramStorage.upload(b, n, m, up)
                            }.getOrNull()
                            if (targets.isNotEmpty() && fileId == null) { fail++; continue }
                            targets.forEach { p ->
                                runCatching { ChatEngine.send(p, body = if (idx == 0) caption.ifBlank { null } else null, fileId = fileId, mediaType = kind) }.onFailure { fail++ }
                            }
                        }
                        if (!hasMedia && caption.isNotBlank()) targets.forEach { p -> runCatching { ChatEngine.send(p, caption.trim()) }.onFailure { fail++ } }
                        busy = false
                        if (fail == 0) { android.widget.Toast.makeText(ctx, "اتبعت ✅", android.widget.Toast.LENGTH_SHORT).show(); onClose() }
                        else status = "فشل $fail — جرّب تاني"
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(16.dp),
            ) {
                if (busy) CircularProgressIndicator(Modifier.height(18.dp), strokeWidth = 2.dp) else Text("إرسال" + if (sel.size + (if (toStory) 1 else 0) > 0) " (${sel.size + (if (toStory) 1 else 0)})" else "")
            }
        }
    }
}
