package com.binarybeast.chatapp.ui

import android.content.Context
import androidx.compose.runtime.staticCompositionLocalOf
import com.binarybeast.chatapp.data.AppSettings
import java.util.concurrent.ConcurrentHashMap

/**
 * اللغات: 10 لغات. «auto» = لغة الجهاز لو مدعومة وإلا الإنجليزي.
 * النصوص العربية في الكود هي المفتاح؛ الجدول في assets/i18n.tsv (عمود لكل لغة) وpatterns.tsv للجمل اللي فيها أرقام.
 */
object Lang {
    val LANGS = listOf(
        "ar" to "العربية", "en" to "English", "fr" to "Français", "es" to "Español", "de" to "Deutsch",
        "tr" to "Türkçe", "ru" to "Русский", "fa" to "فارسی", "ur" to "اردو", "id" to "Bahasa Indonesia",
    )
    private val COL = mapOf("en" to 1, "fr" to 2, "es" to 3, "de" to 4, "tr" to 5, "ru" to 6, "fa" to 7, "ur" to 8, "id" to 9)
    /** علامة (حرف غير مرئي) قبل نص المستخدم علشان ميتترجمش بالغلط. */
    const val RAW = '\u200B'
    fun raw(s: String) = RAW + s

    private val RTL = setOf("ar", "fa", "ur")

    private val table = HashMap<String, Array<String>>()
    private class Pat(val re: Regex, val out: Array<String>)
    private val patterns = ArrayList<Pat>()
    private val caches = ConcurrentHashMap<String, ConcurrentHashMap<String, String>>()
    @Volatile private var loaded = false

    private fun norm(s: String) = s.replace("\\n", "\n").replace(Regex("[ \t]+"), " ").trim()

    fun init(ctx: Context) {
        if (loaded) return
        runCatching {
            ctx.assets.open("i18n.tsv").bufferedReader().useLines { ls ->
                ls.forEach { l ->
                    val c = l.split('\t'); if (c.size >= 10) table[norm(c[0])] = Array(10) { c[it].replace("\\n", "\n") }
                }
            }
            ctx.assets.open("patterns.tsv").bufferedReader().useLines { ls ->
                ls.forEach { l ->
                    val c = l.split('\t'); if (c.size >= 10) patterns += Pat(Regex(c[0]), Array(10) { c[it].replace("\\n", "\n") })
                }
            }
        }
        loaded = true
    }

    /** الكود الفعلي للغة حسب الإعداد (auto → لغة الجهاز). */
    fun resolve(pref: String): String {
        if (pref != "auto" && LANGS.any { it.first == pref }) return pref
        val dev = when (val l = java.util.Locale.getDefault().language) { "in" -> "id"; "iw" -> "he"; else -> l }
        return if (LANGS.any { it.first == dev }) dev else "en"
    }

    fun isRtl(code: String) = code in RTL

    /** ترجمة نص عربي للغة code. لو مفيش ترجمة بيرجع النص زي ما هو (فأسماء الناس والرسايل مبتتأثرش). */
    fun tr(s: String, code: String): String {
        if (code == "ar" || s.isEmpty() || !loaded || s[0] == RAW) return s
        val col = COL[code] ?: return s
        // كاش لكل لغة: مفيش بناء مفتاح نصي جديد مع كل رسم للشاشة
        val cache = caches.getOrPut(code) { ConcurrentHashMap() }
        cache[s]?.let { return it }
        val r = translate(s, col)
        if (cache.size > 4000) cache.clear()
        cache[s] = r
        return r
    }

    fun trNow(s: String): String = tr(s, resolve(AppSettings.now.language))

    private fun translate(s: String, col: Int): String {
        if (!s.any { it in '؀'..'ۿ' }) return s
        val lead = s.takeWhile { it.isWhitespace() }
        val trail = s.takeLastWhile { it.isWhitespace() }
        val core = norm(s)
        if (core.isEmpty()) return s
        table[core]?.let { return lead + it[col] + trail }
        for (p in patterns) {
            val m = p.re.matchEntire(core) ?: continue
            var out = p.out[col]
            for (i in 1 until m.groupValues.size) out = out.replace("{$i}", translate(m.groupValues[i], col))
            return lead + out + trail
        }
        if (core.contains('\n')) {
            val lines = core.split('\n').map { line ->
                val bullet = if (line.startsWith("• ")) "• " else ""
                bullet + translate(line.removePrefix("• "), col)
            }
            return lead + lines.joinToString("\n") + trail
        }
        return s
    }
}

val LocalLang = staticCompositionLocalOf { "ar" }
