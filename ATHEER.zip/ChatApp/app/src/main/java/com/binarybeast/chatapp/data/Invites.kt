package com.binarybeast.chatapp.data

import android.content.Context
import android.content.SharedPreferences
import com.binarybeast.chatapp.data.local.GroupEntity
import java.security.SecureRandom

/**
 * لينكات الدعوة (atheer://…): حساب، قناة، مجموعة، ومساحة خاصة.
 * - المجموعة: اللينك فيه معرّف المجموعة + الأدمن + توكن سري. اللي يفتحه بيبعت طلب انضمام مشفّر للأدمن، وجهاز الأدمن بيضيفه لوحده لو التوكن صح (والأدمن يقدر يجدّد التوكن فاللينك القديم يبطل).
 */
object Invites {
    private lateinit var sp: SharedPreferences
    fun init(ctx: Context) { sp = ctx.applicationContext.getSharedPreferences(Accounts.name("invites"), Context.MODE_PRIVATE) }

    sealed class Link {
        data class User(val key: String) : Link()
        data class Channel(val handle: String) : Link()
        data class Group(val groupId: String, val adminId: String, val token: String) : Link()
        data class Space(val number: String) : Link()
    }

    private val re = Regex("atheer://([ucgs])/([A-Za-z0-9_\\-]+)(?:/([A-Za-z0-9_\\-]+))?(?:/([A-Za-z0-9_\\-]+))?")

    /** بيدوّر على أول لينك دعوة جوه أي نص (علشان لو اتبعت جوه رسالة). */
    fun parse(text: String?): Link? {
        val m = re.find(text ?: return null) ?: return null
        val (kind, a, b, c) = m.destructured
        return when (kind) {
            "u" -> Link.User(a)
            "c" -> Link.Channel(a)
            "g" -> if (b.isNotEmpty() && c.isNotEmpty()) Link.Group(a, b, c) else null
            "s" -> if (SpaceStore.valid(a)) Link.Space(a) else null
            else -> null
        }
    }

    fun user(p: Profile) = "atheer://u/" + (p.username?.takeIf { it.isNotBlank() } ?: p.id)
    fun channel(handle: String) = "atheer://c/$handle"
    fun space(number: String) = "atheer://s/" + number.filter { it.isDigit() }
    fun group(g: GroupEntity) = "atheer://g/${g.groupId}/${g.adminId}/${token(g.groupId)}"

    fun token(groupId: String): String {
        sp.getString("t_$groupId", null)?.let { return it }
        return reset(groupId)
    }
    fun reset(groupId: String): String {
        val b = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val t = b.joinToString("") { "%02x".format(it) }
        sp.edit().putString("t_$groupId", t).apply()
        return t
    }
    fun checkToken(groupId: String, t: String): Boolean = t.isNotEmpty() && sp.getString("t_$groupId", null) == t

    // طلبات انضمام أنا بعتها (علشان أقبل ميتا المجموعة من الأدمن حتى لو إعداد «دعوات المجموعات» مقفول)
    fun addPending(groupId: String) { sp.edit().putStringSet("pending", (sp.getStringSet("pending", emptySet()) ?: emptySet()) + groupId).apply() }
    fun isPending(groupId: String) = ::sp.isInitialized && groupId in (sp.getStringSet("pending", emptySet()) ?: emptySet())
    fun clearPending(groupId: String) { sp.edit().putStringSet("pending", (sp.getStringSet("pending", emptySet()) ?: emptySet()) - groupId).apply() }
}
