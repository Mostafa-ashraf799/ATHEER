package com.binarybeast.chatapp

import com.binarybeast.chatapp.data.local.previewText

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.binarybeast.chatapp.data.local.LocalMessage

object Notifier {
    private const val CH_MSG = "msg_nimbus"        // Nimbus Notify
    private const val CH_REPLY = "msg_echo"        // Echo Reply
    private const val CH_MENTION = "msg_mention"   // Vivid Mention
    private const val CH_CALL = "calls_aurora"     // Aurora Ring (بيتكرر لحد الرد)
    const val ACTION_ANSWER = "com.binarybeast.chatapp.CALL_ANSWER"
    const val ACTION_DECLINE = "com.binarybeast.chatapp.CALL_DECLINE"
    private const val CALL_NOTIF_ID = 7001
    const val CH_SERVICE = "service"

    fun init(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "الاتصال في الخلفية", NotificationManager.IMPORTANCE_MIN)
        )
        // قنوات الإصدارات القديمة (صوت النظام الافتراضي) بتتمسح
        listOf("messages", "calls").forEach { runCatching { nm.deleteNotificationChannel(it) } }
        fun snd(res: Int, usage: Int) = ctx.applicationContext.let { c ->
            com.binarybeast.chatapp.Sounds.rawUri(c, res) to android.media.AudioAttributes.Builder().setUsage(usage)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        }
        fun msgChannel(id: String, name: String, res: Int) {
            val (u, a) = snd(res, android.media.AudioAttributes.USAGE_NOTIFICATION)
            nm.createNotificationChannel(NotificationChannel(id, name, NotificationManager.IMPORTANCE_HIGH).apply { setSound(u, a) })
        }
        msgChannel(CH_MSG, "الرسايل", R.raw.nimbus_notify)
        msgChannel(CH_REPLY, "الردود على رسايلك", R.raw.echo_reply)
        msgChannel(CH_MENTION, "المنشن", R.raw.vivid_mention)
        val (ru, ra) = snd(R.raw.aurora_ring, android.media.AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
        nm.createNotificationChannel(
            NotificationChannel(CH_CALL, "المكالمات", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(ru, ra)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 600, 500, 600, 500, 600)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
        )
    }

    private fun openApp(ctx: Context, requestCode: Int): PendingIntent =
        PendingIntent.getActivity(
            ctx, requestCode,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    /** kind: 0 عادي | 1 رد على رسالتي | 2 منشن */
    fun message(ctx: Context, m: LocalMessage, senderName: String, kind: Int = 0) {
        val prefs = com.binarybeast.chatapp.data.AppSettings.now
        if (!prefs.notifMessages || m.peerId in prefs.muted || com.binarybeast.chatapp.data.AppSettings.isTempMuted(m.peerId) || com.binarybeast.chatapp.data.AppSettings.inQuietHours()) return
        val text = if (!prefs.notifPreview) "رسالة جديدة"
        else m.previewText()
        val n = NotificationCompat.Builder(ctx, when (kind) { 2 -> CH_MENTION; 1 -> CH_REPLY; else -> CH_MSG })
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(if (prefs.hideNotifSender) "ATHEER" else senderName)
            .setContentText(text)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(if (prefs.notifPreview && !prefs.hideNotifSender) NotificationCompat.VISIBILITY_PRIVATE else NotificationCompat.VISIBILITY_SECRET)
            .setContentIntent(openApp(ctx, m.peerId.hashCode()))
            .build()
        runCatching { ctx.getSystemService(NotificationManager::class.java).notify(m.peerId.hashCode(), n) }
    }

    /** إشعار عام للمساحة الخاصة: من غير اسم ولا محتوى. */
    fun important(ctx: Context) {
        val prefs = com.binarybeast.chatapp.data.AppSettings.now
        if (!prefs.notifMessages || com.binarybeast.chatapp.data.AppSettings.inQuietHours()) return
        val n = NotificationCompat.Builder(ctx, CH_MSG)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("ATHEER")
            .setContentText(com.binarybeast.chatapp.ui.Lang.trNow("وصلك رسالة مهمة"))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(openApp(ctx, 7700))
            .build()
        runCatching { ctx.getSystemService(NotificationManager::class.java).notify(7700, n) }
    }

    /** منشور جديد في قناة مشترك فيها. */
    fun channelPost(ctx: Context, channelId: Long, title: String, text: String) {
        val prefs = com.binarybeast.chatapp.data.AppSettings.now
        if (!prefs.notifMessages || "c:$channelId" in prefs.muted || com.binarybeast.chatapp.data.AppSettings.inQuietHours()) return
        val n = NotificationCompat.Builder(ctx, CH_MSG)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(if (prefs.hideNotifSender) "ATHEER" else title)
            .setContentText(if (prefs.notifPreview) text else "منشور جديد")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openApp(ctx, ("c:$channelId").hashCode()))
            .build()
        runCatching { ctx.getSystemService(NotificationManager::class.java).notify(("c:$channelId").hashCode(), n) }
    }

    /**
     * مكالمة واردة: إشعار منبثق صغير (heads-up) فيه «رد» و«رفض» وصوت Aurora Ring متكرر، من غير ما يقاطع اللي بتعمله (لعبة/تطبيق).
     * الشاشة الكاملة بتظهر بس لو الجهاز مقفول (النظام بيقرر).
     */
    fun call(ctx: Context, name: String, video: Boolean) {
        if (!com.binarybeast.chatapp.data.AppSettings.now.notifCalls) return
        val open = openApp(ctx, CALL_NOTIF_ID)
        val answer = PendingIntent.getActivity(
            ctx, CALL_NOTIF_ID + 1,
            Intent(ctx, MainActivity::class.java).setAction(ACTION_ANSWER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val decline = PendingIntent.getBroadcast(
            ctx, CALL_NOTIF_ID + 2,
            Intent(ctx, CallActionReceiver::class.java).setAction(ACTION_DECLINE).setPackage(ctx.packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val b = NotificationCompat.Builder(ctx, CH_CALL)
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle(name)
            .setContentText(com.binarybeast.chatapp.ui.Lang.trNow(if (video) "مكالمة فيديو واردة" else "مكالمة صوت واردة"))
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setTimeoutAfter(45_000)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, com.binarybeast.chatapp.ui.Lang.trNow("رفض"), decline)
            .addAction(android.R.drawable.sym_call_incoming, com.binarybeast.chatapp.ui.Lang.trNow("رد"), answer)
            .setFullScreenIntent(open, true)
        val n = b.build().apply { flags = flags or android.app.Notification.FLAG_INSISTENT }   // الصوت بيتكرر لحد الرد/الرفض/الانتهاء
        runCatching { ctx.getSystemService(NotificationManager::class.java).notify(CALL_NOTIF_ID, n) }
    }

    fun cancelCall(ctx: Context) {
        runCatching { ctx.getSystemService(NotificationManager::class.java).cancel(CALL_NOTIF_ID) }
    }
}
