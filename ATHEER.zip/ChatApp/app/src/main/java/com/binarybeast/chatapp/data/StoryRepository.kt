package com.binarybeast.chatapp.data

import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order

object StoryRepository {
    private val me get() = AuthRepository.currentUserId ?: error("not signed in")

    /** كل الستوريز الشغالة (آخر 24 ساعة) مجمّعة حسب صاحبها. */
    suspend fun feed(): List<StoryGroup> {
        val uid = me
        purgeMyExpired()
        val stories = Supa.client.from("stories").select {
            filter { gt("expires_at", java.time.Instant.now().toString()) }
            order("created_at", Order.ASCENDING)
        }.decodeList<Story>()
        if (stories.isEmpty()) return emptyList()

        val seenIds = Supa.client.from("story_views").select {
            filter { eq("viewer_id", uid) }
        }.decodeList<StoryView>().map { it.storyId }.toSet()

        val mentionedIds = runCatching {
            Supa.client.from("story_mentions").select { filter { eq("user_id", uid) } }
                .decodeList<StoryMention>().map { it.storyId }.toSet()
        }.getOrDefault(emptySet())
        val profiles = ProfileRepository.byIds((stories.map { it.userId } + stories.mapNotNull { it.origUser }).toSet()).associateBy { it.id }
        val enriched = stories.map { st ->
            st.copy(mentioned = st.id in mentionedIds,
                origName = st.origUser?.let { o -> profiles[o]?.let { p -> p.displayName.ifBlank { p.phone } } })
        }

        return enriched.groupBy { it.userId }.mapNotNull { (userId, list) ->
            val p = profiles[userId] ?: return@mapNotNull null
            StoryGroup(p, list, seen = list.all { it.id in seenIds })
        }.sortedWith(
            // بتاعتي الأول، بعدين اللي ذكروني، بعدين اللي لسه ماتشافتش
            compareByDescending<StoryGroup> { it.user.id == uid }.thenByDescending { g -> g.stories.any { it.mentioned } }.thenBy { it.seen }
        )
    }

    const val MAX_ACTIVE = 5

    suspend fun myActiveCount(): Int = Supa.client.from("stories").select {
        filter { eq("user_id", me); gt("expires_at", java.time.Instant.now().toString()) }
    }.decodeList<Story>().size

    /** مدة الستوري بالساعات يحددها المستخدم (لحد 720 = 30 يوم). mentions: userId -> اسم المجموعة (أو null لو إشارة مباشرة). */
    suspend fun post(
        fileId: String, mediaType: String, caption: String?, hours: Double,
        allowRepost: Boolean = false, mentions: Map<String, String?> = emptyMap(),
    ) {
        val exp = java.time.Instant.now().plusSeconds((hours.coerceIn(0.1, 720.0) * 3600).toLong()).toString()
        val created = Supa.client.from("stories").insert(NewStory(me, fileId, mediaType, caption, exp, allowRepost)) { select() }
            .decodeSingle<Story>()
        val rows = mentions.filterKeys { it != me }.entries.take(60).map { StoryMention(created.id, it.key, it.value) }
        if (rows.isNotEmpty()) runCatching { Supa.client.from("story_mentions").insert(rows) }
    }

    /** إعادة نشر ستوري حد تاني (السيرفر بيتأكد إن صاحبها سامح بده). */
    suspend fun repost(src: Story, hours: Double = 24.0) {
        val exp = java.time.Instant.now().plusSeconds((hours.coerceIn(0.1, 720.0) * 3600).toLong()).toString()
        Supa.client.from("stories").insert(
            NewStory(me, src.fileId, src.mediaType, src.caption, exp, false, repostOf = src.id, origUser = src.userId)
        )
    }

    /** تنضيف ستوريز صاحبها المنتهية. */
    suspend fun purgeMyExpired() {
        runCatching {
            Supa.client.from("stories").delete {
                filter { eq("user_id", me); lt("expires_at", java.time.Instant.now().toString()) }
            }
        }
    }

    suspend fun markSeen(storyId: Long) {
        runCatching {
            Supa.client.from("story_views").upsert(StoryView(storyId, me))
        }
    }

    suspend fun delete(storyId: Long) {
        Supa.client.from("stories").delete { filter { eq("id", storyId) } }
    }

    /** مين شاف الستوري دي (لصاحبها بس). */
    suspend fun viewers(storyId: Long): List<Profile> {
        val ids = Supa.client.from("story_views").select { filter { eq("story_id", storyId) } }
            .decodeList<StoryView>().map { it.viewerId }.filter { it != me }
        return ProfileRepository.byIds(ids)
    }
}
