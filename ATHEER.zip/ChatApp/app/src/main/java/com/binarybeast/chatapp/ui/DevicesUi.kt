package com.binarybeast.chatapp.ui

import android.graphics.Bitmap
import android.graphics.Color as AColor
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.binarybeast.chatapp.data.DeviceControl
import com.binarybeast.chatapp.data.DeviceStore
import com.binarybeast.chatapp.data.DeviceSync
import com.binarybeast.chatapp.data.LinkReceiver
import com.binarybeast.chatapp.data.LinkSender
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.launch

private fun qrBitmap(text: String, size: Int): Bitmap {
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, mapOf(EncodeHintType.MARGIN to 1, EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M))
    val px = IntArray(size * size)
    for (y in 0 until size) for (x in 0 until size) px[y * size + x] = if (m[x, y]) AColor.BLACK else AColor.WHITE
    return Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
}

/** شاشة الجهاز الجديد (من شاشة الدخول): QR بيتغيّر كل ١٥ ثانية. */
@Composable
fun LinkNewDeviceScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val qr by LinkReceiver.qr.collectAsState()
    val status by LinkReceiver.status.collectAsState()
    BackHandler { onBack() }
    DisposableEffect(Unit) {
        LinkReceiver.start()
        onDispose { LinkReceiver.stop() }
    }
    val prog = remember { Animatable(1f) }
    LaunchedEffect(qr) { prog.snapTo(1f); prog.animateTo(0f, tween(LinkReceiver.ROTATE_MS.toInt(), easing = LinearEasing)) }
    Scaffold(topBar = { GlassTopBar(title = { Text("ربط من جهاز آخر", fontWeight = FontWeight.Bold) }, navigationIcon = {
        androidx.compose.material3.IconButton(onClick = onBack) { androidx.compose.material3.Icon(AIcons.ArrowBack, "رجوع") }
    }) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("على جهازك القديم (اللي عليه حسابك):", fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
            Text("افتح ATHEER ← الإعدادات ← الأجهزة المرتبطة ← «ربط جهاز جديد» وصوّر الكود ده.", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(20.dp))
            Box(Modifier.size(280.dp).clip(RoundedCornerShape(20.dp)).background(androidx.compose.ui.graphics.Color.White).padding(10.dp).enterPop(), contentAlignment = Alignment.Center) {
                if (qr.isNotEmpty()) {
                    val bmp = remember(qr) { qrBitmap(qr, 640) }
                    Image(bmp.asImageBitmap(), "QR", Modifier.fillMaxSize())
                } else androidx.compose.material3.CircularProgressIndicator()
            }
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(progress = { prog.value }, Modifier.size(width = 280.dp, height = 4.dp))
            Text("الكود بيتغيّر كل ١٥ ثانية", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
            if (status.isNotBlank()) Text(status, Modifier.padding(top = 14.dp), color = MaterialTheme.colorScheme.primary, textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(18.dp))
            Text(
                "• لازم الجهازين على نفس الواي فاي (أو هوتسبوت).\n• النقل بيتم مباشرة بين الجهازين على الشبكة المحلية؛ الرسايل والمفاتيح مبتعدّيش على أي سيرفر.\n• المفتاح الخاص بالتشفير بيتنقل للجهاز الجديد علشان يقدر يفك رسايلك.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** الإعدادات ← الأجهزة المرتبطة. */
@Composable
fun DevicesPage() {
    val scope = rememberCoroutineScope()
    val ch by DeviceStore.changes.collectAsState()
    val conn by DeviceSync.connected.collectAsState()
    val list = remember(ch) { DeviceStore.list() }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var ask by remember { mutableStateOf<Pair<String, CompletableDeferred<Boolean>>?>(null) }
    var removeId by remember { mutableStateOf<String?>(null) }
    var killOthers by remember { mutableStateOf(false) }

    val scan = rememberLauncherForActivityResult(ScanContract()) { res ->
        val text = res.contents ?: return@rememberLauncherForActivityResult
        busy = true; msg = "بيتّصل بالجهاز الجديد…"
        scope.launch {
            val err = LinkSender.link(text, confirm = { name -> val d = CompletableDeferred<Boolean>(); ask = name to d; d.await() }, progress = { msg = it })
            busy = false
            msg = err ?: "تم ربط الجهاز ✅"
        }
    }

    ask?.let { (name, d) ->
        AlertDialog(
            onDismissRequest = { d.complete(false); ask = null },
            title = { Text("ربط «$name»؟") },
            text = { Text("هيدخل الجهاز ده على حسابك ويستلم محادثاتك ومفتاح التشفير بتاعك. اتأكد إنه جهازك انت.") },
            confirmButton = { TextButton(onClick = { d.complete(true); ask = null }) { Text("اربطه") } },
            dismissButton = { TextButton(onClick = { d.complete(false); ask = null }) { Text("إلغاء") } },
        )
    }
    removeId?.let { id ->
        AlertDialog(
            onDismissRequest = { removeId = null },
            title = { Text("إلغاء ربط الجهاز؟") },
            text = { Text("هيتسجّل خروج الجهاز ده ويتمسح الشات منه أول ما يتصل بجهاز من أجهزتك.") },
            confirmButton = { TextButton(onClick = { removeId = null; scope.launch { DeviceControl.remove(id) } }) { Text("إلغاء الربط") } },
            dismissButton = { TextButton(onClick = { removeId = null }) { Text("رجوع") } },
        )
    }
    if (killOthers) AlertDialog(
        onDismissRequest = { killOthers = false },
        title = { Text("خروج من كل الأجهزة التانية؟") },
        text = { Text("كل الجلسات التانية هتتقفل فورًا (حتى لو الجهاز أوفلاين). هتحتاج تربط أجهزتك من جديد.") },
        confirmButton = { TextButton(onClick = { killOthers = false; scope.launch { msg = if (DeviceControl.signOutOthers()) "اتقفلت الجلسات التانية ✅" else "تعذّر التنفيذ (النت؟)" } }) { Text("خروج") } },
        dismissButton = { TextButton(onClick = { killOthers = false }) { Text("رجوع") } },
    )

    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("الجهاز ده", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Row(Modifier.fillMaxWidth().enterSlideEnd(key = "dev:me"), verticalAlignment = Alignment.CenterVertically) {
            Text("📱 " + DeviceStore.myName(), Modifier.weight(1f)); Text("هذا الجهاز", style = MaterialTheme.typography.labelSmall)
        }
        Text("الأجهزة المرتبطة (${list.size})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp))
        if (list.isEmpty()) Text("مفيش أجهزة مرتبطة لسه.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        list.forEach { d ->
            Row(Modifier.fillMaxWidth().enterSlideEnd(key = "dev:" + d.id), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("📱 " + d.name.ifBlank { "جهاز" })
                    val online = d.id in conn
                    Text(
                        if (online) "● متصل (نفق P2P)" else if (d.lastSeen > 0) "آخر اتصال: " + java.text.SimpleDateFormat("d/M HH:mm", java.util.Locale.getDefault()).format(java.util.Date(d.lastSeen)) else "لسه ماتّصلش",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (online) androidx.compose.ui.graphics.Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                TextButton(onClick = { removeId = d.id }) { Text("إلغاء الربط", color = MaterialTheme.colorScheme.error) }
            }
        }
        Button(onClick = {
            scan.launch(ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE).setPrompt("صوّر الكود اللي ظاهر على الجهاز الجديد").setBeepEnabled(false).setOrientationLocked(false))
        }, enabled = !busy, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("➕ ربط جهاز جديد (تصوير QR)") }
        if (msg.isNotBlank()) Text(msg, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
        if (list.isNotEmpty()) OutlinedButton(onClick = { killOthers = true }, modifier = Modifier.fillMaxWidth()) { Text("🚪 تسجيل الخروج من كل الأجهزة التانية") }
        Text(
            "إزاي بيشتغل:\n• الجهاز الجديد (من شاشة الدخول ← «الربط من جهاز آخر») بيعرض QR بيتغيّر كل ١٥ ثانية، وانت بتصوّره من هنا.\n• النقل الأول بيتم مباشرة على الشبكة المحلية (نفس الواي فاي) من غير أي سيرفر.\n• بعد الربط، المزامنة (رسايل جديدة، تفاعلات، تعديل، حذف، قراءة) بتمشي في نفق P2P منفصل بين أجهزتك؛ السيرفر بيشوف بس إشارات اتصال مشفّرة.\n\nحدود:\n• المساحات الخاصة مش بتتنقل (لأن مفاتيحها محلية).\n• لو جهاز كان أوفلاين، بياخد اللي فاته (آخر ٣٠ يوم) أول ما يتصل بجهاز تاني من أجهزتك.\n• التعديلات (تفاعل/حذف/قراءة) اللي بتحصل والجهاز التاني أوفلاين مش بتتنقل له.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp),
        )
    }
}
