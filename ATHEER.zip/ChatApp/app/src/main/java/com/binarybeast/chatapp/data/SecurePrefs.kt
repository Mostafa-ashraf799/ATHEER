package com.binarybeast.chatapp.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * فتح EncryptedSharedPreferences بأمان. على أجهزة كتير الـKeystore بيتبوّظ (بعد تحديث أو تغيير قفل الشاشة…)
 * فالفتح بيرمي استثناء والتطبيق بيقع كل مرة لحد ما المستخدم يمسحه ويثبّته تاني.
 * هنا: لو الفتح فشل بنمسح الملف التالف ونعيد المحاولة، ولو فشل برضه بنرجع لملف عادي بدل ما نقع.
 */
object SecurePrefs {
    fun open(ctx: Context, name: String): SharedPreferences {
        val app = ctx.applicationContext
        fun create() = EncryptedSharedPreferences.create(
            app, name,
            MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
        try { return create() } catch (_: Throwable) {}
        runCatching { app.deleteSharedPreferences(name) }
        runCatching {
            val ks = java.security.KeyStore.getInstance("AndroidKeyStore"); ks.load(null)
            ks.deleteEntry("_androidx_security_master_key_")
        }
        try { return create() } catch (_: Throwable) {}
        runCatching { app.deleteSharedPreferences(name) }
        return app.getSharedPreferences(name + "_fallback", Context.MODE_PRIVATE)
    }

    /** لو التطبيق وقع مرتين ورا بعض وهو بيفتح: نمسح التخزين المشفّر (زي إعادة التثبيت) بدل ما يفضل يقع. */
    fun healIfCrashLoop(ctx: Context) {
        val f = java.io.File(ctx.filesDir, "crashloop.txt")
        val n = runCatching { f.readText().trim().toInt() }.getOrDefault(0)
        if (n >= 2) {
            runCatching {
                ctx.applicationInfo.dataDir.let { java.io.File(it, "shared_prefs").listFiles() }?.forEach {
                    if (it.name.startsWith("accounts_sec") || it.name.startsWith("keys") || it.name.startsWith("devices") || it.name.startsWith("space_sec")) it.delete()
                }
                val ks = java.security.KeyStore.getInstance("AndroidKeyStore"); ks.load(null)
                ks.deleteEntry("_androidx_security_master_key_")
            }
            f.delete()
        }
        // لو فضل شغال ١٠ ثواني نعتبر الفتح نجح ونصفّر العدّاد
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ runCatching { f.delete() } }, 10_000)
    }

    fun noteCrash(ctx: Context) {
        val f = java.io.File(ctx.filesDir, "crashloop.txt")
        val n = runCatching { f.readText().trim().toInt() }.getOrDefault(0)
        runCatching { f.writeText((n + 1).toString()) }
    }
}
