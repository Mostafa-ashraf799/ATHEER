package com.binarybeast.chatapp.ui

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import io.github.jan.supabase.realtime.realtime
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton

import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.coerceAtMost
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.binarybeast.chatapp.call.CallManager
import com.binarybeast.chatapp.data.AppSettings
import com.binarybeast.chatapp.data.ChatEngine
import com.binarybeast.chatapp.data.Profile
import com.binarybeast.chatapp.data.local.previewText
import com.binarybeast.chatapp.data.TelegramStorage
import com.binarybeast.chatapp.data.local.LocalMessage
import com.binarybeast.chatapp.data.local.MsgStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** يقرأ ملف من Uri ويرجّع (bytes, name, mime).  */
fun readUri(ctx: Context, uri: Uri): Triple<ByteArray, String, String> {
    val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
    val name = uri.lastPathSegment?.substringAfterLast('/') ?: "file"
    val size = runCatching { ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } }.getOrNull() ?: -1L
    // مفيش حد من التطبيق (الملفات الكبيرة بتتقسّم عند الرفع)؛ بس حماية من نفاد ذاكرة الجهاز
    require(size < 0 || size <= 150L * 1024 * 1024) { "الملف أكبر من اللي ذاكرة الجهاز تستحمله (150 ميجا)" }
    val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
    return Triple(bytes, name, mime)
}

// ======================================================================= قايمة المحادثات

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChatListScreen(onOpen: (Profile) -> Unit, vm: ChatListVm = viewModel()) {
    val chatsAll by vm.chats.collectAsState()
    val hiddenIds by com.binarybeast.chatapp.data.SpaceStore.hidden.collectAsState()
    val chats = chatsAll.filter { it.peer.id !in hiddenIds }
    val searchError by vm.searchError.collectAsState()
    val ctxL = androidx.compose.ui.platform.LocalContext.current
    val scopeL = androidx.compose.runtime.rememberCoroutineScope()
    var showNew by remember { mutableStateOf(false) }
    var phone by remember { mutableStateOf("") }
    val prefs by AppSettings.prefs.collectAsState()
    var showArchived by remember { mutableStateOf(false) }
    var showGroup by remember { mutableStateOf(false) }
    var gName by remember { mutableStateOf("") }
    var gPhones by remember { mutableStateOf("") }
    var gPicked by remember { mutableStateOf<List<Profile>>(emptyList()) }
    var gPicking by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    var botChats by remember { mutableStateOf<List<Pair<com.binarybeast.chatapp.data.BotInfo, com.binarybeast.chatapp.data.BotMsg?>>>(emptyList()) }
    var botHit by remember { mutableStateOf<com.binarybeast.chatapp.data.BotInfo?>(null) }
    val openBotNow = NavStore.bot
    LaunchedEffect(openBotNow) { botChats = runCatching { com.binarybeast.chatapp.data.BotRepository.chatted() }.getOrDefault(emptyList()) }
    var gSearch by remember { mutableStateOf(false) }
    var gq by remember { mutableStateOf("") }
    // البوتات مبتظهرش في أي قايمة: بس لما تبحث باليوزرنيم بالظبط
    LaunchedEffect(gq, gSearch) {
        botHit = null
        if (gSearch && gq.trim().removePrefix("@").length >= 3) {
            kotlinx.coroutines.delay(350)
            botHit = runCatching { com.binarybeast.chatapp.data.BotRepository.byUsername(gq) }.getOrNull()
        }
    }
    var hits by remember { mutableStateOf<List<LocalMessage>>(emptyList()) }
    // الرقم السري للمساحة الخاصة لو اتكتب في البحث: يفتح المساحة (من غير أي أثر في النتائج)
    LaunchedEffect(gq) {
        kotlinx.coroutines.delay(250)
        if (kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { com.binarybeast.chatapp.data.SpaceStore.matches(gq) }) { gq = ""; gSearch = false; NavStore.spaceOpen = true; return@LaunchedEffect }
        hits = if (gq.trim().length >= 2) runCatching { ChatEngine.dao.search(gq.trim()) }.getOrDefault(emptyList()).filter { !com.binarybeast.chatapp.data.SpaceStore.isHidden(it.peerId) } else emptyList()
    }
    val myId0 = com.binarybeast.chatapp.data.AuthRepository.currentUserId
    var chatFilter by remember { mutableStateOf(0) }   // 0 الكل | 1 غير مقروءة | 2 أشخاص | 3 مجموعات
    val visible = chats
        .filter { it.peer.id != myId0 }
        .filter { (it.peer.id in prefs.archived) == showArchived }
        .filter { when (chatFilter) { 1 -> it.unread > 0; 2 -> !it.peer.id.startsWith("g:"); 3 -> it.peer.id.startsWith("g:"); else -> true } }
        .sortedWith(
            when (prefs.chatSort) {
                "unread" -> compareByDescending<com.binarybeast.chatapp.data.ChatPreview> { it.peer.id in prefs.pinned }.thenByDescending { it.unread > 0 }.thenByDescending { it.last.createdAt }
                "name" -> compareByDescending<com.binarybeast.chatapp.data.ChatPreview> { it.peer.id in prefs.pinned }.thenBy { it.peer.displayName.ifBlank { it.peer.phone }.lowercase() }
                else -> compareByDescending<com.binarybeast.chatapp.data.ChatPreview> { it.peer.id in prefs.pinned }.thenByDescending { it.last.createdAt }
            },
        )
    val typingList by ChatEngine.typing.collectAsState()
    val totalUnread = chats.sumOf { if (it.peer.id in prefs.muted) 0 else it.unread }
    var listMenu by remember { mutableStateOf(false) }
    var showBroadcast by remember { mutableStateOf(false) }
    var focusDlg by remember { mutableStateOf(false) }

    if (showBroadcast) BroadcastDialog(onClose = { showBroadcast = false })
    if (focusDlg) ChoiceDialog("وضع التركيز: كتم الإشعارات لمدة", listOf("1" to "ساعة", "2" to "ساعتين", "8" to "٨ ساعات", "24" to "يوم"), "1", { v -> AppSettings.setFocus(v.toInt()); android.widget.Toast.makeText(ctxL, "وضع التركيز شغّال 🎯", android.widget.Toast.LENGTH_SHORT).show() }, { focusDlg = false })
    Scaffold(
        topBar = {
            GlassTopBar(
                title = {
                    if (gSearch) OutlinedTextField(
                        value = gq, onValueChange = { gq = it }, singleLine = true,
                        placeholder = { Text("ابحث في كل الرسايل") }, modifier = Modifier.fillMaxWidth(),
                    ) else if (showArchived) Text("المؤرشفة", fontWeight = FontWeight.Bold) else Row(verticalAlignment = Alignment.CenterVertically) { ConnectionTitle(); if (prefs.unreadInTitle && totalUnread > 0) Text(" ($totalUnread)", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }
                },
                actions = {
                    IconButton(onClick = { gSearch = !gSearch; gq = "" }) { Icon(if (gSearch) AIcons.Close else AIcons.Search, "بحث") }
                    IconButton(onClick = { showGroup = true }) { Icon(AIcons.GroupAdd, "مجموعة جديدة") }
                    IconButton(onClick = { showArchived = !showArchived }) {
                        Icon(if (showArchived) AIcons.Unarchive else AIcons.Archive, "المؤرشفة")
                    }
                    IconButton(onClick = { listMenu = true }) { Icon(AIcons.MoreVert, "المزيد") }
                    DropdownMenu(expanded = listMenu, onDismissRequest = { listMenu = false }) {
                        DropdownMenuItem(text = { Text("✅ تحديد الكل كمقروء") }, onClick = {
                            listMenu = false
                            scopeL.launch { chats.filter { it.unread > 0 }.forEach { c -> runCatching { ChatEngine.dao.markRead(c.peer.id) } } }
                        })
                        DropdownMenuItem(text = { Text("📣 رسالة لأكتر من شخص") }, onClick = { listMenu = false; showBroadcast = true })
                        DropdownMenuItem(
                            text = { Text(if (prefs.focusUntil > System.currentTimeMillis()) "🎯 إنهاء وضع التركيز" else "🎯 وضع التركيز (كتم الإشعارات)") },
                            onClick = { listMenu = false; if (prefs.focusUntil > System.currentTimeMillis()) AppSettings.setFocus(0) else focusDlg = true },
                        )
                        DropdownMenuItem(text = { Text("🔃 ترتيب: " + when (prefs.chatSort) { "unread" -> "غير المقروء الأول"; "name" -> "بالاسم"; else -> "الأحدث" }) }, onClick = {
                            listMenu = false
                            AppSettings.update { s -> s.copy(chatSort = when (s.chatSort) { "recent" -> "unread"; "unread" -> "name"; else -> "recent" }) }
                        })
                    }
                },
            )
        },
        floatingActionButton = {
            GlassCircleButton(AIcons.PersonAdd, { showNew = true }, size = 60.dp, accent = true, contentDescription = "محادثة جديدة")
        },
    ) { pad ->
        if (gSearch && gq.isNotBlank()) {
            val byName = chats.filter { it.peer.id != myId0 && (it.peer.displayName + " " + (it.peer.username ?: "") + " " + it.peer.phone).contains(gq.trim(), ignoreCase = true) }
            LazyColumn(Modifier.padding(pad)) {
                botHit?.let { bh ->
                    item { Text("بوت", Modifier.padding(16.dp, 8.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) }
                    item(key = "bh" + bh.id) {
                        Row(Modifier.fillMaxWidth().clickable { NavStore.bot = bh; gSearch = false; gq = "" }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            BotAvatar(bh, 44.dp)
                            Column(Modifier.padding(horizontal = 12.dp)) {
                                androidx.compose.material3.Text(bh.name + " 🤖", fontWeight = FontWeight.SemiBold)
                                androidx.compose.material3.Text("@" + bh.username, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                if (byName.isNotEmpty()) item { Text("محادثات", Modifier.padding(16.dp, 8.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) }
                items(byName, key = { "c" + it.peer.id }) { c ->
                    Row(Modifier.fillMaxWidth().clickable { onOpen(c.peer) }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(c.peer.avatarFileId, c.peer.displayName.ifBlank { c.peer.phone }, 44.dp)
                        Text(c.peer.displayName.ifBlank { c.peer.phone }, Modifier.padding(horizontal = 12.dp), fontWeight = FontWeight.SemiBold)
                    }
                }
                if (hits.isNotEmpty()) item { Text("رسايل", Modifier.padding(16.dp, 8.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) }
                items(hits, key = { "m" + it.id }) { h ->
                    val who = if (h.peerId == myId0) ChatEngine.savedProfile() else chats.firstOrNull { it.peer.id == h.peerId }?.peer
                    if (who != null) Column(Modifier.fillMaxWidth().clickable { onOpen(who) }.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Text(if (h.peerId == myId0) "الرسائل المحفوظة" else who.displayName.ifBlank { who.phone }, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        Text(h.previewText(), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
                if (byName.isEmpty() && hits.isEmpty() && botHit == null) item { Text("مفيش نتايج.", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            return@Scaffold
        }
        if (visible.isEmpty() && showArchived) {
            Box(Modifier.padding(pad).fillMaxSize(), Alignment.Center) {
                Text(if (showArchived) "مفيش محادثات مؤرشفة." else "مفيش محادثات لسه.\nدوس على ➕ وابدأ برقم صاحبك.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else LazyColumn(Modifier.padding(pad)) {
            if (!showArchived) item(key = "filters") {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("الكل", "غير مقروءة", "أشخاص", "مجموعات").forEachIndexed { i, label ->
                        androidx.compose.material3.FilterChip(selected = chatFilter == i, onClick = { chatFilter = i }, label = { Text(label) })
                    }
                }
            }
            if (!showArchived) item {
                // «الرسائل المحفوظة»: محادثة مع نفسك، محلية بالكامل
                val savedLast = chats.firstOrNull { it.peer.id == myId0 }?.last
                Row(
                    Modifier.fillMaxWidth().clickable { onOpen(ChatEngine.savedProfile()) }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(52.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                        Text("🔖", style = MaterialTheme.typography.titleLarge)
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text("الرسائل المحفوظة", fontWeight = FontWeight.SemiBold)
                        Text(
                            savedLast?.previewText()?.takeIf { it.isNotBlank() } ?: "احفظ رسايل وملاحظات ليك انت بس",
                            maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
            if (!showArchived) items(botChats, key = { "bot" + it.first.id }) { (bot, last) ->
                Row(
                    Modifier.fillMaxWidth().clickable { NavStore.bot = bot }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    BotAvatar(bot, 52.dp)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        androidx.compose.material3.Text(bot.name + " 🤖", fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        androidx.compose.material3.Text(
                            if (prefs.hideListPreview) "••••••" else (last?.text ?: "").replace(Regex("<[^>]+>"), "").replace("\\", "").take(80),
                            maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
            if (visible.isEmpty() && !showArchived) item {
                Text("مفيش محادثات لسه.\nدوس على ➕ وابدأ برقم صاحبك.", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(visible, key = { it.peer.id }) { c ->
                Row(
                    Modifier.fillMaxWidth().enterSlideEnd(delayMs = visible.indexOf(c).coerceIn(0, 8) * 35, key = "row:" + c.peer.id).combinedClickable(onClick = { onOpen(c.peer) }, onLongClick = { menuFor = c.peer.id }).padding(horizontal = 16.dp, vertical = if (prefs.compactList) 4.dp else 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Avatar(c.peer.avatarFileId, c.peer.displayName.ifBlank { c.peer.phone }, if (prefs.compactList) 44.dp else 52.dp)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(
                            c.peer.displayName.ifBlank { c.peer.phone },
                            fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            if (prefs.typingInList && c.peer.id in typingList) "بيكتب…" else if (prefs.hideListPreview) "••••••" else c.last.previewText(),
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (prefs.typingInList && c.peer.id in typingList) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (c.peer.id in prefs.muted || AppSettings.isTempMuted(c.peer.id)) Text("🔕", style = MaterialTheme.typography.labelSmall)
                            if (c.peer.id in prefs.pinned) Icon(AIcons.PushPin, null, Modifier.size(12.dp))
                            Text(hhmmMs(c.last.createdAt), style = MaterialTheme.typography.labelSmall)
                        }
                        DropdownMenu(expanded = menuFor == c.peer.id, onDismissRequest = { menuFor = null }) {
                            DropdownMenuItem(
                                text = { Text(if (c.peer.id in prefs.pinned) "إلغاء التثبيت" else "تثبيت") },
                                onClick = { AppSettings.togglePin(c.peer.id); menuFor = null },
                            )
                            DropdownMenuItem(
                                text = { Text(if (c.peer.id in prefs.muted) "تشغيل الإشعارات" else "كتم الإشعارات") },
                                onClick = { AppSettings.toggleMute(c.peer.id); menuFor = null },
                            )
                            DropdownMenuItem(
                                text = { Text(if (c.peer.id in prefs.archived) "إلغاء الأرشفة" else "أرشفة") },
                                onClick = { AppSettings.toggleArchive(c.peer.id); menuFor = null },
                            )
                            if (!ChatEngine.isGroup(c.peer.id)) DropdownMenuItem(
                                text = { Text("تحديد كغير مقروءة") },
                                onClick = { scopeL.launch { ChatEngine.dao.markLastUnread(c.peer.id) }; menuFor = null },
                            )
                            DropdownMenuItem(
                                text = { Text("📤 تصدير المحادثة (نص)") },
                                onClick = {
                                    val p = c.peer; menuFor = null
                                    scopeL.launch {
                                        val f = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                                        val me = ChatEngine.profile(myId0 ?: "")?.displayName?.ifBlank { null } ?: "أنا"
                                        val txt = ChatEngine.dao.chatAll(p.id).joinToString("\n") { m ->
                                            "[" + f.format(java.util.Date(m.createdAt)) + "] " + (if (m.mine) me else p.displayName.ifBlank { p.phone }) + ": " + (m.body ?: ("<" + (m.mediaType ?: "ملف") + ">"))
                                        }
                                        shareText(ctxL, txt.ifBlank { "—" })
                                    }
                                },
                            )
                            com.binarybeast.chatapp.data.SpaceStore.list().let { sps ->
                                sps.forEach { sp ->
                                    DropdownMenuItem(
                                        text = { Text(if (sps.size > 1) "🔒 نقل إلى " + Lang.raw(sp.name) else "🔒 نقل للمساحة الخاصة") },
                                        onClick = { com.binarybeast.chatapp.data.SpaceStore.hide(c.peer.id, sp.id); menuFor = null },
                                    )
                                }
                            }
                        }
                        if (c.unread > 0) {
                            Spacer(Modifier.height(4.dp))
                            Box(
                                Modifier.swell(c.unread).enterBounce().clip(CircleShape).background(MaterialTheme.colorScheme.primary).size(22.dp),
                                contentAlignment = Alignment.Center,
                            ) { Text("${c.unread}", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelSmall) }
                        }
                    }
                }
            }
        }
    }

    if (gPicking) PickChatsDialog("اختار الأعضاء من محادثاتك", includeGroups = false, onDone = { gPicked = it }, onClose = { gPicking = false })
    if (showGroup) AlertDialog(
        onDismissRequest = { showGroup = false },
        title = { Text("مجموعة جديدة") },
        text = {
            Column {
                OutlinedTextField(value = gName, onValueChange = { gName = it }, label = { Text("اسم المجموعة") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = gPhones, onValueChange = { gPhones = it }, label = { Text("أرقام الأعضاء (بفاصلة أو سطر جديد)") },
                    minLines = 3, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                )
                TextButton(onClick = { gPicking = true }) { Text(if (gPicked.isEmpty()) "➕ اختيار من محادثاتي" else "✅ اتختار ${gPicked.size} — تعديل") }
                searchError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.createGroup(gName, gPhones, gPicked) { p -> if (p != null) { showGroup = false; gName = ""; gPhones = ""; gPicked = emptyList(); onOpen(p) } }
            }) { Text("إنشاء") }
        },
        dismissButton = { TextButton(onClick = { showGroup = false }) { Text("إلغاء") } },
    )

    var saved by remember { mutableStateOf<List<Profile>>(emptyList()) }
    var refreshTick by remember { mutableStateOf(0) }
    LaunchedEffect(showNew, prefs.backupContacts, refreshTick) {
        if (showNew) {
            // القايمة بتظهر فورًا من الجهاز؛ بنحدّثها من السيرفر بس لو فاضية/قديمة أو لما تدوس «تحديث»
            saved = com.binarybeast.chatapp.data.ContactSync.cached()
            if (refreshTick > 0 || com.binarybeast.chatapp.data.ContactSync.needsRefresh())
                saved = runCatching { com.binarybeast.chatapp.data.ContactSync.refresh() }.getOrDefault(saved)
        }
    }
    if (showNew) AlertDialog(
        onDismissRequest = { showNew = false },
        title = { Text("محادثة جديدة") },
        text = {
            Column {
                OutlinedTextField(
                    value = phone, onValueChange = { phone = it },
                    label = { Text("رقم الموبايل أو @يوزر_نيم") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                )
                searchError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("حفظ جهات الاتصال")
                        androidx.compose.material3.Text(
                            "بيتحفظ بس مين بتكلّمهم (مش الرسايل) علشان ترجّعهم لو مسحت التطبيق",
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                    androidx.compose.material3.Switch(checked = prefs.backupContacts, onCheckedChange = { on ->
                        AppSettings.update { s -> s.copy(backupContacts = on) }
                        com.binarybeast.chatapp.data.ContactSync.syncAll()
                    })
                }
                if (saved.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.Text("جهات الاتصال المحفوظة", style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
                        TextButton(onClick = { refreshTick++ }) { Text("تحديث") }
                    }
                    Column(Modifier.heightIn(max = 240.dp).verticalScroll(rememberScrollState())) {
                        saved.forEach { p ->
                            Row(
                                Modifier.fillMaxWidth().clickable { showNew = false; onOpen(p) }.padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Avatar(p.avatarFileId, p.displayName.ifBlank { p.phone }, 40.dp)
                                androidx.compose.material3.Text(
                                    (p.displayName.ifBlank { "—" }) + (p.username?.let { "  @$it" } ?: ""),
                                    modifier = Modifier.padding(start = 12.dp),
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val typed = phone
                scopeL.launch {
                    val isSpaceNo = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { com.binarybeast.chatapp.data.SpaceStore.matches(typed) }
                    if (isSpaceNo) { showNew = false; phone = ""; NavStore.spaceOpen = true }
                    else if (com.binarybeast.chatapp.data.Invites.parse(typed) != null) { InviteHandler.open(ctxL, typed, scopeL); showNew = false; phone = "" }
                    else vm.findUser(typed) { showNew = false; phone = ""; onOpen(it) }
                }
            }) { Text("ابدأ") }
        },
        dismissButton = { TextButton(onClick = { showNew = false }) { Text("إلغاء") } },
    )
}

// ======================================================================= شاشة المحادثة

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChatScreen(peer: Profile, onBack: () -> Unit) {
    val wp by com.binarybeast.chatapp.data.AppSettings.prefs.collectAsState()
    Box(Modifier.fillMaxSize()) {
        ChatWallpaper(wp.wallpaper)
        ChatScreenInner(peer, onBack)
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
private fun ChatScreenInner(peer: Profile, onBack: () -> Unit) {
    val vm: ChatVm = viewModel(key = "chat-${peer.id}", factory = viewModelFactory { initializer { ChatVm(peer) } })
    val messages by vm.messages.collectAsState()
    val sending by vm.sending.collectAsState()
    val notice by vm.notice.collectAsState()
    val prefs by AppSettings.prefs.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val editTargetState = remember { mutableStateOf<LocalMessage?>(null) }
    var linkVer by remember { mutableStateOf(0) }
    var showQuick by remember { mutableStateOf(false) }
    val isSp = com.binarybeast.chatapp.data.SpaceStore.isSpace(peer.id)
    val hiddenSet by com.binarybeast.chatapp.data.SpaceStore.hidden.collectAsState()
    if (isSp || peer.id in hiddenSet) SecureWindow()
    var text by remember { mutableStateOf(AppSettings.draft(peer.id)) }
    LaunchedEffect(text) { if (editTargetState.value == null) AppSettings.setDraft(peer.id, text) }
    var editing by remember { mutableStateOf<Pair<Uri, Boolean>?>(null) }
    var viewer by remember { mutableStateOf<LocalMessage?>(null) }
    var starOnly by remember { mutableStateOf(false) }
    var silentMode by remember { mutableStateOf(false) }
    var ttlPick by remember { mutableStateOf(false) }
    var schedPick by remember { mutableStateOf(false) }
    var schedList by remember { mutableStateOf(false) }
    var pendingMedia by remember { mutableStateOf<MediaDraft?>(null) }
    var restrictedView by remember { mutableStateOf<Pair<LocalMessage, Int>?>(null) }   // الرسالة + الثواني المتبقية (0 = من غير مؤقّت)
    var attachMenu by remember { mutableStateOf(false) }
    val ctxL2 = androidx.compose.ui.platform.LocalContext.current
    var showStickers by remember { mutableStateOf(false) }
    val removing = remember { androidx.compose.runtime.mutableStateListOf<Long>() }
    val translations = remember { androidx.compose.runtime.mutableStateMapOf<String, String>() }
    val uiLang = LocalLang.current
    var showMaker by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var storiesHidden by remember(peer.id) { mutableStateOf(false) }
    val scopeMenu = androidx.compose.runtime.rememberCoroutineScope()
    LaunchedEffect(peer.id) {
        if (!peer.id.startsWith("g:")) storiesHidden = runCatching { com.binarybeast.chatapp.data.ContactSync.isHidden(peer.id) }.getOrDefault(false)
    }
    var replyTo by remember { mutableStateOf<LocalMessage?>(null) }
    var editTarget by remember { mutableStateOf<LocalMessage?>(null) }
    editTargetState.value = editTarget
    var actionMsg by remember { mutableStateOf<LocalMessage?>(null) }
    var confirmDelete by remember { mutableStateOf<LocalMessage?>(null) }
    var searchOn by remember { mutableStateOf(false) }
    val typingSet by vm.typing.collectAsState()
    val grp by vm.group.collectAsState()
    val votes by vm.votes.collectAsState()
    val names by vm.names.collectAsState()
    var showInfo by remember { mutableStateOf(false) }
    var showProfile by remember { mutableStateOf(false) }
    var showAddMembers by remember { mutableStateOf(false) }
    var showGroupBots by remember { mutableStateOf(false) }
    val groupBotsNow by vm.groupBots.collectAsState()
    val botMsgList by vm.botMsgs.collectAsState()
    val botNotice by vm.botNotice.collectAsState()
    var showSafety by remember { mutableStateOf(false) }
    var infoMsg by remember { mutableStateOf<LocalMessage?>(null) }
    var forwardMsg by remember { mutableStateOf<LocalMessage?>(null) }
    val listVm: ChatListVm = viewModel()
    val allChats by listVm.chats.collectAsState()
    var online by remember { mutableStateOf(false) }
    LaunchedEffect(peer.id) {
        while (!vm.isGroup) { online = ChatEngine.isLinkOpen(peer.id); kotlinx.coroutines.delay(2000) }
    }
    var showPoll by remember { mutableStateOf(false) }
    val myId = com.binarybeast.chatapp.data.AuthRepository.currentUserId
    val recorder = remember { com.binarybeast.chatapp.media.VoiceRecorder(ctx) }
    var recording by remember { mutableStateOf(false) }
    var recMs by remember { mutableStateOf(0L) }
    LaunchedEffect(recording) {
        val t0 = System.currentTimeMillis()
        while (recording) { recMs = System.currentTimeMillis() - t0; kotlinx.coroutines.delay(200) }
    }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { if (recorder.running) recorder.cancel() } }
    var query by remember { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current
    val shown = remember(messages, searchOn, query, starOnly) {
        val shown0 = if (searchOn && query.isNotBlank()) messages.filter { it.body?.contains(query, ignoreCase = true) == true } else messages
        (if (starOnly) shown0.filter { it.starred } else shown0).filter { !it.deleted }
    }
    val limitN by vm.limit.collectAsState()
    val hasMore = messages.size >= limitN && !searchOn && !starOnly
    val blocked = peer.id in prefs.blocked
    if (showSafety) androidx.compose.material3.AlertDialog(
        onDismissRequest = { showSafety = false },
        title = { Text("التحقق من التشفير") },
        text = {
            val k = peer.publicKey
            Column {
                Text(if (k == null) "مفتاح الطرف التاني مش متاح دلوقتي." else com.binarybeast.chatapp.data.ChatEngine.safetyNumber(k),
                    style = MaterialTheme.typography.titleMedium)
                Text("قارن الرقم ده مع الطرف التاني (مكالمة أو وجهًا لوجه). لو متطابق يبقى مفيش حد معترض الرسايل بينكم.",
                    Modifier.padding(top = 8.dp), style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = { showSafety = false }) { Text("تمام") } },
    )

    if (ttlPick) AlertDialog(
        onDismissRequest = { ttlPick = false },
        title = { Text("مسح الرسايل تلقائيًا") },
        text = {
            Column {
                listOf(0 to "إيقاف", 3600 to "بعد ساعة", 86400 to "بعد 24 ساعة", 7 * 86400 to "بعد 7 أيام", 30 * 86400 to "بعد 30 يوم").forEach { (sec, label) ->
                    TextButton(onClick = { AppSettings.setChatTtl(peer.id, sec); ttlPick = false }) {
                        Text(label + if (AppSettings.chatTtl(peer.id) == sec) "  ✓" else "")
                    }
                }
                Text("بينطبّق على الرسايل الجاية اللي إنت بتبعتها وبتستقبلها. الطرف التاني بيمسحها عنده كمان.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = { ttlPick = false }) { Text("تمام") } },
    )
    if (schedPick) AlertDialog(
        onDismissRequest = { schedPick = false },
        title = { Text("ابعتها بعد…") },
        text = {
            Column {
                listOf(5 to "5 دقايق", 30 to "30 دقيقة", 60 to "ساعة", 180 to "3 ساعات", 720 to "12 ساعة", 1440 to "غدًا").forEach { (min, label) ->
                    TextButton(onClick = {
                        val t = text; text = ""; schedPick = false
                        scope.launch { ChatEngine.schedule(peer, t, System.currentTimeMillis() + min * 60_000L) }
                    }) { Text(label) }
                }
                Text("بتتبعت لوحدها في الميعاد طول ما التطبيق (أو الخدمة الخلفية) شغّال.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { schedPick = false }) { Text("إلغاء") } },
    )
    if (schedList) {
        var items by remember { mutableStateOf<List<com.binarybeast.chatapp.data.local.ScheduledMsg>>(emptyList()) }
        LaunchedEffect(schedList) { items = ChatEngine.scheduled.forPeer(peer.id) }
        AlertDialog(
            onDismissRequest = { schedList = false },
            title = { Text("الرسايل المجدولة") },
            text = {
                Column {
                    if (items.isEmpty()) Text("مفيش رسايل مجدولة.")
                    items.forEach { it0 ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(it0.body, maxLines = 2)
                                Text(hhmmMs(it0.sendAt), style = MaterialTheme.typography.labelSmall)
                            }
                            TextButton(onClick = { scope.launch { ChatEngine.scheduled.delete(it0.id); items = ChatEngine.scheduled.forPeer(peer.id) } }) { Text("إلغاء") }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { schedList = false }) { Text("تمام") } },
        )
    }

    // أي صورة/فيديو/صوت بيعدّي على اختيار طريقة العرض قبل الإرسال
    fun queueMedia(bytes: ByteArray, name: String, mime: String, caption: String?) {
        if (mime.startsWith("image/") || mime.startsWith("video/") || mime.startsWith("audio/")) pendingMedia = MediaDraft(bytes, name, mime, caption)
        else vm.sendMedia(bytes, name, mime, caption)
    }
    pendingMedia?.let { d ->
        ViewModeDialog(
            onCancel = { pendingMedia = null },
            onSend = { mode, secs -> pendingMedia = null; vm.sendMedia(d.bytes, d.name, d.mime, d.caption, mode, secs) },
        )
    }
    restrictedView?.let { (m, secs) ->
        RestrictedViewer(m, secs, onClose = {
            restrictedView = null
            if (m.viewMode == 1) scope.launch { ChatEngine.burn(m) }
        })
    }

    val source = rememberMediaSource(
        onMedia = { uri, isVideo -> editing = uri to isVideo },
        onFile = { uri ->
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { readUri(ctx, uri) } }
                    .onSuccess { (b, n, m) -> queueMedia(b, n, m, null) }
                    .onFailure { vm.notice.value = it.message ?: "تعذّر قراءة الملف" }
            }
        },
    )

    LaunchedEffect(messages.lastOrNull()?.id) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex + (if (hasMore) 1 else 0)) }

    // محرر الصور/الفيديو قبل الإرسال
    editing?.let { (uri, isVideo) ->
        MediaEditorScreen(
            uri = uri, isVideo = isVideo,
            onDone = { em -> editing = null; queueMedia(em.bytes, em.name, em.mime, em.caption) },
            onCancel = { editing = null },
        )
        return
    }

    if (showMaker) {
        StickerMakerScreen(
            onClose = { showMaker = false },
            onSaved = { id, sendNow -> showMaker = false; if (sendNow) vm.sendStored(id, "sticker") },
        )
        return
    }

    val hapticFx = androidx.compose.ui.platform.LocalHapticFeedback.current
    val ctxFx = androidx.compose.ui.platform.LocalContext.current
    val ctxCS = androidx.compose.ui.platform.LocalContext.current
    var showStats by remember { mutableStateOf(false) }
    var showNote by remember { mutableStateOf(false) }
    var showMuteFor by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    if (showStats) ChatStatsDialog(peer) { showStats = false }
    if (showNote) NoteDialog(peer.id) { showNote = false }
    if (showMuteFor) MuteForDialog(peer.id) { showMuteFor = false }
    if (confirmClear) androidx.compose.material3.AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("مسح المحادثة؟") },
        text = { Text("الرسايل هتتمسح من عندك انت بس على الجهاز ده. الطرف التاني مش هيتأثر.") },
        confirmButton = { androidx.compose.material3.TextButton(onClick = { confirmClear = false; scope.launch { runCatching { ChatEngine.dao.deleteChat(peer.id) } } }) { Text("امسح") } },
        dismissButton = { androidx.compose.material3.TextButton(onClick = { confirmClear = false }) { Text("إلغاء") } },
    )
    val viewK = androidx.compose.ui.platform.LocalView.current
    androidx.compose.runtime.DisposableEffect(prefs.keepScreenOn) {
        viewK.keepScreenOn = prefs.keepScreenOn
        onDispose { viewK.keepScreenOn = false }
    }
    fun send() {
        if (text.isBlank()) return
        if (prefs.haptics) Haptic.click(ctxFx, hapticFx)
        val et = editTarget
        if (et != null) { vm.edit(et, text); editTarget = null } else vm.sendText(text, replyTo)
        replyTo = null; text = ""
    }

    Scaffold(
        topBar = {
            Column {
            GlassTopBar(
                navigationIcon = { IconButton(onClick = onBack) { Icon(AIcons.ArrowBack, "رجوع") } },
                title = {
                    if (searchOn) OutlinedTextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        placeholder = { Text("ابحث في المحادثة") }, modifier = Modifier.fillMaxWidth(),
                    ) else Row(
                        Modifier.clip(RoundedCornerShape(16.dp)).clickable { if (vm.isGroup) showInfo = true else if (!isSp) showProfile = true },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Avatar(peer.avatarFileId, peer.displayName.ifBlank { peer.phone }, 38.dp)
                        Column(Modifier.padding(start = 10.dp)) {
                            Text((grp?.name ?: peer.displayName).ifBlank { peer.phone }, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                            Text(if (vm.isGroup) "${grp?.memberList()?.size ?: 0} أعضاء" else if (peer.id in typingSet) "بيكتب…" else if (online) "متصل الآن" else peer.username?.let { "@$it" } ?: peer.about, modifier = if (peer.id in typingSet) Modifier.breathe() else Modifier, style = MaterialTheme.typography.labelSmall, maxLines = 1,
                                color = if (peer.id in typingSet) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                            AppSettings.note(peer.id).takeIf { it.isNotBlank() }?.let { Text("📝 " + it, style = MaterialTheme.typography.labelSmall, maxLines = 1, color = MaterialTheme.colorScheme.tertiary) }
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { searchOn = !searchOn; query = "" }) {
                        Icon(if (searchOn) AIcons.Close else AIcons.Search, "بحث")
                    }
                    if (!vm.isGroup && peer.id != myId && !isSp) {
                        IconButton(onClick = { CallManager.startCall(peer.id, video = false) }) { Icon(AIcons.Call, "مكالمة صوت") }
                        IconButton(onClick = { CallManager.startCall(peer.id, video = true) }) { Icon(AIcons.Videocam, "مكالمة فيديو") }
                    } else if (vm.isGroup) {
                        if (grp?.adminId == myId) IconButton(onClick = { showAddMembers = true }) { Icon(AIcons.GroupAdd, "إضافة أعضاء") }
                        IconButton(onClick = { showInfo = true }) { Icon(AIcons.Group, "معلومات المجموعة") }
                    }
                    IconButton(onClick = { moreMenu = true }) { Icon(AIcons.MoreVert, "المزيد") }
                    DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                        DropdownMenuItem(
                            text = { Text(if (starOnly) "عرض كل الرسايل" else "⭐ الرسايل المميّزة بنجمة") },
                            onClick = { moreMenu = false; starOnly = !starOnly },
                        )
                        DropdownMenuItem(
                            text = { Text(if (silentMode) "🔔 إلغاء الإرسال الصامت" else "🔕 إرسال صامت (من غير إشعار)") },
                            onClick = { moreMenu = false; silentMode = !silentMode; vm.silent = silentMode },
                        )
                        DropdownMenuItem(text = { Text("📊 إحصائيات المحادثة") }, onClick = { moreMenu = false; showStats = true })
                        if (!vm.isGroup && peer.id != myId) DropdownMenuItem(text = { Text("📝 ملاحظة خاصة") }, onClick = { moreMenu = false; showNote = true })
                        DropdownMenuItem(text = { Text("🔕 كتم مؤقت") }, onClick = { moreMenu = false; showMuteFor = true })
                        if (!vm.isGroup && peer.id != myId) DropdownMenuItem(text = { Text("🔗 نسخ لينك الشخص") }, onClick = { moreMenu = false; copyText(ctxCS, com.binarybeast.chatapp.data.Invites.user(peer)) })
                        DropdownMenuItem(text = { Text("🧹 مسح المحادثة عندي") }, onClick = { moreMenu = false; confirmClear = true })
                        if (!vm.isGroup && peer.id != myId) DropdownMenuItem(
                            text = { Text("⏳ مسح تلقائي للرسايل") },
                            onClick = { moreMenu = false; ttlPick = true },
                        )
                        if (!vm.isGroup && peer.id != myId) DropdownMenuItem(
                            text = { Text(if (storiesHidden) "👁 إظهار ستوريزي له" else "🙈 إخفاء ستوريزي عنه") },
                            onClick = {
                                moreMenu = false
                                val target = !storiesHidden
                                storiesHidden = target
                                scopeMenu.launch { runCatching { com.binarybeast.chatapp.data.ContactSync.setHidden(peer.id, target) }.onFailure { storiesHidden = !target } }
                            },
                        )
                        if (vm.isGroup) DropdownMenuItem(
                            text = { Text("🤖 بوتات المجموعة") },
                            onClick = { moreMenu = false; showGroupBots = true },
                        )
                        DropdownMenuItem(
                            text = { Text("⚡ ردود سريعة") },
                            onClick = { moreMenu = false; showQuick = true },
                        )
                        DropdownMenuItem(
                            text = { Text("🕒 جدولة الرسالة المكتوبة") },
                            onClick = { moreMenu = false; if (text.isNotBlank() && !isSp) schedPick = true },
                        )
                        DropdownMenuItem(
                            text = { Text("الرسايل المجدولة") },
                            onClick = { moreMenu = false; schedList = true },
                        )
                        DropdownMenuItem(
                            text = { Text("تصدير المحادثة") },
                            onClick = {
                                moreMenu = false
                                val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                                val txt = messages.filter { it.mediaType != "system" }.joinToString("\n") { m ->
                                    val who = if (m.mine) "أنا" else if (vm.isGroup) (names[m.senderId] ?: "؟") else (peer.displayName.ifBlank { peer.phone })
                                    val body = m.previewText()
                                    "[${fmt.format(java.util.Date(m.createdAt))}] $who: $body"
                                }
                                runCatching {
                                    // ملف نصي كامل (من غير حد على عدد الرسايل ولا حجم Intent)
                                    val dir = java.io.File(ctx.cacheDir, "exports").also { it.mkdirs() }
                                    val f = java.io.File(dir, "chat_${System.currentTimeMillis()}.txt").also { it.writeText(txt) }
                                    val uri = androidx.core.content.FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
                                    ctx.startActivity(
                                        android.content.Intent.createChooser(
                                            android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain")
                                                .putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                                .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION),
                                            "تصدير المحادثة",
                                        ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                    )
                                }
                            },
                        )
                        if (!vm.isGroup) DropdownMenuItem(
                            text = { Text("التحقق من التشفير") },
                            onClick = { moreMenu = false; showSafety = true },
                        )
                        if (!vm.isGroup) DropdownMenuItem(
                            text = { Text(if (blocked) "إلغاء الحظر" else "حظر") },
                            onClick = { moreMenu = false; if (blocked) AppSettings.unblock(peer.id) else AppSettings.block(peer.id) },
                        )
                    }
                },
            )
            messages.lastOrNull { it.pinned && !it.deleted }?.let { pm ->
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp).glass(barShape())
                        .clickable { scope.launch { val ix = shown.indexOfFirst { it.id == pm.id }; if (ix >= 0) listState.animateScrollToItem(ix + (if (hasMore) 1 else 0)) } }
                        .padding(start = 14.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(AIcons.PushPin, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                    Text(pm.previewText(), Modifier.weight(1f).padding(horizontal = 8.dp, vertical = 8.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                    IconButton(onClick = { scope.launch { ChatEngine.togglePin(pm) } }, modifier = Modifier.size(32.dp)) { Icon(AIcons.Close, "إلغاء التثبيت", Modifier.size(16.dp)) }
                }
            }
            }
        },
        bottomBar = {
            Surface(color = androidx.compose.ui.graphics.Color.Transparent) {
                Column {
                    if (blocked) Text(
                        "المستخدم ده محظور: مش هتوصلك رسايله ومكالماته.",
                        Modifier.fillMaxWidth().padding(8.dp), color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.labelMedium,
                    )
                    (editTarget ?: replyTo)?.let { t ->
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (editTarget != null) AIcons.Edit else AIcons.Reply, null, tint = MaterialTheme.colorScheme.primary)
                            Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                                Text(if (editTarget != null) "تعديل الرسالة" else "رد على", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                Text(t.previewText(), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { editTarget = null; replyTo = null; text = "" }) { Icon(AIcons.Close, "إلغاء") }
                        }
                    }
                    notice?.let { Text(it, Modifier.padding(horizontal = 12.dp), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelMedium) }
                                        if (recording) Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { recorder.cancel(); recording = false }) { Icon(AIcons.Delete, "إلغاء", tint = MaterialTheme.colorScheme.error) }
                        Text("● " + "%d:%02d".format(recMs / 60000, (recMs / 1000) % 60), Modifier.weight(1f), color = MaterialTheme.colorScheme.error)
                        GlassCircleButton(AIcons.Send, {
                            recording = false
                            val f = recorder.stop()
                            if (f != null) scope.launch {
                                val bytes = withContext(Dispatchers.IO) { f.readBytes().also { f.delete() } }
                                queueMedia(bytes, "voice.m4a", "audio/mp4", null)
                            }
                        }, size = 48.dp, accent = true, contentDescription = "إرسال")
                    } else Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        GlassCircleButton(AIcons.AttachFile, { attachMenu = true }, enabled = !sending, contentDescription = "إرفاق")
                        val sendLocation = rememberLocationSender(
                            onText = { t -> vm.sendText(t) },
                            onError = { m -> android.widget.Toast.makeText(ctxL2, m, android.widget.Toast.LENGTH_LONG).show() },
                        )
                        if (attachMenu) AttachSheet(
                            source = source, isGroup = vm.isGroup,
                            onPoll = { showPoll = true },
                            onLocation = sendLocation,
                            onRecent = { uri, isVideo -> editing = uri to isVideo },
                            onDismiss = { attachMenu = false },
                        )
                        if (showStickers) StickerSheet(
                            onSend = { id, kind -> showStickers = false; vm.sendStored(id, kind) },
                            onEmoji = { e -> text += e },
                            onMaker = { showMaker = true },
                            onDismiss = { showStickers = false },
                            draft = text, onBackspace = { text = dropLastGrapheme(text) }, onDraftSend = { send() },
                        )
                        GlassCircleButton(AIcons.Smile, { showStickers = true }, enabled = !sending, size = 40.dp, contentDescription = "ستيكرز")
                        OutlinedTextField(
                            value = text, onValueChange = { text = it; if (it.isNotBlank()) com.binarybeast.chatapp.data.ChatEngine.sendTyping(peer.id) },
                            placeholder = { Text(if (sending) "جاري الرفع…" else "اكتب رسالة") },
                            supportingText = { if (prefs.charCounter && text.length > 400) Text("${text.length}", style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.weight(1f), maxLines = 4,
                            shape = RoundedCornerShape(LocalStyle.current.radius.coerceAtMost(26.dp)),
                            colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = LocalPal.current.surfaceHi,
                                unfocusedContainerColor = LocalPal.current.surfaceHi,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = if (prefs.enterToSend) ImeAction.Send else ImeAction.Default),
                            keyboardActions = KeyboardActions(onSend = { send() }),
                        )
                        if (text.isBlank() && editTarget == null) GlassCircleButton(AIcons.Mic, {
                            if (recorder.start()) recording = true else vm.notice.value = "تعذّر بدء التسجيل (تأكد من إذن المايك)"
                        }, size = 48.dp, accent = true, enabled = !sending && !blocked, contentDescription = "تسجيل صوتي")
                        else GlassCircleButton(AIcons.Send, { send() }, size = 48.dp, accent = true, contentDescription = "إرسال")
                    }
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 10.dp),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            if (hasMore) item(key = "more") {
                androidx.compose.material3.TextButton(onClick = { vm.loadMore() }, modifier = Modifier.fillMaxWidth()) { Text("تحميل رسائل أقدم") }
            }
            items(shown, key = { it.id }) { m ->
                val mine = m.mine
                if (m.mediaType == "system") {
                    Text(m.body ?: "", Modifier.fillMaxWidth().padding(vertical = 4.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    return@items
                }
                // في RTL: Start = اليمين، فرسايلي على اليمين
                var dragX by remember(m.id) { mutableStateOf(0f) }
                // حذف: يطلع فوق شوية وينزل بسرعة وهو بيصغّر لحد ما يختفي
                val rp by animateFloatFast(if (m.id in removing) 1f else 0f, androidx.compose.animation.core.tween(420, easing = androidx.compose.animation.core.FastOutLinearInEasing), "rm")
                Row(
                    Modifier.fillMaxWidth()
                        .animateItem()
                        .graphicsLayer {
                            val p = rp
                            if (p > 0f) {
                                val up = 28f
                                translationY = (if (p < 0.25f) -up * (p / 0.25f) else -up + (p - 0.25f) / 0.75f * (up + 240f)) * density
                                val sc = (1f - p).coerceAtLeast(0f)
                                scaleX = sc; scaleY = sc; alpha = 1f - p * p
                            }
                        }
                        .offset { androidx.compose.ui.unit.IntOffset(dragX.toInt(), 0) }
                        .pointerInput(m.id) {
                            detectHorizontalDragGestures(
                                onDragEnd = { if (kotlin.math.abs(dragX) > 110f && !m.deleted) { replyTo = m; editTarget = null }; dragX = 0f },
                                onDragCancel = { dragX = 0f },
                            ) { _, d -> dragX = (dragX + d).coerceIn(-140f, 140f) }
                        },
                    horizontalArrangement = if (mine) Arrangement.Start else Arrangement.End,
                ) {
                    val st = LocalStyle.current
                    val pal = LocalPal.current
                    val bubbleShape = RoundedCornerShape(st.bubbleRadius)
                    val isSticker = m.mediaType == "sticker"
                    val bubbleColor = if (isSticker) Color.Transparent else if (mine) pal.bubbleOut else pal.bubbleIn
                    val bubbleBorder = if (isSticker) null else if (st.border > 0.dp) androidx.compose.foundation.BorderStroke(st.border, pal.line)
                                       else if (!mine) androidx.compose.foundation.BorderStroke(1.dp, pal.line.copy(alpha = 0.6f)) else null
                    CompositionLocalProvider(LocalContentColor provides (if (mine) pal.onBubbleOut else pal.text)) {
                    Surface(
                        shape = bubbleShape,
                        color = bubbleColor,
                        border = bubbleBorder,
                        modifier = Modifier.widthIn(max = 290.dp).enterBubble(fromStart = mine, key = m.msgId)
                            .combinedClickable(onClick = {}, onDoubleClick = { if (prefs.doubleTapLike && !m.deleted) { if (prefs.haptics) Haptic.click(ctxFx, hapticFx); vm.react(m, "❤️") } }, onLongClick = { if (!m.deleted) actionMsg = m }),
                    ) {
                        Column(Modifier.padding(8.dp)) {
                            if (vm.isGroup && !mine) Text(names[m.senderId] ?: "…", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                            if (false) Text("🚫", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            m.replyText?.let { rt ->
                                Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)) {
                                    Text(rt, Modifier.fillMaxWidth().padding(6.dp), maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium)
                                }
                            }
                            val fid = m.mediaFileId
                            val restricted = m.viewMode != 0 && m.mediaType in setOf("image", "video", "audio")
                            if (m.mediaType == "gone") Text("⏳ انتهت صلاحية الميديا", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (fid != null && restricted) {
                                val what = when (m.mediaType) { "image" -> "صورة"; "video" -> "فيديو"; else -> "صوت" }
                                val label = if (m.viewMode == 1) "👁 $what تتشاف مرة واحدة" else "⏱ $what مؤقتة (${fmtSecs(m.viewSecs)})"
                                Box(
                                    Modifier.fillMaxWidth().height(80.dp).clip(RoundedCornerShape(10.dp))
                                        .background(MaterialTheme.colorScheme.surface)
                                        .clickable(enabled = !mine) {
                                            scope.launch {
                                                val now = System.currentTimeMillis()
                                                val alreadyOpened = m.openedAt > 0
                                                val left = if (m.viewMode == 2) m.viewSecs - ((if (alreadyOpened) now - m.openedAt else 0L) / 1000).toInt() else 0
                                                if ((m.viewMode == 1 && alreadyOpened) || (m.viewMode == 2 && left <= 0)) ChatEngine.burn(m)
                                                else { ChatEngine.markOpened(m); restrictedView = m to left }
                                            }
                                        },
                                    contentAlignment = Alignment.Center,
                                ) { Text(if (mine) "🔒 $label" + (if (m.openedAt > 0) "\n✅ اتفتحت" else "") else "$label — اضغط للفتح", Modifier.padding(8.dp)) }
                            } else if (fid != null) when (m.mediaType) {
                                "image" -> {
                                    // لو "التحميل التلقائي" مقفول، الصورة مبتتحمّلش غير لما تدوس عليها
                                    var loaded by remember(m.id) { mutableStateOf(prefs.autoDownloadImages || mine) }
                                    if (loaded) TgImage(
                                        fid,
                                        Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(10.dp)).clickable { viewer = m },
                                        ContentScale.Crop,
                                    ) else Box(
                                        Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(10.dp))
                                            .background(MaterialTheme.colorScheme.surface).clickable { loaded = true },
                                        contentAlignment = Alignment.Center,
                                    ) { Text("📷 اضغط لتحميل الصورة") }
                                }
                                "video" -> Box(
                                    Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(10.dp))
                                        .background(MaterialTheme.colorScheme.surface).clickable { viewer = m },
                                    contentAlignment = Alignment.Center,
                                ) { Icon(AIcons.PlayCircle, "تشغيل", Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary) }
                                "audio" -> VoiceBubble(fid)
                                "sticker" -> TgImage(fid, Modifier.size(150.dp), ContentScale.Fit)
                                "gif" -> TgImage(fid, Modifier.size(width = 200.dp, height = 200.dp).clip(RoundedCornerShape(12.dp)), ContentScale.Fit)
                                else -> Text("📎 ملف", fontWeight = FontWeight.Medium)
                            }
                            if (m.mediaType == "poll" && !m.deleted) PollBubble(m, votes.filter { it.msgId == m.msgId }, myId) { idx -> vm.vote(m, idx) }
                            else if (!restricted && m.senderId?.startsWith("bot:") == true && botMsgList.any { it.id == -m.id }) GroupBotBody(botMsgList.first { it.id == -m.id }, MaterialTheme.colorScheme.onSurface) { d -> vm.pressGroupButton(botMsgList.first { it.id == -m.id }, d) }
                            else if (!restricted && prefs.bigEmoji && m.body?.let { isBigAnimEmoji(it) } == true) BigEmojiRow(m.body!!)
                            else if (!restricted) m.body?.let { LinkifiedText(it, style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface, fontSize = if (prefs.bigEmoji && isEmojiOnly(it)) 36.sp else MaterialTheme.typography.bodyMedium.fontSize, fontWeight = if (prefs.boldText) FontWeight.SemiBold else null)) }
                            translations[m.msgId]?.let { tt ->
                                Text(tt, Modifier.padding(top = 4.dp), style = MaterialTheme.typography.bodySmall.copy(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic), color = MaterialTheme.colorScheme.primary)
                            }
                            val rx = listOfNotNull(m.myReaction, m.theirReaction).distinct().joinToString("")
                            if (rx.isNotEmpty()) Text(rx, style = MaterialTheme.typography.bodyMedium)
                            Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                                if (m.starred) Text("⭐ ", style = MaterialTheme.typography.labelSmall)
                                if (m.edited) Text("معدّلة · ", style = MaterialTheme.typography.labelSmall)
                                Text(hhmmMs(m.createdAt), style = MaterialTheme.typography.labelSmall)
                                if (mine && !prefs.hideTicks) {
                                    Spacer(Modifier.size(4.dp))
                                    Box(Modifier.swell(m.status).shake(if (m.status == MsgStatus.FAILED) 1 else 0)) {
                                    when (m.status) {
                                        // ✓✓ أخضر = وصلت وجه تأكيد الاستلام
                                        MsgStatus.READ -> Icon(AIcons.DoneAll, null, Modifier.size(14.dp), tint = androidx.compose.ui.graphics.Color(0xFF2196F3))   // أزرق = اتقرت
                                        MsgStatus.DELIVERED -> Icon(AIcons.DoneAll, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                        // ✓ اتبعتت (صندوق احتياطي أو P2P بنستنى التأكيد)
                                        MsgStatus.SENT, MsgStatus.P2P_PENDING -> Icon(AIcons.Done, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                        MsgStatus.FAILED -> Text("!", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                                        else -> Text("🕓", style = MaterialTheme.typography.labelSmall)   // لسه بتتبعت (النت ضعيف) — بتتعاد لوحدها
                                    }
                                    }
                                }
                            }
                        }
                    }
                    }
                }
            }
        }
        val atBottom by remember { androidx.compose.runtime.derivedStateOf { listState.firstVisibleItemIndex + listState.layoutInfo.visibleItemsInfo.size >= listState.layoutInfo.totalItemsCount - 1 } }
        androidx.compose.animation.AnimatedVisibility(
            visible = !atBottom && shown.size > 6,
            modifier = Modifier.align(Alignment.BottomEnd).padding(14.dp),
            enter = androidx.compose.animation.scaleIn() + androidx.compose.animation.fadeIn(),
            exit = androidx.compose.animation.scaleOut() + androidx.compose.animation.fadeOut(),
        ) {
            GlassCircleButton(AIcons.ArrowDown, { scope.launch { listState.animateScrollToItem((shown.size - 1 + (if (hasMore) 1 else 0)).coerceAtLeast(0)) } }, size = 44.dp, contentDescription = "لآخر رسالة")
        }
        }
    }

    if (showPoll) {
        var q by remember { mutableStateOf("") }
        var opts by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPoll = false },
            title = { Text("استطلاع جديد") },
            text = {
                Column {
                    OutlinedTextField(value = q, onValueChange = { q = it }, label = { Text("السؤال") })
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = opts, onValueChange = { opts = it }, label = { Text("الاختيارات (كل واحد في سطر، 2 إلى 20)") }, minLines = 3)
                }
            },
            confirmButton = { TextButton(onClick = { vm.sendPoll(q, opts.lines()); showPoll = false }) { Text("إرسال") } },
            dismissButton = { TextButton(onClick = { showPoll = false }) { Text("إلغاء") } },
        )
    }

    if (showQuick) {
        val qr by com.binarybeast.chatapp.data.QuickReplies.items.collectAsState()
        var newQ by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showQuick = false },
            title = { Text("ردود سريعة") },
            text = {
                Column {
                    qr.forEach { q ->
                        Row(Modifier.fillMaxWidth().clickable { text = if (text.isBlank()) q else text.trimEnd() + " " + q; showQuick = false }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(Lang.raw(q), Modifier.weight(1f))
                            IconButton(onClick = { com.binarybeast.chatapp.data.QuickReplies.remove(q) }, modifier = Modifier.size(32.dp)) { Icon(AIcons.Close, "حذف", Modifier.size(16.dp)) }
                        }
                    }
                    OutlinedTextField(newQ, { newQ = it }, singleLine = true, label = { Text("رد جديد") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = { TextButton(enabled = newQ.isNotBlank(), onClick = { com.binarybeast.chatapp.data.QuickReplies.add(newQ); newQ = "" }) { Text("إضافة") } },
            dismissButton = { TextButton(onClick = { showQuick = false }) { Text("إغلاق") } },
        )
    }

    val gNow = grp
    if (showProfile) PeerProfileDialog(peer, myId) { showProfile = false }

    if (showInfo && gNow != null) GroupProfileDialog(
        group = gNow, myId = myId, names = names,
        onRename = { vm.renameGroup(it) },
        onAvatar = { b, m -> vm.setGroupAvatar(b, m) },
        onAdd = { vm.addMembers(it) },
        onAddProfiles = { vm.addProfiles(it) },
        inviteLink = linkVer.let { com.binarybeast.chatapp.data.Invites.group(gNow) },
        onResetLink = { com.binarybeast.chatapp.data.Invites.reset(gNow.groupId); linkVer++ },
        onRemove = { vm.removeMember(it) },
        onTtl = { vm.setTtl(it) },
        onLeave = { showInfo = false; vm.leaveGroup(onBack) },
        onClose = { showInfo = false },
    )
    if (showGroupBots) GroupBotsDialog(
        groupId = peer.id.removePrefix("g:"), title = grp?.name ?: "", bots = groupBotsNow,
        onChanged = { vm.refreshGroupBots() }, onClose = { showGroupBots = false },
    )
    botNotice?.let { t ->
        androidx.compose.material3.AlertDialog(onDismissRequest = { vm.botNotice.value = null }, text = { androidx.compose.material3.Text(t) },
            confirmButton = { TextButton(onClick = { vm.botNotice.value = null }) { Text("تمام") } })
    }
    if (showAddMembers) AddMembersDialog(onAdd = { vm.addMembers(it) }, onClose = { showAddMembers = false })

    actionMsg?.let { m ->
        AlertDialog(
            onDismissRequest = { actionMsg = null },
            confirmButton = {},
            text = {
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        listOf("👍", "❤️", "😂", "😮", "😢", "🙏").forEach { e ->
                            Text(e, Modifier.clickable { vm.react(m, e); actionMsg = null }.padding(6.dp), style = MaterialTheme.typography.headlineSmall)
                        }
                    }
                    TextButton(onClick = { replyTo = m; editTarget = null; actionMsg = null }) { Icon(AIcons.Reply, null); Text("  رد") }
                    if (com.binarybeast.chatapp.data.Invites.parse(m.body) != null) TextButton(onClick = { InviteHandler.open(ctx, m.body ?: "", scope); actionMsg = null }) { Text("🔗  فتح الدعوة") }
                    m.body?.let { b ->
                        TextButton(onClick = { clipboard.setText(AnnotatedString(b)); actionMsg = null }) { Icon(AIcons.ContentCopy, null); Text("  نسخ") }
                    }
                    if (m.mediaType != "poll" && m.mediaType != "system" && !m.body.isNullOrBlank()) TextButton(onClick = {
                        val id = m.msgId; val b = m.body ?: ""; actionMsg = null
                        if (translations.containsKey(id)) translations.remove(id)
                        else scope.launch {
                            translations[id] = "جاري الترجمة…"
                            translations[id] = runCatching { com.binarybeast.chatapp.data.MsgTranslator.translate(b, uiLang) }
                                .map { (t, _) -> Lang.raw(t) }.getOrElse { "تعذّرت الترجمة (محتاج إنترنت مرة واحدة لتحميل اللغة)" }
                        }
                    }) { Text("  ترجمة") }
                    if (m.mine && m.mediaFileId == null && m.body != null) TextButton(onClick = {
                        editTarget = m; replyTo = null; text = m.body ?: ""; actionMsg = null
                    }) { Icon(AIcons.Edit, null); Text("  تعديل") }
                    if (m.mediaType != "poll" && m.mediaType != "system" && m.mediaType != "gone" && m.viewMode == 0) {
                        TextButton(onClick = { forwardMsg = m; actionMsg = null }) { Icon(AIcons.Reply, null); Text("  تحويل") }
                        if (peer.id != myId) TextButton(onClick = {
                            scope.launch { ChatEngine.send(ChatEngine.savedProfile(), m.body, m.mediaFileId, m.mediaType) }; actionMsg = null
                        }) { Text("🔖  حفظ في رسايلي المحفوظة") }
                    }
                    if (m.mediaType == "sticker" || m.mediaType == "gif") m.mediaFileId?.let { fid0 ->
                        TextButton(onClick = { com.binarybeast.chatapp.data.StickerStore.add(fid0, m.mediaType ?: "sticker"); actionMsg = null }) { Text("🏷  حفظ في ${if (m.mediaType == "gif") "الـGIF" else "الستيكرات"}") }
                    }
                    if (m.mediaType != "system" && m.mediaType != "gone") TextButton(onClick = { scope.launch { ChatEngine.togglePin(m) }; actionMsg = null }) { Icon(AIcons.PushPin, null); Text(if (m.pinned) "  إلغاء التثبيت" else "  تثبيت") }
                    if (m.mediaType != "system" && m.mediaType != "gone") TextButton(onClick = { scope.launch { ChatEngine.toggleStar(m) }; actionMsg = null }) { Text(if (m.starred) "☆  شيل النجمة" else "⭐  نجمة") }
                    if (m.mediaType != "system" && m.mediaType != "gone") TextButton(onClick = { infoMsg = m; actionMsg = null }) { Text("ℹ️  معلومات الرسالة") }
                    TextButton(onClick = { confirmDelete = m; actionMsg = null }) { Icon(AIcons.Delete, null); Text("  حذف") }
                }
            },
        )
    }

    infoMsg?.let { im ->
        val f = java.text.SimpleDateFormat("EEEE d MMM yyyy - HH:mm:ss", java.util.Locale.getDefault())
        val st = when (im.status) {
            com.binarybeast.chatapp.data.local.MsgStatus.READ -> "اتقرت ✓✓"
            com.binarybeast.chatapp.data.local.MsgStatus.DELIVERED -> "وصلت ✓✓"
            com.binarybeast.chatapp.data.local.MsgStatus.SENT, com.binarybeast.chatapp.data.local.MsgStatus.P2P_PENDING -> "اتبعتت ✓"
            com.binarybeast.chatapp.data.local.MsgStatus.FAILED -> "فشل الإرسال"
            else -> "بتتبعت…"
        }
        AlertDialog(
            onDismissRequest = { infoMsg = null },
            confirmButton = { TextButton(onClick = { infoMsg = null }) { Text("تمام") } },
            title = { Text("معلومات الرسالة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text((if (im.mine) "اتبعتت: " else "اتستلمت: ") + f.format(java.util.Date(im.createdAt)))
                    if (im.mine) Text("الحالة: $st")
                    if (im.edited) Text("اتعدّلت")
                    if (im.expireAt > 0) Text("بتتمسح تلقائيًا: " + f.format(java.util.Date(im.expireAt)))
                    if (im.pinned) Text("مثبّتة")
                    if (im.starred) Text("عليها نجمة")
                }
            },
        )
    }

    forwardMsg?.let { fm ->
        AlertDialog(
            onDismissRequest = { forwardMsg = null },
            title = { Text("تحويل إلى") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    allChats.filter { it.peer.id != myId }.forEach { c ->
                        TextButton(onClick = {
                            scope.launch { ChatEngine.send(c.peer, fm.body, fm.mediaFileId, fm.mediaType) }
                            forwardMsg = null
                        }) { Text(c.peer.displayName.ifBlank { c.peer.phone }) }
                    }
                    if (allChats.none { it.peer.id != myId }) Text("مفيش محادثات تانية.")
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { forwardMsg = null }) { Text("إلغاء") } },
        )
    }

    confirmDelete?.let { m ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("حذف الرسالة") },
            text = { Text(if (m.mine) "تتمسح عندك بس، أو عند الطرفين؟" else "هتتمسح من عندك بس.") },
            confirmButton = {
                if (m.mine) TextButton(onClick = { confirmDelete = null; scope.launch { removing.add(m.id); kotlinx.coroutines.delay(440); vm.deleteForEveryone(m); removing.remove(m.id) } }) { Text("عند الطرفين") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = null; scope.launch { removing.add(m.id); kotlinx.coroutines.delay(440); vm.deleteForMe(m); removing.remove(m.id) } }) { Text("عندي بس") }
            },
        )
    }

    viewer?.let { m ->
        MediaViewer(m.mediaFileId ?: "", m.mediaType ?: "image", m.body, onClose = { viewer = null })
    }
}


/** مشغّل رسالة صوتية: بينزّل الملف من تيليجرام (مرة واحدة) ويشغّله بـ MediaPlayer. */
@Composable
private fun VoiceBubble(fileId: String) {
    var player by remember(fileId) { mutableStateOf<android.media.MediaPlayer?>(null) }
    var playing by remember(fileId) { mutableStateOf(false) }
    var loading by remember(fileId) { mutableStateOf(false) }
    var speed by remember(fileId) { mutableStateOf(1f) }
    fun applySpeed(p: android.media.MediaPlayer) { runCatching { p.playbackParams = p.playbackParams.setSpeed(speed) } }
    val scope = rememberCoroutineScope()
    androidx.compose.runtime.DisposableEffect(fileId) { onDispose { runCatching { player?.release() } } }

    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(enabled = !loading, onClick = {
            val p = player
            if (p != null) {
                if (playing) { p.pause(); playing = false } else { p.start(); applySpeed(p); playing = true }
            } else scope.launch {
                loading = true
                runCatching {
                    val f = TelegramStorage.download(fileId)
                    val mp = android.media.MediaPlayer()
                    mp.setDataSource(f.absolutePath)
                    mp.setOnCompletionListener { playing = false; runCatching { it.seekTo(0) } }
                    withContext(Dispatchers.IO) { mp.prepare() }
                    mp.start(); applySpeed(mp); player = mp; playing = true
                }
                loading = false
            }
        }) { Icon(if (playing) AIcons.Pause else AIcons.PlayCircle, "تشغيل", tint = MaterialTheme.colorScheme.primary) }
        Text(if (loading) "جاري التحميل…" else "🎤 رسالة صوتية", Modifier.weight(1f, fill = false))
        Text(
            if (speed == 1f) "1×" else if (speed == 1.5f) "1.5×" else "2×",
            Modifier.padding(start = 8.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f))
                .clickable {
                    speed = when (speed) { 1f -> 1.5f; 1.5f -> 2f; else -> 1f }
                    player?.let { if (playing) applySpeed(it) }
                }.padding(horizontal = 8.dp, vertical = 3.dp),
            style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold,
        )
    }
}


/** استطلاع: بيعرض الاختيارات وعدد الأصوات؛ الضغط على اختيار بيصوّت (والتصويت تاني بيغيّر اختيارك). */
@Composable
private fun PollBubble(m: LocalMessage, votes: List<com.binarybeast.chatapp.data.local.PollVote>, myId: String?, onVote: (Int) -> Unit) {
    val (question, options) = remember(m.body) {
        runCatching {
            val j = org.json.JSONObject(m.body ?: "{}")
            val arr = j.getJSONArray("o")
            j.optString("q") to List(arr.length()) { arr.getString(it) }
        }.getOrDefault("" to emptyList())
    }
    val total = votes.size.coerceAtLeast(1)
    Column {
        Text("📊 $question", fontWeight = FontWeight.SemiBold)
        options.forEachIndexed { i, label ->
            val count = votes.count { it.option == i }
            val mine = votes.any { it.voterId == myId && it.option == i }
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (mine) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp).clickable { onVote(i) },
            ) {
                Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text((if (mine) "✓ " else "") + label, Modifier.weight(1f))
                    Text("$count (${count * 100 / total}%)", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}


// ======================================================================= ميديا مرة واحدة / مؤقّتة

private class MediaDraft(val bytes: ByteArray, val name: String, val mime: String, val caption: String?)

private fun fmtSecs(s: Int): String = when {
    s < 60 -> "$s ث"
    s < 3600 -> "${s / 60} د"
    s < 86400 -> "${s / 3600} س"
    else -> "${s / 86400} يوم"
}

@Composable
private fun ViewModeDialog(onCancel: () -> Unit, onSend: (mode: Int, secs: Int) -> Unit) {
    var mode by remember { mutableStateOf(0) }
    var secs by remember { mutableStateOf(30) }
    var custom by remember { mutableStateOf("") }
    val presets = listOf(10 to "10 ث", 30 to "30 ث", 60 to "دقيقة", 3600 to "ساعة", 86400 to "24 ساعة")
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("طريقة العرض عند الطرف التاني") },
        text = {
            Column {
                @Composable fun opt(m: Int, label: String, sub: String) = Row(
                    Modifier.fillMaxWidth().clickable { mode = m }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    androidx.compose.material3.RadioButton(selected = mode == m, onClick = { mode = m })
                    Column { Text(label, fontWeight = FontWeight.SemiBold); Text(sub, style = MaterialTheme.typography.bodySmall) }
                }
                opt(0, "عادي", "يفضل في المحادثة")
                opt(1, "👁 مرة واحدة", "يتشاف مرة واحدة وبعدها بيتشال أول ما يقفله")
                opt(2, "⏱ مؤقّت", "بيتشال بعد المدة دي من أول ما يفتحه")
                if (mode == 2) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
                        presets.take(3).forEach { (v, l) ->
                            androidx.compose.material3.FilterChip(selected = custom.isBlank() && secs == v, onClick = { secs = v; custom = "" }, label = { Text(l) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        presets.drop(3).forEach { (v, l) ->
                            androidx.compose.material3.FilterChip(selected = custom.isBlank() && secs == v, onClick = { secs = v; custom = "" }, label = { Text(l) })
                        }
                    }
                    OutlinedTextField(
                        custom, { custom = it.filter(Char::isDigit).take(6) }, singleLine = true,
                        label = { Text("أو اكتب عدد الثواني") }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                    )
                }
                if (mode != 0) Text("بيتمنع تحويلها وحفظها، ولقطات الشاشة بتتقفل وقت العرض. (الملف نفسه بيفضل في تخزين تيليجرام بتاعك.)",
                    Modifier.padding(top = 8.dp), style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = { onSend(mode, (custom.toIntOrNull() ?: secs).coerceIn(1, 7 * 86400)) }) { Text("إرسال") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("إلغاء") } },
    )
}

/** عارض الميديا المقيّدة: لقطات الشاشة مقفولة، ولو مؤقّت بيتقفل لوحده لما الوقت يخلص. */
@Composable
private fun RestrictedViewer(m: LocalMessage, secsLeft: Int, onClose: () -> Unit) {
    var left by remember { mutableStateOf(secsLeft) }
    val timed = m.viewMode == 2
    LaunchedEffect(Unit) {
        if (!timed) return@LaunchedEffect
        while (left > 0) { kotlinx.coroutines.delay(1000); left-- }
        onClose()
    }
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onClose,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
    ) {
        (androidx.compose.ui.platform.LocalView.current.parent as? androidx.compose.ui.window.DialogWindowProvider)
            ?.window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black)) {
            val fid = m.mediaFileId
            if (fid != null) when (m.mediaType) {
                "video" -> TgVideoPlayer(fid, Modifier.fillMaxSize())
                "audio" -> Box(Modifier.fillMaxSize(), Alignment.Center) { VoiceBubble(fid) }
                else -> TgImage(fid, Modifier.fillMaxSize(), ContentScale.Fit)
            }
            m.body?.takeIf { it.isNotBlank() }?.let {
                Text(it, Modifier.align(Alignment.BottomCenter).padding(24.dp), color = androidx.compose.ui.graphics.Color.White)
            }
            Text(
                if (timed) "⏱ ${fmtSecs(left)}" else "👁 مرة واحدة",
                Modifier.align(Alignment.TopCenter).padding(16.dp), color = androidx.compose.ui.graphics.Color.White,
            )
            IconButton(onClick = onClose, modifier = Modifier.align(Alignment.TopStart).padding(8.dp)) {
                Icon(AIcons.Close, "إغلاق", tint = androidx.compose.ui.graphics.Color.White)
            }
        }
    }
}


/** عنوان الشاشة الرئيسية: «جاري الاتصال…» لحد ما الاتصال يتفتح، وبعدها لوجو واسم التطبيق. */
@Composable
private fun ConnectionTitle() {
    val rt by com.binarybeast.chatapp.data.Supa.client.realtime.status.collectAsState()
    val st by com.binarybeast.chatapp.data.AuthRepository.sessionStatus
        .collectAsState(initial = io.github.jan.supabase.auth.status.SessionStatus.Initializing)
    val connected = rt == io.github.jan.supabase.realtime.Realtime.Status.CONNECTED &&
        st is io.github.jan.supabase.auth.status.SessionStatus.Authenticated
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (connected) {
            androidx.compose.foundation.Image(
                androidx.compose.ui.res.painterResource(com.binarybeast.chatapp.R.drawable.logo), null,
                Modifier.size(28.dp).enterBounce().clip(RoundedCornerShape(8.dp)),
            )
            androidx.compose.material3.Text(
                androidx.compose.ui.res.stringResource(com.binarybeast.chatapp.R.string.app_name),
                Modifier.padding(start = 8.dp), fontWeight = FontWeight.Bold,
            )
        } else {
            androidx.compose.material3.CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
            Text("جاري الاتصال…", Modifier.padding(start = 8.dp).breathe(), fontWeight = FontWeight.Bold)
        }
    }
}


/** رسالة إيموجي بس (لحد ١٦ حرف من غير حروف/أرقام/ASCII). */
fun isEmojiOnly(t: String): Boolean {
    val x = t.trim()
    return x.isNotEmpty() && x.length <= 16 && x.none { it.isLetterOrDigit() || (it.code < 128 && !it.isWhitespace()) }
}
