package com.binarybeast.chatapp.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binarybeast.chatapp.data.AppSettings
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * مكتبة الحركات (أكتر من 40 أنيميشن مختلف). كلها بتحترم إعداد «الأنيميشن» (لو مقفول بتتحوّل لعرض ثابت).
 * التصنيفات:
 *  دخول (15)  : enterFade, enterSlideUp, enterSlideDown, enterSlideStart, enterSlideEnd, enterPop, enterBounce, enterZoom,
 *               enterRotate, enterFlipY, enterFlipX, enterDrop, enterSwing, enterUnfold, enterBubble
 *  ضغط (5)    : pressDip, pressSquash, pressTilt, pressGlow, pressLift
 *  تنبيه مستمر (9) : pulse, breathe, wiggle, floatY, spin, heartbeat, blink, pendulum, glowRing
 *  حدث (7)    : shake, tada, jelly, rubberBand, flash, hop, swell
 *  شاشات/أخرى : shimmer, TypingDots, CountUpText, TypewriterText, SlideNumber, SparkleBurst, RisingEmoji, AnimatedGradientBox, RadarRipple
 *  انتقالات (8)   : Transitions.*
 *  ظهور/اختفاء (8): Vis.pairs
 */
object Motion {
    val on: Boolean get() = AppSettings.now.animations
    /** عناصر اتعرضلها أنيميشن دخول قبل كده في الجلسة (علشان القوايم متعيدش الحركة كل ما تعمل scroll). */
    internal val seen: MutableSet<Any> = java.util.Collections.synchronizedSet(HashSet())
}

// ============================================================= دخول

@Composable
private fun rememberEnter(delayMs: Int, key: Any?, spec: AnimationSpec<Float>): Animatable<Float, androidx.compose.animation.core.AnimationVector1D> {
    val skip = !Motion.on || (key != null && key in Motion.seen)
    val a = remember { Animatable(if (skip) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (!skip) {
            if (delayMs > 0) delay(delayMs.toLong())
            a.animateTo(1f, spec)
            if (key != null) Motion.seen.add(key)
        }
    }
    return a
}

private val smooth = tween<Float>(320, easing = FastOutSlowInEasing)

@Composable fun Modifier.enterFade(delayMs: Int = 0, key: Any? = null): Modifier {
    val a = rememberEnter(delayMs, key, tween(300))
    return graphicsLayer { alpha = a.value }
}
@Composable fun Modifier.enterSlideUp(delayMs: Int = 0, key: Any? = null): Modifier {
    val a = rememberEnter(delayMs, key, smooth)
    return graphicsLayer { translationY = (1f - a.value) * 28.dp.toPx(); alpha = a.value }
}
@Composable fun Modifier.enterSlideDown(delayMs: Int = 0, key: Any? = null): Modifier {
    val a = rememberEnter(delayMs, key, smooth)
    return graphicsLayer { translationY = -(1f - a.value) * 28.dp.toPx(); alpha = a.value }
}
/** من جهة بداية الشاشة (يمين في العربي). */
@Composable fun Modifier.enterSlideStart(delayMs: Int = 0, key: Any? = null): Modifier {
    val a = rememberEnter(delayMs, key, smooth)
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    return graphicsLayer {
        val s = if (rtl) 1f else -1f
        translationX = s * (1f - a.value) * 40.dp.toPx(); alpha = a.value
    }
}
@Composable fun Modifier.enterSlideEnd(delayMs: Int = 0, key: Any? = null): Modifier {
    val a = rememberEnter(delayMs, key, smooth)
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    return graphicsLayer {
        val s = if (rtl) -1f else 1f
        translationX = s * (1f - a.value) * 40.dp.toPx(); alpha = a.value
    }
}
@Composable fun Modifier.enterPop(delayMs: Int = 0, key: Any? = null): Modifier {
    val a = rememberEnter(delayMs, key, spring(dampingRatio = 0.5f, stiffness = 420f))
    return graphicsLayer { val s = 0.6f + 0.4f * a.value; scaleX = s; scaleY = s; alpha = a.value.coerceIn(0f, 1f) }
}
@Composable fun Modifier.enterBounce(delayMs: Int = 0, key: Any? = null): Modifier {
    val a = rememberEnter(delayMs, key, spring(dampingRatio = 0.32f, stiffness = 260f))
    return graphicsLayer { scaleX = a.value; scaleY = a.value; alpha = (a.value * 3f).coerceIn(0f, 1f) }
}
@Composable fun Modifier.enterZoom(delayMs: Int = 0, key: Any? = null): Modifier {
    val a = rememberEnter(delayMs, key, smooth)
    return graphicsLayer { val s = 1.35f - 0.35f * a.value; scaleX = s; scaleY = s; alpha = a.value }
}
@Composable fun Modifier.enterRotate(delayMs: Int = 0, key: Any? = null): Modifier {
    val a = rememberEnter(delayMs, key, tween(420, easing = FastOutSlowInEasing))
    return graphicsLayer { rotationZ = -90f * (1f - a.value); alpha = a.value; val s = 0.7f + 0.3f * a.value; scaleX = s; scaleY = s }
}
@Composable fun Modifier.enterFlipY(delayMs: Int = 0, key: Any? = null): Modifier {
    val a = rememberEnter(delayMs, key, tween(450, easing = FastOutSlowInEasing))
    return graphicsLayer { rotationY = 90f * (1f - a.value); cameraDistance = 12f * density; alpha = a.value }
}
@Composable fun Modifier.enterFlipX(delayMs: Int = 0, key: Any? = null): Modifier {
    val a = rememberEnter(delayMs, key, tween(450, easing = FastOutSlowInEasing))
    return graphicsLayer { rotationX = -90f * (1f - a.value); cameraDistance = 12f * density; alpha = a.value }
}
@Composable fun Modifier.enterDrop(delayMs: Int = 0, key: Any? = null): Modifier {
    val a = rememberEnter(delayMs, key, spring(dampingRatio = 0.45f, stiffness = 300f))
    return graphicsLayer { translationY = -(1f - a.value) * 90.dp.toPx(); alpha = a.value.coerceIn(0f, 1f) }
}
@Composable fun Modifier.enterSwing(delayMs: Int = 0, key: Any? = null): Modifier {
    val a = rememberEnter(delayMs, key, spring(dampingRatio = 0.3f, stiffness = 120f))
    return graphicsLayer { transformOrigin = TransformOrigin(0.5f, 0f); rotationZ = 22f * (1f - a.value); alpha = a.value.coerceIn(0f, 1f) }
}
@Composable fun Modifier.enterUnfold(delayMs: Int = 0, key: Any? = null): Modifier {
    val a = rememberEnter(delayMs, key, tween(380, easing = FastOutSlowInEasing))
    return graphicsLayer { transformOrigin = TransformOrigin(0.5f, 0f); scaleY = a.value; alpha = a.value }
}
/** فقاعة رسالة: بتنزلق من جهة صاحبها وتكبر بنطّة خفيفة. */
@Composable fun Modifier.enterBubble(fromStart: Boolean, key: Any? = null): Modifier {
    val a = rememberEnter(0, key, spring(dampingRatio = 0.62f, stiffness = 380f))
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    return graphicsLayer {
        val s = if (fromStart == rtl) 1f else -1f
        translationX = s * (1f - a.value) * 36.dp.toPx(); translationY = (1f - a.value) * 10.dp.toPx()
        val sc = 0.85f + 0.15f * a.value; scaleX = sc; scaleY = sc; alpha = a.value.coerceIn(0f, 1f)
        transformOrigin = TransformOrigin(if (fromStart == rtl) 1f else 0f, 1f)
    }
}

// ============================================================= ضغط

enum class PressKind { Dip, Squash, Tilt, Glow, Lift }

@Composable
fun Modifier.pressEffect(kind: PressKind, enabled: Boolean = true, role: Role? = Role.Button, onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val p by androidx.compose.animation.core.animateFloatAsState(
        if (pressed && Motion.on) 1f else 0f, spring(dampingRatio = 0.45f, stiffness = 600f), label = "press",
    )
    return this.graphicsLayer {
        when (kind) {
            PressKind.Dip -> { scaleX = 1f - 0.07f * p; scaleY = 1f - 0.07f * p }
            PressKind.Squash -> { scaleX = 1f + 0.08f * p; scaleY = 1f - 0.10f * p }
            PressKind.Tilt -> { rotationZ = 4f * p; scaleX = 1f - 0.04f * p; scaleY = 1f - 0.04f * p }
            PressKind.Glow -> { alpha = 1f - 0.4f * p }
            PressKind.Lift -> { translationY = -3.dp.toPx() * p; scaleX = 1f + 0.04f * p; scaleY = 1f + 0.04f * p }
        }
    }.clickable(interactionSource = src, indication = null, enabled = enabled, role = role, onClick = onClick)
}

// ============================================================= تنبيه مستمر (بنستخدمه بحرص: عناصر صغيرة بس)

@Composable
private fun loop(from: Float, to: Float, ms: Int, reverse: Boolean = true, easing: androidx.compose.animation.core.Easing = FastOutSlowInEasing, delayMs: Int = 0) =
    rememberInfiniteTransition(label = "loop").animateFloat(
        from, to,
        infiniteRepeatable(tween(ms, easing = easing), if (reverse) RepeatMode.Reverse else RepeatMode.Restart, StartOffset(delayMs)),
        label = "v",
    )

@Composable fun Modifier.pulse(to: Float = 1.08f, ms: Int = 900): Modifier {
    if (!Motion.on) return this
    val t = loop(1f, to, ms); return graphicsLayer { scaleX = t.value; scaleY = t.value }
}
@Composable fun Modifier.breathe(min: Float = 0.55f, ms: Int = 1400): Modifier {
    if (!Motion.on) return this
    val t = loop(1f, min, ms); return graphicsLayer { alpha = t.value }
}
@Composable fun Modifier.wiggle(deg: Float = 6f, ms: Int = 260): Modifier {
    if (!Motion.on) return this
    val t = loop(-deg, deg, ms); return graphicsLayer { rotationZ = t.value }
}
@Composable fun Modifier.floatY(dp: Float = 6f, ms: Int = 1600): Modifier {
    if (!Motion.on) return this
    val t = loop(0f, dp, ms); return graphicsLayer { translationY = -t.value.dp.toPx() }
}
@Composable fun Modifier.spin(ms: Int = 2400): Modifier {
    if (!Motion.on) return this
    val t = loop(0f, 360f, ms, reverse = false, easing = LinearEasing); return graphicsLayer { rotationZ = t.value }
}
@Composable fun Modifier.heartbeat(ms: Int = 1000): Modifier {
    if (!Motion.on) return this
    val t = rememberInfiniteTransition(label = "hb").animateFloat(
        1f, 1f,
        infiniteRepeatable(keyframes { durationMillis = ms; 1f at 0; 1.18f at ms / 8; 1f at ms / 4; 1.12f at ms * 3 / 8; 1f at ms / 2; 1f at ms }),
        label = "v",
    )
    return graphicsLayer { scaleX = t.value; scaleY = t.value }
}
@Composable fun Modifier.blink(ms: Int = 700): Modifier {
    if (!Motion.on) return this
    val t = loop(1f, 0.15f, ms, easing = LinearEasing); return graphicsLayer { alpha = t.value }
}
@Composable fun Modifier.pendulum(deg: Float = 12f, ms: Int = 1200): Modifier {
    if (!Motion.on) return this
    val t = loop(-deg, deg, ms); return graphicsLayer { transformOrigin = TransformOrigin(0.5f, 0f); rotationZ = t.value }
}
/** حلقة بتنبض حوالين العنصر (للأفاتار اللي عنده ستوري جديدة، ونقطة «متصل»). */
@Composable fun Modifier.glowRing(color: Color, ms: Int = 1200): Modifier {
    if (!Motion.on) return this
    val t = loop(0f, 1f, ms, reverse = false, easing = LinearEasing)
    return drawWithContent {
        drawContent()
        val r = size.minDimension / 2f
        drawCircle(color.copy(alpha = (1f - t.value) * 0.55f), radius = r + r * 0.35f * t.value, style = Stroke(width = 2.dp.toPx()))
    }
}

// ============================================================= أحداث (بتتشغّل لما trigger يتغيّر)

@Composable
private fun rememberBurst(trigger: Int, ms: Int): Animatable<Float, androidx.compose.animation.core.AnimationVector1D> {
    val a = remember { Animatable(1f) }
    val first = remember { booleanArrayOf(true) }
    LaunchedEffect(trigger) {
        val skip = first[0]; first[0] = false
        if (!skip && trigger != 0 && Motion.on) { a.snapTo(0f); a.animateTo(1f, tween(ms, easing = LinearEasing)) }
    }
    return a
}
@Composable fun Modifier.shake(trigger: Int): Modifier {
    val a = rememberBurst(trigger, 480)
    return graphicsLayer { translationX = sin(a.value * PI.toFloat() * 7f) * (1f - a.value) * 12.dp.toPx() }
}
@Composable fun Modifier.tada(trigger: Int): Modifier {
    val a = rememberBurst(trigger, 700)
    return graphicsLayer {
        val k = (1f - a.value)
        val s = 1f + 0.18f * sin(a.value * PI.toFloat()) ; scaleX = s; scaleY = s
        rotationZ = sin(a.value * PI.toFloat() * 8f) * 6f * k
    }
}
@Composable fun Modifier.jelly(trigger: Int): Modifier {
    val a = rememberBurst(trigger, 700)
    return graphicsLayer {
        val k = (1f - a.value)
        scaleX = 1f + 0.25f * sin(a.value * PI.toFloat() * 5f) * k
        scaleY = 1f - 0.25f * sin(a.value * PI.toFloat() * 5f) * k
    }
}
@Composable fun Modifier.rubberBand(trigger: Int): Modifier {
    val a = rememberBurst(trigger, 800)
    return graphicsLayer {
        val k = (1f - a.value)
        scaleX = 1f + 0.35f * sin(a.value * PI.toFloat() * 3f) * k
        scaleY = 1f - 0.2f * sin(a.value * PI.toFloat() * 3f) * k
    }
}
@Composable fun Modifier.flash(trigger: Int): Modifier {
    val a = rememberBurst(trigger, 700)
    return graphicsLayer { alpha = 0.25f + 0.75f * abs(cos(a.value * PI.toFloat() * 3f)) }
}
@Composable fun Modifier.hop(trigger: Int): Modifier {
    val a = rememberBurst(trigger, 650)
    return graphicsLayer { translationY = -abs(sin(a.value * PI.toFloat() * 2f)) * (1f - a.value) * 22.dp.toPx() }
}
/** انتفاخ مرة واحدة (مثلًا لما رقم يزيد). */
@Composable fun Modifier.swell(trigger: Int): Modifier {
    val a = rememberBurst(trigger, 380)
    return graphicsLayer { val s = 1f + 0.35f * sin(a.value * PI.toFloat()); scaleX = s; scaleY = s }
}

// ============================================================= لمعان تحميل
@Composable fun Modifier.shimmer(): Modifier {
    if (!Motion.on) return this
    val t = loop(0f, 1f, 1300, reverse = false, easing = LinearEasing)
    return drawWithContent {
        drawContent()
        val w = size.width
        val x = -w + 2f * w * t.value
        drawRect(Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.35f), Color.Transparent), Offset(x, 0f), Offset(x + w * 0.7f, size.height * 0.3f)))
    }
}

// ============================================================= مكوّنات متحركة

/** «بيكتب…» بنقط بتتموّج. */
@Composable
fun TypingDots(color: Color = MaterialTheme.colorScheme.primary, dot: Int = 5) {
    Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(3) { i ->
            val t = if (Motion.on) rememberInfiniteTransition(label = "dot$i").animateFloat(
                0f, 1f, infiniteRepeatable(keyframes { durationMillis = 900; 0f at 0; 1f at 200; 0f at 400; 0f at 900 }, initialStartOffset = StartOffset(i * 140)), label = "v",
            ) else null
            Box(Modifier.size(dot.dp).graphicsLayer { translationY = -(t?.value ?: 0f) * 4.dp.toPx() }.clip(CircleShape).background(color))
        }
    }
}

/** رقم بيعدّ من الصفر للقيمة. */
@Composable
fun CountUpText(target: Int, modifier: Modifier = Modifier, ms: Int = 900, fontSize: Int = 20) {
    val v by animateIntAsState(if (Motion.on) target else target, tween(if (Motion.on) ms else 0), label = "count")
    androidx.compose.material3.Text(v.toString(), modifier, fontSize = fontSize.sp, fontWeight = FontWeight.Bold)
}

/** نص بيتكتب حرف حرف. */
@Composable
fun TypewriterText(text: String, modifier: Modifier = Modifier, perCharMs: Long = 35) {
    var n by remember(text) { mutableIntStateOf(if (Motion.on) 0 else text.length) }
    LaunchedEffect(text) { if (Motion.on) { n = 0; while (n < text.length) { delay(perCharMs); n++ } } }
    androidx.compose.material3.Text(text.take(n), modifier)
}

/** رقم بيتزحلق لفوق/تحت لما يتغيّر (عدّاد الغير مقروء). */
@Composable
fun SlideNumber(value: Int, modifier: Modifier = Modifier, color: Color = Color.Unspecified, fontSize: Int = 12) {
    AnimatedContent(
        targetState = value, modifier = modifier, label = "num",
        transitionSpec = {
            if (targetState > initialState) (slideInVertically { -it } + fadeIn()) togetherWith (slideOutVertically { it } + fadeOut())
            else (slideInVertically { it } + fadeIn()) togetherWith (slideOutVertically { -it } + fadeOut())
        },
    ) { n -> androidx.compose.material3.Text(n.toString(), color = color, fontSize = fontSize.sp) }
}

/** انفجار شرارات صغيرة حوالين العنصر لما trigger يتغيّر. */
@Composable
fun SparkleBurst(trigger: Int, color: Color = MaterialTheme.colorScheme.primary, modifier: Modifier = Modifier.size(48.dp)) {
    val a = rememberBurst(trigger, 700)
    Canvas(modifier) {
        if (a.value >= 1f) return@Canvas
        val c = Offset(size.width / 2, size.height / 2)
        val r = size.minDimension / 2f
        for (i in 0 until 12) {
            val ang = i * (2 * PI / 12).toFloat()
            val d = r * (0.3f + 0.9f * a.value)
            drawCircle(color.copy(alpha = 1f - a.value), radius = (if (i % 2 == 0) 3f else 2f).dp.toPx() * (1f - a.value * 0.5f),
                center = Offset(c.x + cos(ang) * d, c.y + sin(ang) * d))
        }
    }
}

/** إيموجي بيطلع لفوق ويختفي (تفاعل على ستوري). */
@Composable
fun RisingEmoji(emoji: String, onEnd: () -> Unit = {}) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(if (Motion.on) 1300 else 1, easing = FastOutSlowInEasing)); onEnd() }
    androidx.compose.material3.Text(
        emoji, fontSize = 40.sp,
        modifier = Modifier.graphicsLayer {
            translationY = -a.value * 260.dp.toPx(); alpha = 1f - a.value
            val s = 1f + 0.6f * a.value; scaleX = s; scaleY = s; rotationZ = sin(a.value * PI.toFloat() * 3f) * 10f
        },
    )
}

/** خلفية بتدرّج بيتحرك ببطء. */
@Composable
fun AnimatedGradientBox(colors: List<Color>, modifier: Modifier = Modifier, content: @Composable () -> Unit = {}) {
    val t = if (Motion.on) loop(0f, 1f, 5000) else null
    Box(
        modifier.drawWithContent {
            val k = t?.value ?: 0f
            drawRect(Brush.linearGradient(colors, Offset(size.width * k, 0f), Offset(size.width * (1f + k), size.height)))
            drawContent()
        },
    ) { content() }
}

/** دوايرة بتتوسّع وتختفي (زي رادار) — مكالمة جاية/اتصال. */
@Composable
fun RadarRipple(color: Color = MaterialTheme.colorScheme.primary, modifier: Modifier = Modifier.size(80.dp)) {
    val t = if (Motion.on) loop(0f, 1f, 1800, reverse = false, easing = LinearEasing) else null
    val t2 = if (Motion.on) loop(0f, 1f, 1800, reverse = false, easing = LinearEasing, delayMs = 900) else null
    Canvas(modifier) {
        val r = size.minDimension / 2f
        listOf(t, t2).forEach { s ->
            val v = s?.value ?: return@forEach
            drawCircle(color.copy(alpha = (1f - v) * 0.5f), radius = r * v, style = Stroke(width = 2.dp.toPx()))
        }
        drawCircle(color.copy(alpha = 0.9f), radius = r * 0.22f)
    }
}

/** هيكل تحميل (skeleton) بلمعان. */
@Composable
fun SkeletonRow(modifier: Modifier = Modifier) {
    val base = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
    Row(modifier.fillMaxWidth().padding(16.dp).shimmer(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(52.dp).clip(CircleShape).background(base))
        Column(Modifier.padding(start = 12.dp)) {
            Box(Modifier.fillMaxWidth(0.5f).height(12.dp).clip(RoundedCornerShape(6.dp)).background(base))
            Box(Modifier.padding(top = 8.dp).fillMaxWidth(0.8f).height(10.dp).clip(RoundedCornerShape(6.dp)).background(base))
        }
    }
}

// ============================================================= انتقالات الشاشات (8)

object Transitions {
    private fun <T> t(ms: Int) = tween<T>(ms, easing = FastOutSlowInEasing)
    fun fadeThrough(): ContentTransform = (fadeIn(t(240)) + scaleIn(t(240), initialScale = 0.96f)) togetherWith fadeOut(t(120))
    fun sharedAxisX(forward: Boolean): ContentTransform {
        val s = if (forward) 1 else -1
        return (slideInHorizontally(t(300)) { s * it / 4 } + fadeIn(t(260))) togetherWith (slideOutHorizontally(t(300)) { -s * it / 4 } + fadeOut(t(160)))
    }
    fun sharedAxisY(forward: Boolean): ContentTransform {
        val s = if (forward) 1 else -1
        return (slideInVertically(t(300)) { s * it / 10 } + fadeIn(t(260))) togetherWith (slideOutVertically(t(300)) { -s * it / 10 } + fadeOut(t(160)))
    }
    fun zoomThrough(): ContentTransform = (scaleIn(t(320), initialScale = 0.8f) + fadeIn(t(280))) togetherWith (scaleOut(t(260), targetScale = 1.12f) + fadeOut(t(200)))
    fun slideOver(): ContentTransform = slideInHorizontally(t(320)) { it } togetherWith (slideOutHorizontally(t(320)) { -it / 4 } + fadeOut(t(260)))
    fun riseUp(): ContentTransform = (slideInVertically(t(340)) { it } + fadeIn(t(200))) togetherWith (fadeOut(t(200)) + scaleOut(t(260), targetScale = 0.94f))
    fun dropDown(): ContentTransform = (slideInVertically(t(340)) { -it } + fadeIn(t(200))) togetherWith (slideOutVertically(t(260)) { it / 3 } + fadeOut(t(200)))
    fun springPop(): ContentTransform = (scaleIn(spring(0.55f, 380f), initialScale = 0.6f) + fadeIn(t(160))) togetherWith (scaleOut(t(160), targetScale = 0.9f) + fadeOut(t(140)))
}

// ============================================================= ظهور/اختفاء (8) لـ AnimatedVisibility
object Vis {
    val fadeSlideUp = (fadeIn() + slideInVertically { it / 2 }) to (fadeOut() + slideOutVertically { it / 2 })
    val scaleFade = (scaleIn(initialScale = 0.7f) + fadeIn()) to (scaleOut(targetScale = 0.7f) + fadeOut())
    val expandV = (expandVertically() + fadeIn()) to (shrinkVertically() + fadeOut())
    val slideH = (slideInHorizontally { it } + fadeIn()) to (slideOutHorizontally { it } + fadeOut())
    val bounceScale = scaleIn(spring(0.4f, 400f), initialScale = 0.3f) to scaleOut(targetScale = 0.3f)
    val dropIn = (slideInVertically(spring(0.5f, 300f)) { -it }) to (slideOutVertically { -it } + fadeOut())
    val zoomOut = (scaleIn(initialScale = 1.4f) + fadeIn()) to (scaleOut(targetScale = 1.4f) + fadeOut())
    val fadeOnly = fadeIn(tween(300)) to fadeOut(tween(200))
    val all: List<Pair<String, Pair<EnterTransition, ExitTransition>>> get() = listOf(
        "fadeSlideUp" to fadeSlideUp, "scaleFade" to scaleFade, "expandV" to expandV, "slideH" to slideH,
        "bounceScale" to bounceScale, "dropIn" to dropIn, "zoomOut" to zoomOut, "fadeOnly" to fadeOnly,
    )
}
