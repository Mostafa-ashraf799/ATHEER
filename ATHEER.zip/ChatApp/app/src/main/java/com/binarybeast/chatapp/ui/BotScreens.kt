package com.binarybeast.chatapp.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.binarybeast.chatapp.data.AuthRepository
import com.binarybeast.chatapp.data.BotInfo
import com.binarybeast.chatapp.data.BotMsg
import com.binarybeast.chatapp.data.BotRepository
import com.binarybeast.chatapp.data.Channel
import com.binarybeast.chatapp.data.inlineButtons
import com.binarybeast.chatapp.data.replyKeyboard
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ============================================================ تنسيق نص البوت (HTML / Markdown زي تيليجرام)

private class FmtSpan(val s: Int, val e: Int, val style: SpanStyle?, val url: String?)

private fun spanStyleOf(k: String): SpanStyle? = when (k) {
    "b" -> SpanStyle(fontWeight = FontWeight.Bold)
    "i" -> SpanStyle(fontStyle = FontStyle.Italic)
    "u" -> SpanStyle(textDecoration = TextDecoration.Underline)
    "s" -> SpanStyle(textDecoration = TextDecoration.LineThrough)
    "c" -> SpanStyle(fontFamily = FontFamily.Monospace, background = Color(0x33888888))
    else -> null
}

private fun unhtml(s: String) = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").replace("&amp;", "&")

/** يحوّل النص + parse_mode (HTML أو MarkdownV2) لنص منسّق. من غير parse_mode بيتعرض زي ما هو. */
fun formatBotText(raw: String, mode: String?, linkColor: Color): AnnotatedString {
    if (mode == null) return AnnotatedString(raw)
    val sb = StringBuilder()
    val spans = ArrayList<FmtSpan>()
    val open = HashMap<String, Int>()
    fun openK(k: String) { if (k !in open) open[k] = sb.length }
    fun closeK(k: String) { val st = open.remove(k) ?: return; if (sb.length > st) spans += FmtSpan(st, sb.length, spanStyleOf(k), null) }
    fun toggle(k: String) { if (k in open) closeK(k) else openK(k) }
    fun link(start: Int, url: String) { if (sb.length > start) spans += FmtSpan(start, sb.length, SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline), url) }

    if (mode == "HTML") {
        val re = Regex("<(/?)([a-zA-Z]+)([^>]*)>")
        var i = 0
        var href: String? = null
        var linkStart = 0
        for (m in re.findAll(raw)) {
            sb.append(unhtml(raw.substring(i, m.range.first))); i = m.range.last + 1
            val close = m.groupValues[1] == "/"
            val key = when (m.groupValues[2].lowercase()) {
                "b", "strong" -> "b"; "i", "em" -> "i"; "u", "ins" -> "u"; "s", "strike", "del" -> "s"
                "code", "pre" -> "c"; "a" -> "a"; "br" -> "br"; else -> null
            }
            when (key) {
                null -> {}
                "br" -> sb.append('\n')
                "a" -> if (!close) {
                    href = Regex("href\\s*=\\s*[\"']([^\"']+)[\"']").find(m.groupValues[3])?.groupValues?.get(1); linkStart = sb.length
                } else { href?.let { link(linkStart, it) }; href = null }
                else -> key?.let { k -> if (close) closeK(k) else openK(k) }
            }
        }
        sb.append(unhtml(raw.substring(i)))
    } else {
        var i = 0
        while (i < raw.length) {
            val c = raw[i]
            if (c == '\\' && i + 1 < raw.length) { sb.append(raw[i + 1]); i += 2; continue }
            if (raw.startsWith("```", i)) {
                val end = raw.indexOf("```", i + 3)
                if (end > 0) {
                    var body = raw.substring(i + 3, end)
                    val nl = body.indexOf('\n')
                    if (nl >= 0 && body.substring(0, nl).matches(Regex("[A-Za-z0-9_+-]*"))) body = body.substring(nl + 1)
                    val st = sb.length; sb.append(body.trimEnd('\n'))
                    if (sb.length > st) spans += FmtSpan(st, sb.length, spanStyleOf("c"), null)
                    i = end + 3; continue
                }
            }
            if ("c" in open && c != '`') { sb.append(c); i++; continue }
            when (c) {
                '`' -> { toggle("c"); i++ }
                '*' -> { toggle("b"); i++ }
                '~' -> { toggle("s"); i++ }
                '_' -> if (i + 1 < raw.length && raw[i + 1] == '_') { toggle("u"); i += 2 } else { toggle("i"); i++ }
                '|' -> if (i + 1 < raw.length && raw[i + 1] == '|') i += 2 else { sb.append(c); i++ }
                '[' -> {
                    val mid = raw.indexOf("](", i)
                    val end = if (mid > 0) raw.indexOf(')', mid) else -1
                    if (mid > 0 && end > 0 && !raw.substring(i, mid).contains('\n')) {
                        val st = sb.length; sb.append(raw.substring(i + 1, mid)); link(st, raw.substring(mid + 2, end)); i = end + 1
                    } else { sb.append(c); i++ }
                }
                else -> { sb.append(c); i++ }
            }
        }
    }
    open.keys.toList().forEach { closeK(it) }
    return buildAnnotatedString {
        append(sb.toString())
        spans.forEach { sp ->
            sp.style?.let { addStyle(it, sp.s, sp.e) }
            sp.url?.let { addStringAnnotation("URL", it, sp.s, sp.e) }
        }
    }
}

@Composable
fun BotText(text: String, mode: String?, color: Color, modifier: Modifier = Modifier) {
    val open = LocalOpenLink.current
    val link = MaterialTheme.colorScheme.primary
    val ann = remember(text, mode, link) { formatBotText(text, mode, link) }
    ClickableText(
        ann, modifier, style = LocalTextStyle.current.copy(color = color),
        onClick = { off -> ann.getStringAnnotations("URL", off, off).firstOrNull()?.let { open(it.item) } },
    )
}

// ============================================================ شكل ملكة النحل 🐝👑

private fun hexPath(cx: Float, cy: Float, r: Float): Path = Path().apply {
    for (k in 0..5) {
        val a = (PI / 3 * k + PI / 6).toFloat()
        val x = cx + r * cos(a); val y = cy + r * sin(a)
        if (k == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

private fun DrawScope.drawQueenBee() {
    val s = size.width
    // خلفية ملكية بنفسجي + خلايا نحل دهبية خفيفة
    drawRect(Brush.radialGradient(listOf(Color(0xFF8E24AA), Color(0xFF4A148C), Color(0xFF240A4F)), center = Offset(s * 0.35f, s * 0.3f), radius = s * 0.95f))
    val hr = s * 0.13f
    val dx = hr * 1.732f
    for (row in -1..8) for (col in -1..8) {
        val cx = col * dx + if (row % 2 != 0) dx / 2 else 0f
        val cy = row * hr * 1.5f
        drawPath(hexPath(cx, cy, hr * 0.92f), Color(0xFFFFC107).copy(alpha = 0.16f), style = Stroke(width = s * 0.008f))
    }
    // أجنحة
    val wingFill = Color.White.copy(alpha = 0.82f)
    val wingStroke = Color(0xFFB3E5FC)
    rotate(-28f, Offset(s * 0.5f, s * 0.6f)) {
        drawOval(wingFill, Offset(s * 0.12f, s * 0.36f), Size(s * 0.30f, s * 0.2f))
        drawOval(wingStroke, Offset(s * 0.12f, s * 0.36f), Size(s * 0.30f, s * 0.2f), style = Stroke(s * 0.012f))
    }
    rotate(28f, Offset(s * 0.5f, s * 0.6f)) {
        drawOval(wingFill, Offset(s * 0.58f, s * 0.36f), Size(s * 0.30f, s * 0.2f))
        drawOval(wingStroke, Offset(s * 0.58f, s * 0.36f), Size(s * 0.30f, s * 0.2f), style = Stroke(s * 0.012f))
    }
    // الجسم (دهبي بخطوط غامقة)
    val body = Path().apply { addOval(androidx.compose.ui.geometry.Rect(Offset(s * 0.30f, s * 0.50f), Size(s * 0.40f, s * 0.36f))) }
    drawPath(body, Color(0xFFFFC107))
    clipPath(body) {
        drawRect(Color(0xFF3E2723), Offset(s * 0.30f, s * 0.62f), Size(s * 0.40f, s * 0.055f))
        drawRect(Color(0xFF3E2723), Offset(s * 0.30f, s * 0.73f), Size(s * 0.40f, s * 0.055f))
    }
    drawPath(body, Color(0xFF3E2723), style = Stroke(s * 0.014f))
    // الراس + العيون
    drawCircle(Color(0xFF3E2723), s * 0.115f, Offset(s * 0.5f, s * 0.47f))
    drawCircle(Color.White, s * 0.026f, Offset(s * 0.465f, s * 0.465f))
    drawCircle(Color.White, s * 0.026f, Offset(s * 0.535f, s * 0.465f))
    drawCircle(Color(0xFF3E2723), s * 0.012f, Offset(s * 0.468f, s * 0.468f))
    drawCircle(Color(0xFF3E2723), s * 0.012f, Offset(s * 0.538f, s * 0.468f))
    // قرون الاستشعار
    drawLine(Color(0xFFFFD54F), Offset(s * 0.46f, s * 0.38f), Offset(s * 0.40f, s * 0.30f), s * 0.012f)
    drawLine(Color(0xFFFFD54F), Offset(s * 0.54f, s * 0.38f), Offset(s * 0.60f, s * 0.30f), s * 0.012f)
    // التاج
    val crown = Path().apply {
        moveTo(s * 0.37f, s * 0.385f); lineTo(s * 0.385f, s * 0.20f); lineTo(s * 0.445f, s * 0.29f); lineTo(s * 0.5f, s * 0.15f)
        lineTo(s * 0.555f, s * 0.29f); lineTo(s * 0.615f, s * 0.20f); lineTo(s * 0.63f, s * 0.385f); close()
    }
    drawPath(crown, Brush.verticalGradient(listOf(Color(0xFFFFF176), Color(0xFFFFB300)), startY = s * 0.15f, endY = s * 0.39f))
    drawPath(crown, Color(0xFFFF8F00), style = Stroke(s * 0.012f))
    drawCircle(Color(0xFFE53935), s * 0.019f, Offset(s * 0.385f, s * 0.205f))
    drawCircle(Color(0xFF29B6F6), s * 0.022f, Offset(s * 0.5f, s * 0.16f))
    drawCircle(Color(0xFFE53935), s * 0.019f, Offset(s * 0.615f, s * 0.205f))
}

@Composable
fun BeeQueenAvatar(size: Dp = 48.dp) {
    Canvas(Modifier.size(size).clip(CircleShape)) { drawQueenBee() }
}

@Composable
fun BotAvatar(bot: BotInfo, size: Dp = 44.dp) {
    if (bot.isQueenBee) BeeQueenAvatar(size)
    else if (!bot.avatarUrl.isNullOrBlank()) coil.compose.AsyncImage(
        model = bot.avatarUrl, contentDescription = null, modifier = Modifier.size(size).clip(CircleShape), contentScale = ContentScale.Crop,
    )
    else if (bot.isMaker) Box(Modifier.size(size).clip(CircleShape).background(Color(0xFF1E88E5)), Alignment.Center) {
        androidx.compose.material3.Text("⚙️", style = MaterialTheme.typography.titleMedium)
    }
    else Box(Modifier.size(size).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)), Alignment.Center) {
        androidx.compose.material3.Text("🤖", style = MaterialTheme.typography.titleMedium)
    }
}

// ============================================================ أزرار inline

@Composable
private fun InlineKeyboard(markup: kotlinx.serialization.json.JsonObject?, busyKey: String?, keyPrefix: String, onPress: (String, String) -> Unit) {
    val open = LocalOpenLink.current
    val rows = remember(markup) { markup.inlineButtons() }
    if (rows.isEmpty()) return
    Column(Modifier.widthIn(max = 320.dp).padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        rows.forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                row.forEach { b ->
                    val k = keyPrefix + ":" + (b.data ?: b.url)
                    OutlinedButton(
                        onClick = { if (b.url != null) open(b.url) else if (b.data != null) onPress(k, b.data) },
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        enabled = busyKey != k,
                    ) {
                        androidx.compose.material3.Text(if (b.url != null) b.text + " ↗" else b.text, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }
}

// ============================================================ شاشة محادثة البوت

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BotChatScreen(bot: BotInfo, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var msgs by remember { mutableStateOf<List<BotMsg>>(emptyList()) }
    var text by remember { mutableStateOf("") }
    var fastUntil by remember { mutableStateOf(0L) }
    var busyKey by remember { mutableStateOf<String?>(null) }
    var alertText by remember { mutableStateOf<String?>(null) }
    var menu by remember { mutableStateOf(false) }
    var showCmds by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val reload: suspend () -> Unit = {
        runCatching { BotRepository.messages(bot.id) }.onSuccess { if (it != msgs) msgs = it }
    }
    LaunchedEffect(bot.id) {
        while (true) { reload(); delay(if (System.currentTimeMillis() < fastUntil) 700 else 3000) }
    }
    LaunchedEffect(msgs.lastOrNull()?.id, msgs.lastOrNull()?.text?.length) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex)
    }
    // كيبورد الرد: آخر رسالة من البوت فيها keyboard (أو remove_keyboard)
    val replyKb = remember(msgs) {
        msgs.lastOrNull { it.fromBot && it.replyMarkup != null && (it.replyMarkup.containsKey("keyboard") || it.replyMarkup.containsKey("remove_keyboard")) }
            ?.replyMarkup.replyKeyboard()
    }
    val waiting = msgs.lastOrNull()?.fromBot == false && System.currentTimeMillis() < fastUntil + 30_000

    fun send(t: String) {
        val s = t.trim(); if (s.isEmpty()) return
        msgs = msgs + BotMsg(id = -System.nanoTime(), fromBot = false, text = s)
        fastUntil = System.currentTimeMillis() + 25_000
        scope.launch {
            runCatching { BotRepository.send(bot.id, s) }.onFailure { alertText = it.message ?: "تعذّر الإرسال" }
            reload()
        }
    }
    fun press(m: BotMsg, key: String, data: String) {
        if (m.id < 0) return
        busyKey = key
        scope.launch {
            val ans = runCatching { BotRepository.press(bot.id, m.id, data) }.onFailure { alertText = it.message }.getOrNull()
            busyKey = null
            fastUntil = System.currentTimeMillis() + 8_000
            ans?.answerText?.let { t ->
                if (ans.answerAlert) alertText = t else android.widget.Toast.makeText(ctx, t, android.widget.Toast.LENGTH_SHORT).show()
            }
            reload()
        }
    }

    Scaffold(
        topBar = {
            GlassTopBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BotAvatar(bot, 38.dp)
                        Column(Modifier.padding(start = 10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                androidx.compose.material3.Text(bot.name, maxLines = 1, fontWeight = FontWeight.Bold)
                                Surface(Modifier.padding(start = 6.dp), shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)) {
                                    Text("بوت", Modifier.padding(horizontal = 6.dp, vertical = 1.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                            Text(if (waiting) "بيكتب…" else "@${bot.username}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(AIcons.ArrowBack, "رجوع") } },
                actions = {
                    IconButton(onClick = { menu = true }) { Icon(AIcons.MoreVert, "المزيد") }
                    androidx.compose.material3.DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        androidx.compose.material3.DropdownMenuItem(text = { Text("مسح المحادثة") }, onClick = {
                            menu = false; scope.launch { runCatching { BotRepository.clearChat(bot.id) }; reload() }
                        })
                        androidx.compose.material3.DropdownMenuItem(text = { Text("عن البوت") }, onClick = { menu = false; alertText = listOf("@${bot.username}", bot.description, bot.about).filter { it.isNotBlank() }.joinToString("\n\n") })
                    }
                },
            )
        },
        bottomBar = {
            Column(Modifier.fillMaxWidth().navigationBarsPadding().imePadding()) {
                val cmdFilter = text.removePrefix("/")
                val cmds = bot.commands.filter { showCmds || (text.startsWith("/") && it.command.startsWith(cmdFilter.lowercase())) }
                if (cmds.isNotEmpty() && (showCmds || text.startsWith("/"))) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp))) {
                        cmds.take(8).forEach { c ->
                            Row(Modifier.fillMaxWidth().clickable { showCmds = false; text = ""; send("/" + c.command) }.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                Text(Lang.raw("/" + c.command), fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                                Text(Lang.raw(c.description), Modifier.padding(start = 10.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
                if (replyKb.isNotEmpty()) Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    replyKb.forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            row.forEach { label ->
                                Button(onClick = { send(label) }, Modifier.weight(1f), shape = RoundedCornerShape(10.dp),
                                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 6.dp)) {
                                    androidx.compose.material3.Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (bot.commands.isNotEmpty()) TextButton(onClick = { showCmds = !showCmds }) { androidx.compose.material3.Text("/") }
                    OutlinedTextField(
                        text, { text = it.take(4096); if (!it.startsWith("/")) showCmds = showCmds }, Modifier.weight(1f),
                        placeholder = { Text("اكتب رسالة…") }, maxLines = 5,
                    )
                    IconButton(enabled = text.isNotBlank(), onClick = { val t = text; text = ""; showCmds = false; send(t) }) { Icon(AIcons.Send, "إرسال") }
                }
            }
        },
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(), state = listState,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (msgs.isEmpty()) item {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    BotAvatar(bot, 88.dp)
                    Text(bot.name, Modifier.padding(top = 12.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    if (bot.about.isNotBlank()) Text(bot.about, Modifier.padding(top = 4.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = { send("/start") }, Modifier.padding(top = 16.dp)) { Text("ابدأ") }
                }
            }
            items(msgs, key = { it.id }) { m ->
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (m.fromBot) Alignment.End else Alignment.Start) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (m.fromBot) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.widthIn(max = 320.dp),
                    ) {
                        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                            m.photoUrl?.let { u ->
                                coil.compose.AsyncImage(u, null, Modifier.fillMaxWidth().padding(bottom = 6.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.FillWidth)
                            }
                            m.text?.let {
                                val c = if (m.fromBot) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onPrimaryContainer
                                if (m.fromBot) BotText(it, m.parseMode, c) else androidx.compose.material3.Text(it, color = c)
                            }
                            Text(
                                (if (m.edited) "معدّلة · " else "") + hhmm(m.createdAt), Modifier.align(Alignment.End).padding(top = 2.dp),
                                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    if (m.fromBot) InlineKeyboard(m.replyMarkup, busyKey, "m${m.id}") { k, d -> press(m, k, d) }
                }
            }
            if (waiting) item { Text("🐝 …", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }

    alertText?.let { t ->
        AlertDialog(onDismissRequest = { alertText = null }, text = { androidx.compose.material3.Text(t) },
            confirmButton = { TextButton(onClick = { alertText = null }) { Text("تمام") } })
    }
}

// ============================================================ كل البوتات + إنشاء بوت

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BotsScreen(onBack: () -> Unit, onOpen: (BotInfo) -> Unit) {
    BackHandler(onBack = onBack)
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val me = AuthRepository.currentUserId
    var q by remember { mutableStateOf("") }
    var found by remember { mutableStateOf<BotInfo?>(null) }
    var mine by remember { mutableStateOf<List<BotInfo>>(emptyList()) }
    var tick by remember { mutableStateOf(0) }
    var creating by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var newUser by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var tokenShown by remember { mutableStateOf<Pair<String, String>?>(null) }   // username → token
    var manage by remember { mutableStateOf<BotInfo?>(null) }

    LaunchedEffect(q) {
        delay(300)
        found = if (q.isBlank()) null else runCatching { BotRepository.byUsername(q) }.getOrNull()
    }
    LaunchedEffect(tick) { mine = runCatching { BotRepository.mine() }.getOrDefault(emptyList()) }

    Scaffold(
        topBar = {
            GlassTopBar(
                title = { Text("البوتات", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(AIcons.ArrowBack, "رجوع") } },
                actions = { TextButton(onClick = { creating = true; err = null }) { Text("إنشاء بوت") } },
            )
        },
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            item {
                OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("اكتب يوزرنيم البوت بالظبط (@username)") })
            }
            found?.let { fb -> item(key = "f" + fb.id) { BotRow(fb, onClick = { onOpen(fb) }, onManage = null) } }
            if (q.isNotBlank() && found == null) item { Text("مفيش بوت باليوزرنيم ده. البوتات بتظهر بالبحث باليوزرنيم بالظبط بس.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (mine.isNotEmpty()) item { Text("بوتاتي", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) }
            items(mine, key = { "m" + it.id }) { b -> BotRow(b, onClick = { onOpen(b) }, onManage = { manage = b }) }
            item { Text("لإدارة بوتاتك بأوامر زي BotFather، ابحث عن @${BotRepository.MAKER_USERNAME} واكتب /help.", Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall) }
            item {
                TextButton(onClick = { copyText(ctx, BotRepository.baseUrl) }) { Text("نسخ Base URL للمطورين") }
            }
        }
    }

    if (creating) AlertDialog(
        onDismissRequest = { creating = false },
        title = { Text("إنشاء بوت جديد") },
        text = {
            Column {
                OutlinedTextField(newName, { newName = it.take(64) }, label = { Text("اسم البوت") }, singleLine = true)
                OutlinedTextField(newUser, { newUser = it.trim().take(32) }, label = { Text("اليوزرنيم (لازم يخلص بـ bot)") }, singleLine = true, modifier = Modifier.padding(top = 6.dp))
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 6.dp)) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    runCatching { BotRepository.createBot(newName, newUser) }
                        .onSuccess { j -> creating = false; tokenShown = j.getString("username") to j.getString("token"); newName = ""; newUser = ""; tick++ }
                        .onFailure { err = it.message }
                }
            }) { Text("إنشاء") }
        },
        dismissButton = { TextButton(onClick = { creating = false }) { Text("إلغاء") } },
    )

    tokenShown?.let { (u, t) -> TokenDialog(u, t) { tokenShown = null } }

    manage?.let { b ->
        AlertDialog(
            onDismissRequest = { manage = null },
            title = { Text("@${b.username}") },
            text = {
                Column {
                    TextButton(onClick = { scope.launch { runCatching { BotRepository.getToken(b.id) }.onSuccess { tokenShown = b.username to it; manage = null } } }) { Text("🔑 عرض التوكن") }
                    TextButton(onClick = { scope.launch { runCatching { BotRepository.rotateToken(b.id) }.onSuccess { tokenShown = b.username to it; manage = null } } }) { Text("♻️ توكن جديد (القديم يبطل)") }
                    TextButton(onClick = { scope.launch { runCatching { BotRepository.deleteBot(b.id) }; manage = null; tick++ } }) { Text("🗑 حذف البوت", color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = { TextButton(onClick = { manage = null }) { Text("تمام") } },
        )
    }
}

@Composable
private fun BotRow(b: BotInfo, onClick: () -> Unit, onManage: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        BotAvatar(b, 48.dp)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            androidx.compose.material3.Text(b.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(Lang.raw("@${b.username}" + if (b.about.isNotBlank()) " · ${b.about}" else ""), maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        }
        if (onManage != null) TextButton(onClick = onManage) { Text("إدارة") }
    }
}

@Composable
private fun TokenDialog(username: String, token: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val base = BotRepository.baseUrl
    val snippet = "# python-telegram-bot\nApplication.builder().token(\"$token\")\n  .base_url(\"$base\").build()"
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("تم إنشاء @$username") },
        text = {
            Column {
                Text("⚠️ أي حد معاه التوكن يتحكم في البوت — متشاركوش. تقدر تشوفه تاني من «عرض التوكن»، ولو اتسرّب جدّده.")
                LinkRow("Token", token)
                LinkRow("Base URL (بدل api.telegram.org/bot)", base)
                TextButton(onClick = { copyText(ctx, snippet) }) { Text("نسخ مثال python-telegram-bot") }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("نسخته") } },
    )
}

// ============================================================ إضافة بوت لقناة

@Composable
fun ChannelBotsDialog(channel: Channel, onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    var bots by remember { mutableStateOf<List<BotInfo>>(emptyList()) }
    var added by remember { mutableStateOf<Set<String>>(emptySet()) }
    var err by remember { mutableStateOf<String?>(null) }
    var q by remember { mutableStateOf("") }
    var found by remember { mutableStateOf<BotInfo?>(null) }
    fun load() = scope.launch {
        val ids = runCatching { BotRepository.channelBots(channel.id).toSet() }.getOrDefault(emptySet())
        added = ids
        bots = runCatching { BotRepository.byIds(ids) }.getOrDefault(emptyList())
    }
    LaunchedEffect(channel.id) { load().join() }
    LaunchedEffect(q) { kotlinx.coroutines.delay(300); found = if (q.isBlank()) null else runCatching { BotRepository.byUsername(q) }.getOrNull() }
    @Composable fun row(b: BotInfo) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            BotAvatar(b, 40.dp)
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                androidx.compose.material3.Text(b.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(Lang.raw("@${b.username}"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (b.id in added) TextButton(onClick = { scope.launch { runCatching { BotRepository.removeFromChannel(b.id, channel.id) }.onFailure { err = it.message }; load() } }) { Text("إزالة") }
            else Button(onClick = { scope.launch { runCatching { BotRepository.addToChannel(b.id, channel.id) }.onFailure { err = it.message }; load() } }) { Text("إضافة") }
        }
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("بوتات القناة «${channel.name}»") },
        text = {
            Column {
                OutlinedTextField(q, { q = it.trim().take(40) }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("ابحث بيوزرنيم البوت (@username)") })
                found?.let { row(it) }
                if (q.isNotBlank() && found == null) Text("مفيش بوت بالاسم ده.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (bots.isNotEmpty()) Text("بوتات القناة", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                bots.filter { it.id != found?.id }.forEach { row(it) }
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Text("البوت بينشر في القناة بالأزرار، وبيستلم ضغطات الأعضاء.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("تمام") } },
    )
}

/** منشور بوت في قناة: اسم البوت فوق النص. */
@Composable
fun BotPostHeader(bot: BotInfo?) {
    if (bot != null) Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 4.dp)) {
        BotAvatar(bot, 22.dp)
        androidx.compose.material3.Text(bot.name, Modifier.padding(start = 6.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
    }
}

/** أزرار inline تحت منشور البوت في القناة. */
@Composable
fun BotPostKeyboard(post: com.binarybeast.chatapp.data.ChannelPost, onPressed: (String?) -> Unit) {
    val scope = rememberCoroutineScope()
    var busyKey by remember { mutableStateOf<String?>(null) }
    InlineKeyboard(post.replyMarkup, busyKey, "p${post.id}") { k, d ->
        val bid = post.botId ?: return@InlineKeyboard
        busyKey = k
        scope.launch {
            val ans = runCatching { BotRepository.press(bid, post.id, d, post.channelId) }.getOrNull()
            busyKey = null
            onPressed(ans?.answerText)
        }
    }
}


// ============================================================ بوتات المجموعات

/** جسم رسالة بوت داخل شات مجموعة: نص منسّق + أزرار inline. */
@Composable
fun GroupBotBody(msg: com.binarybeast.chatapp.data.GroupBotMsg, color: Color, onPress: (String) -> Unit) {
    msg.text?.let { BotText(it, msg.parseMode, color) }
    InlineKeyboard(msg.replyMarkup, null, "g${msg.id}") { _, d -> onPress(d) }
}

@Composable
fun GroupBotsDialog(groupId: String, title: String, bots: List<com.binarybeast.chatapp.data.GroupBotInfo>, onChanged: () -> Unit, onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var found by remember { mutableStateOf<BotInfo?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(q) { delay(300); found = if (q.isBlank()) null else runCatching { BotRepository.byUsername(q) }.getOrNull() }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("بوتات المجموعة") },
        text = {
            Column {
                OutlinedTextField(q, { q = it.trim().take(40) }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("ابحث بيوزرنيم البوت (@username)") })
                found?.let { b ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        BotAvatar(b, 40.dp)
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                            androidx.compose.material3.Text(b.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(Lang.raw("@${b.username}" + if (b.groupPrivacy) "" else " · بيشوف كل الرسايل"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (bots.none { it.id == b.id }) Button(onClick = {
                            scope.launch { runCatching { BotRepository.groupAddBot(groupId, title, b.id) }.onFailure { err = it.message }.onSuccess { err = null; q = "" }; onChanged() }
                        }) { Text("إضافة") }
                    }
                }
                if (q.isNotBlank() && found == null) Text("مفيش بوت بالاسم ده.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (bots.isNotEmpty()) Text("البوتات الحالية", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                bots.forEach { b ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            androidx.compose.material3.Text(b.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(Lang.raw("@${b.username}" + if (b.groupPrivacy) " · الخصوصية مفعّلة" else " · بيشوف كل الرسايل"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (b.addedByMe) TextButton(onClick = { scope.launch { runCatching { BotRepository.groupRemoveBot(groupId, b.id) }.onFailure { err = it.message }; onChanged() } }) { Text("إزالة") }
                    }
                }
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Text("البوت بيشوف بس الأوامر (/) والإشارات (@) والردود عليه، إلا لو صاحبه قفل وضع الخصوصية. رسايل المجموعة العادية بتفضل مشفّرة ومبتتبعتش للسيرفر. مين يقدر يضيف البوت: أي عضو.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("تمام") } },
    )
}
