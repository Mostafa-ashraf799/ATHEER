package com.binarybeast.chatapp.data

import android.content.Context
import android.net.Uri
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.binarybeast.chatapp.data.local.GroupEntity
import com.binarybeast.chatapp.data.local.LocalMessage
import io.github.jan.supabase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.X509EncodedKeySpec
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * الأجهزة المرتبطة بنفس الحساب.
 *
 * الربط الأول (بيتم على نفس الشبكة المحلية، مباشرة بين الجهازين، من غير أي سيرفر وسيط):
 *   الجهاز الجديد بيعرض QR بيتغيّر كل ١٥ ثانية، والجهاز القديم بيصوّره ويتصل بالجهاز الجديد على الشبكة المحلية.
 *   القناة مشفّرة (ECDH مؤقت + AES-GCM) ومربوطة بقيمة عشوائية موجودة في الـ QR بس.
 *   الجهاز القديم بيبعت: جلسة دخول مستقلة، مفتاح التشفير بتاع الحساب، المحادثات، والمجموعات.
 *   الحاجة الوحيدة اللي بتعدّي على السيرفر: طلب جلسة مستقلة للجهاز الجديد (من غير رسايل ولا مفاتيح).
 *
 * المزامنة بعد كده: نفق WebRTC P2P منفصل بين الأجهزة (DeviceSync).
 */
object DeviceStore {
    data class Dev(val id: String, val name: String, val addedAt: Long, val lastSeen: Long)

    private lateinit var ctx: Context
    fun init(c: Context) { ctx = c.applicationContext }

    private val sp by lazy {
        SecurePrefs.open(ctx, Accounts.name("devices"))
    }

    /** بيزيد لما القايمة تتغيّر (للواجهة). */
    val changes = MutableStateFlow(0)

    @Synchronized
    fun myId(): String = sp.getString("id", null) ?: UUID.randomUUID().toString().replace("-", "").also { sp.edit().putString("id", it).apply() }
    fun myName(): String = (android.os.Build.MODEL ?: "Android").take(40)

    @Synchronized
    fun syncKey(create: Boolean): ByteArray? {
        sp.getString("sync", null)?.let { return Base64.decode(it, Base64.NO_WRAP) }
        if (!create) return null
        val k = ByteArray(32).also { SecureRandom().nextBytes(it) }
        sp.edit().putString("sync", Base64.encodeToString(k, Base64.NO_WRAP)).apply()
        return k
    }
    @Synchronized fun setSyncKey(k: ByteArray) { sp.edit().putString("sync", Base64.encodeToString(k, Base64.NO_WRAP)).apply() }

    @Synchronized
    fun list(): List<Dev> {
        val raw = sp.getString("list", null) ?: return emptyList()
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { val o = a.getJSONObject(it); Dev(o.getString("id"), o.optString("name"), o.optLong("at"), o.optLong("ls")) }
        }.getOrDefault(emptyList())
    }

    @Synchronized
    private fun save(l: List<Dev>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("at", it.addedAt).put("ls", it.lastSeen)) }
        sp.edit().putString("list", a.toString()).apply()
        linkedCache = l.isNotEmpty()
        changes.value = changes.value + 1
    }

    @Synchronized
    fun upsert(d: Dev) {
        if (d.id == myId() || d.id in removedIds()) return
        val l = list().toMutableList()
        val ex = l.indexOfFirst { it.id == d.id }
        if (ex >= 0) l[ex] = l[ex].copy(name = d.name.ifBlank { l[ex].name }, lastSeen = maxOf(l[ex].lastSeen, d.lastSeen)) else l += d
        save(l)
    }

    @Synchronized
    fun seen(id: String) { list().firstOrNull { it.id == id }?.let { upsert(it.copy(lastSeen = System.currentTimeMillis())) } }

    fun removedIds(): Set<String> = sp.getStringSet("removed", emptySet())?.toSet() ?: emptySet()

    @Synchronized
    fun remove(id: String) {
        save(list().filterNot { it.id == id })
        sp.edit().putStringSet("removed", removedIds() + id).apply()
    }

    @Synchronized
    fun mergeRemoved(ids: Collection<String>) {
        if (ids.isEmpty()) return
        val all = removedIds() + ids
        sp.edit().putStringSet("removed", all).apply()
        val l = list(); val k = l.filterNot { it.id in all }
        if (k.size != l.size) save(k)
    }

    @Volatile private var linkedCache: Boolean? = null
    fun isLinked(): Boolean = linkedCache ?: list().isNotEmpty().also { linkedCache = it }

    @Synchronized
    fun clear() { sp.edit().clear().apply(); linkedCache = false; changes.value = changes.value + 1 }
}

// ------------------------------------------------------------------ تشفير القناة المحلية

internal object LinkCrypt {
    private val rng = SecureRandom()
    fun b64(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)
    fun unb64(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP)
    fun urlB64(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)
    fun unUrlB64(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)

    fun ephemeral(): KeyPair = KeyPairGenerator.getInstance("EC").apply { initialize(ECGenParameterSpec("secp256r1")) }.generateKeyPair()

    fun derive(priv: PrivateKey, otherPub: ByteArray, nonce: ByteArray, pkOld: ByteArray, pkNew: ByteArray): ByteArray {
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(priv)
        ka.doPhase(KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(otherPub)), true)
        val md = MessageDigest.getInstance("SHA-256")
        md.update(ka.generateSecret()); md.update(nonce); md.update(pkOld); md.update(pkNew); md.update("atheer-link-v1".toByteArray())
        return md.digest()
    }

    fun enc(key: ByteArray, plain: ByteArray): ByteArray {
        val iv = ByteArray(12).also { rng.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return iv + c.doFinal(plain)
    }

    fun dec(key: ByteArray, raw: ByteArray): ByteArray {
        require(raw.size > 28)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
        return c.doFinal(raw, 12, raw.size - 12)
    }

    fun sha256(vararg parts: ByteArray): ByteArray { val md = MessageDigest.getInstance("SHA-256"); parts.forEach { md.update(it) }; return md.digest() }
}

private class Wire(private val sock: Socket) {
    val inp = DataInputStream(BufferedInputStream(sock.getInputStream()))
    val out = DataOutputStream(BufferedOutputStream(sock.getOutputStream()))
    var key: ByteArray? = null

    fun writeRaw(b: ByteArray) { out.writeInt(b.size); out.write(b); out.flush() }
    fun readRaw(max: Int): ByteArray { val n = inp.readInt(); require(n in 0..max) { "bad frame" }; val b = ByteArray(n); inp.readFully(b); return b }
    fun write(o: JSONObject) = writeRaw(LinkCrypt.enc(key!!, o.toString().toByteArray()))
    fun read(): JSONObject = JSONObject(String(LinkCrypt.dec(key!!, readRaw(8_000_000))))
    fun close() { runCatching { sock.close() } }
}

// ------------------------------------------------------------------ تصدير/استيراد الرسايل

internal fun LocalMessage.toSyncJson(): JSONObject = JSONObject().put("i", msgId).put("p", peerId).put("m", mine).put("t", createdAt).put("s", status).put("r", read)
    .put("e", edited).put("d", deleted).put("vm", viewMode).put("vs", viewSecs).put("oa", openedAt).put("st", starred).put("ex", expireAt).put("pn", pinned).apply {
        body?.let { put("b", it) }; mediaFileId?.let { put("f", it) }; mediaType?.let { put("mt", it) }
        replyToId?.let { put("ri", it) }; replyText?.let { put("rt", it) }; myReaction?.let { put("mr", it) }
        theirReaction?.let { put("tr", it) }; senderId?.let { put("si", it) }
    }

private fun JSONObject.str(k: String): String? = if (has(k) && !isNull(k)) getString(k) else null

internal fun msgFromSync(o: JSONObject): LocalMessage = LocalMessage(
    msgId = o.getString("i"), peerId = o.getString("p"), mine = o.optBoolean("m"), body = o.str("b")?.take(20_000),
    mediaFileId = o.str("f"), mediaType = o.str("mt"), createdAt = o.optLong("t"), status = o.optInt("s"), read = o.optBoolean("r"),
    replyToId = o.str("ri"), replyText = o.str("rt"), myReaction = o.str("mr"), theirReaction = o.str("tr"),
    edited = o.optBoolean("e"), deleted = o.optBoolean("d"), senderId = o.str("si"),
    viewMode = o.optInt("vm"), viewSecs = o.optInt("vs"), openedAt = o.optLong("oa"), starred = o.optBoolean("st"),
    expireAt = o.optLong("ex"), pinned = o.optBoolean("pn"),
)

internal fun GroupEntity.toSyncJson(): JSONObject = JSONObject().put("g", groupId).put("n", name).put("a", adminId).put("m", members).put("ttl", ttlSec).put("c", createdAt).apply { avatarFileId?.let { put("av", it) } }
internal fun groupFromSync(o: JSONObject) = GroupEntity(o.getString("g"), o.optString("n"), o.optString("a"), o.optString("m"), o.optLong("ttl"), o.optLong("c"), o.str("av"))

/** الرسايل اللي مينفعش تتنقل: محادثات المساحة الخاصة (مفاتيحها محلية بس). */
internal fun syncable(m: LocalMessage): Boolean = !SpaceStore.isSpace(m.peerId) && !SpaceStore.isHidden(m.peerId)

// ------------------------------------------------------------------ الجهاز الجديد: يعرض QR ويستقبل

object LinkReceiver {
    val qr = MutableStateFlow("")
    val status = MutableStateFlow("")
    val done = MutableStateFlow(false)
    const val ROTATE_MS = 15_000L

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var busy = false
    @Volatile private var stopWanted = false
    private var job: Job? = null
    private var server: ServerSocket? = null
    private val nonces = ArrayList<Pair<String, Long>>()

    @Synchronized private fun consume(n: String): Boolean {
        val now = System.currentTimeMillis()
        nonces.removeAll { now - it.second > 22_000 }
        val ix = nonces.indexOfFirst { it.first == n }
        if (ix < 0) return false
        nonces.removeAt(ix); return true
    }

    fun hosts(): List<String> = runCatching {
        NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }.filterIsInstance<Inet4Address>()
            .filter { it.isSiteLocalAddress }.mapNotNull { it.hostAddress }
    }.getOrDefault(emptyList())

    fun start() {
        stopNow()
        stopWanted = false
        done.value = false; status.value = ""; qr.value = ""
        job = ioScope.launch {
            val ss = try { ServerSocket(0) } catch (e: Exception) { status.value = "تعذّر فتح قناة الربط"; return@launch }
            server = ss
            val rot = launch {
                while (isActive) {
                    val raw = ByteArray(16).also { SecureRandom().nextBytes(it) }
                    val n = LinkCrypt.urlB64(raw)
                    synchronized(this@LinkReceiver) { nonces += n to System.currentTimeMillis() }
                    val hs = hosts()
                    qr.value = if (hs.isEmpty()) "" else "atheer://link?v=1&h=${hs.take(3).joinToString(",")}&p=${ss.localPort}&n=$n"
                    if (hs.isEmpty()) status.value = "اتصل بالواي فاي (أو شغّل هوتسبوت) علشان الربط"
                    delay(ROTATE_MS)
                }
            }
            try {
                while (isActive) {
                    val c = try { ss.accept() } catch (e: Exception) { break }
                    launch {
                        busy = true
                        runCatching { handle(c) }.onFailure { if (!done.value) status.value = "فشل الربط: " + (it.message ?: it.javaClass.simpleName).take(80) }
                        runCatching { c.close() }
                        busy = false
                        if (stopWanted || done.value) stopNow()
                    }
                }
            } finally { rot.cancel(); runCatching { ss.close() } }
        }
    }

    /** لو فيه نقل شغّال بنستنى يخلص (علشان ماننقطعش في النص) وبعدين نقفل. */
    fun stop() { if (busy) stopWanted = true else stopNow() }

    private fun stopNow() {
        job?.cancel(); job = null
        runCatching { server?.close() }; server = null
    }

    private suspend fun handle(c: Socket) {
        c.soTimeout = 20_000
        val w = Wire(c)
        val hs = JSONObject(String(w.readRaw(4096)))
        val n = hs.optString("n")
        if (!consume(n)) { w.writeRaw("""{"err":"bad"}""".toByteArray()); w.close(); return }
        val pkOld = LinkCrypt.unb64(hs.getString("pk"))
        val kp = LinkCrypt.ephemeral()
        val pkNew = kp.public.encoded
        w.writeRaw(JSONObject().put("pk", LinkCrypt.b64(pkNew)).toString().toByteArray())
        w.key = LinkCrypt.derive(kp.private, pkOld, LinkCrypt.unUrlB64(n), pkOld, pkNew)
        status.value = "جهاز بيحاول يتّصل…"
        w.write(JSONObject().put("t", "hello").put("name", DeviceStore.myName()).put("dev", DeviceStore.myId()))
        c.soTimeout = 150_000

        var access = ""; var refresh = ""; var priv = ""; var pub = ""
        var count = 0
        val origin = ArrayList<DeviceStore.Dev>()
        while (true) {
            val j = w.read()
            when (j.optString("t")) {
                "cancel" -> { status.value = "الجهاز التاني لغى الربط"; return }
                "session" -> { access = j.getString("access"); refresh = j.getString("refresh"); status.value = "بيستلم الحساب…" }
                "identity" -> { priv = j.getString("priv"); pub = j.getString("pub") }
                "sync" -> {
                    DeviceStore.setSyncKey(LinkCrypt.unb64(j.getString("key")))
                    j.optJSONArray("devs")?.let { a -> for (i in 0 until a.length()) { val o = a.getJSONObject(i); origin += DeviceStore.Dev(o.getString("id"), o.optString("name"), o.optLong("at", System.currentTimeMillis()), System.currentTimeMillis()) } }
                }
                "prefs" -> applyPrefs(j)
                "groups" -> j.optJSONArray("list")?.let { a -> for (i in 0 until a.length()) runCatching { ChatEngine.groups.upsert(groupFromSync(a.getJSONObject(i))) } }
                "msgs" -> j.optJSONArray("list")?.let { a ->
                    for (i in 0 until a.length()) runCatching { ChatEngine.dao.insert(msgFromSync(a.getJSONObject(i))) }
                    count += a.length(); status.value = "بيستلم الرسايل… $count"
                }
                "done" -> {
                    if (access.isEmpty() || priv.isEmpty()) error("بيانات ناقصة")
                    CryptoBox.importIdentity(priv, pub)
                    origin.forEach { DeviceStore.upsert(it) }
                    Supa.client.auth.importAuthToken(access, refresh)
                    w.write(JSONObject().put("t", "ack"))
                    status.value = "تم الربط ✅"
                    done.value = true
                    return
                }
            }
        }
    }

    private fun applyPrefs(j: JSONObject) {
        fun set(k: String): Set<String> = j.optJSONArray(k)?.let { a -> (0 until a.length()).map { a.getString(it) }.toSet() } ?: emptySet()
        AppSettings.update { p ->
            p.copy(
                pinned = p.pinned + set("pinned"), archived = p.archived + set("archived"), muted = p.muted + set("muted"),
                blocked = p.blocked + set("blocked"), mutedStories = p.mutedStories + set("mutedStories"),
                notes = p.notes + set("notes"), chatTtls = p.chatTtls + set("chatTtls"),
            )
        }
    }
}

// ------------------------------------------------------------------ الجهاز القديم: يصوّر QR ويبعت

object LinkSender {
    private val IPV4 = Regex("""^\d{1,3}(\.\d{1,3}){3}$""")

    /** @return null لو نجح، أو رسالة الخطأ. */
    suspend fun link(qrText: String, confirm: suspend (String) -> Boolean, progress: (String) -> Unit): String? = withContext(Dispatchers.IO) {
        val u = runCatching { Uri.parse(qrText) }.getOrNull()
        if (u == null || u.scheme != "atheer" || u.host != "link") return@withContext "ده مش كود ربط من ATHEER"
        val hosts = (u.getQueryParameter("h") ?: "").split(',').filter { IPV4.matches(it) && runCatching { java.net.InetAddress.getByName(it).isSiteLocalAddress }.getOrDefault(false) }
        val port = u.getQueryParameter("p")?.toIntOrNull() ?: return@withContext "كود غير صالح"
        val n = u.getQueryParameter("n") ?: return@withContext "كود غير صالح"
        if (hosts.isEmpty()) return@withContext "الكود ده مش لجهاز على شبكة محلية"

        var sock: Socket? = null
        for (h in hosts) {
            val s = Socket()
            if (runCatching { s.connect(InetSocketAddress(h, port), 4000) }.isSuccess) { sock = s; break } else runCatching { s.close() }
        }
        if (sock == null) return@withContext "مقدرتش أوصل للجهاز الجديد. لازم الجهازين على نفس الواي فاي (وتأكد إن الشبكة مش بتمنع الأجهزة تتكلم مع بعض)."
        val w = Wire(sock)
        try {
            sock.soTimeout = 20_000
            val kp = LinkCrypt.ephemeral()
            val pkOld = kp.public.encoded
            w.writeRaw(JSONObject().put("n", n).put("pk", LinkCrypt.b64(pkOld)).toString().toByteArray())
            val resp = JSONObject(String(w.readRaw(4096)))
            if (resp.has("err")) return@withContext "الكود انتهت صلاحيته، صوّر الكود الجديد"
            val pkNew = LinkCrypt.unb64(resp.getString("pk"))
            w.key = LinkCrypt.derive(kp.private, pkNew, LinkCrypt.unUrlB64(n), pkOld, pkNew)
            val hello = w.read()
            val name = hello.optString("name").ifBlank { "جهاز جديد" }
            val devId = hello.optString("dev")
            if (devId.length < 8) return@withContext "رد غير صالح"
            sock.soTimeout = 150_000
            if (!confirm(name)) { runCatching { w.write(JSONObject().put("t", "cancel")) }; return@withContext "اتلغى الربط" }

            progress("بيجهّز جلسة للجهاز الجديد…")
            val (acc, ref) = AuthRepository.requestLinkedSession()
            w.write(JSONObject().put("t", "session").put("access", acc).put("refresh", ref))
            val (priv, pub) = CryptoBox.exportIdentity()
            w.write(JSONObject().put("t", "identity").put("priv", priv).put("pub", pub))
            val key = DeviceStore.syncKey(true)!!
            val devs = JSONArray()
            DeviceStore.list().forEach { devs.put(JSONObject().put("id", it.id).put("name", it.name).put("at", it.addedAt)) }
            devs.put(JSONObject().put("id", DeviceStore.myId()).put("name", DeviceStore.myName()).put("at", System.currentTimeMillis()))
            w.write(JSONObject().put("t", "sync").put("key", LinkCrypt.b64(key)).put("devs", devs))
            val p = AppSettings.now
            w.write(JSONObject().put("t", "prefs")
                .put("pinned", JSONArray(p.pinned.toList())).put("archived", JSONArray(p.archived.toList())).put("muted", JSONArray(p.muted.toList()))
                .put("blocked", JSONArray(p.blocked.toList())).put("mutedStories", JSONArray(p.mutedStories.toList()))
                .put("notes", JSONArray(p.notes.toList())).put("chatTtls", JSONArray(p.chatTtls.toList())))
            val groups = JSONArray(); runCatching { ChatEngine.groups.all() }.getOrDefault(emptyList()).forEach { groups.put(it.toSyncJson()) }
            w.write(JSONObject().put("t", "groups").put("list", groups))
            val all = ChatEngine.dao.observeAll().first().filter { syncable(it) }
            var sent = 0
            for (chunk in all.chunked(80)) {
                val a = JSONArray(); chunk.forEach { a.put(it.toSyncJson()) }
                w.write(JSONObject().put("t", "msgs").put("list", a))
                sent += chunk.size; progress("بيتبعت $sent / ${all.size} رسالة")
            }
            // الجهاز الجديد يتسجّل عندنا قبل ما نقفل
            DeviceStore.upsert(DeviceStore.Dev(devId, name, System.currentTimeMillis(), System.currentTimeMillis()))
            w.write(JSONObject().put("t", "done"))
            sock.soTimeout = 60_000
            val ack = w.read()
            if (ack.optString("t") != "ack") return@withContext "الجهاز الجديد ماأكّدش الاستلام"
            DeviceSync.kick()
            null
        } catch (e: Exception) {
            "فشل الربط: " + (e.message ?: e.javaClass.simpleName).take(100)
        } finally { w.close() }
    }
}

// ------------------------------------------------------------------ إلغاء الربط

object DeviceControl {
    /** الجهاز ده اتشال من الأجهزة المرتبطة من جهاز تاني: اخرج وامسح بياناتك المحلية. */
    @Volatile var wiping = false
    suspend fun removedByOwner() {
        if (wiping) return
        wiping = true
        runCatching { ChatEngine.wipeLocal() }
        runCatching { AuthRepository.signOut() }
        DeviceStore.clear()
    }

    suspend fun remove(id: String) {
        DeviceSync.sendUnlink(id)
        DeviceStore.remove(id)
    }

    /** تسجيل خروج كل الجلسات التانية (الأجهزة المرتبطة هتحتاج ربط من جديد). */
    suspend fun signOutOthers(): Boolean = runCatching {
        Supa.client.auth.signOut(io.github.jan.supabase.auth.SignOutScope.OTHERS)
        DeviceStore.list().forEach { DeviceSync.sendUnlink(it.id); DeviceStore.remove(it.id) }
    }.isSuccess
}
