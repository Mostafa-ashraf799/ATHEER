package com.binarybeast.chatapp.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray

/** ردود سريعة: جمل جاهزة بتتضاف لخانة الكتابة بضغطة. محلية على الجهاز. */
object QuickReplies {
    private lateinit var sp: SharedPreferences
    private val _items = MutableStateFlow<List<String>>(emptyList())
    val items: StateFlow<List<String>> = _items
    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences(Accounts.name("quick_replies"), Context.MODE_PRIVATE)
        val raw = sp.getString("l", null)
        _items.value = if (raw == null) listOf("تمام 👍", "هكلمك بعدين", "ثانية وراجعلك", "شكرًا") else
            runCatching { JSONArray(raw).let { a -> (0 until a.length()).map { a.getString(it) } } }.getOrDefault(emptyList())
    }
    private fun save(l: List<String>) { _items.value = l; sp.edit().putString("l", JSONArray(l).toString()).apply() }
    fun add(s: String) { val t = s.trim().take(300); if (t.isNotEmpty() && t !in _items.value) save(_items.value + t) }
    fun remove(s: String) = save(_items.value - s)
}
