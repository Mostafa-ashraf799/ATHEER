package com.binarybeast.chatapp.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binarybeast.chatapp.data.AppSettings

private class Fx(val name: String, val block: @Composable (Modifier, Int) -> Modifier)

private val ENTER = listOf(
    Fx("دخول: تلاشي") { m, _ -> m.enterFade() }, Fx("دخول: من تحت") { m, _ -> m.enterSlideUp() },
    Fx("دخول: من فوق") { m, _ -> m.enterSlideDown() }, Fx("دخول: من البداية") { m, _ -> m.enterSlideStart() },
    Fx("دخول: من النهاية") { m, _ -> m.enterSlideEnd() }, Fx("دخول: نطّة") { m, _ -> m.enterPop() },
    Fx("دخول: ارتداد") { m, _ -> m.enterBounce() }, Fx("دخول: زووم") { m, _ -> m.enterZoom() },
    Fx("دخول: لفّة") { m, _ -> m.enterRotate() }, Fx("دخول: قلب رأسي") { m, _ -> m.enterFlipY() },
    Fx("دخول: قلب أفقي") { m, _ -> m.enterFlipX() }, Fx("دخول: سقوط") { m, _ -> m.enterDrop() },
    Fx("دخول: أرجحة") { m, _ -> m.enterSwing() }, Fx("دخول: فرد") { m, _ -> m.enterUnfold() },
    Fx("دخول: فقاعة") { m, _ -> m.enterBubble(true) },
)
private val PRESS = listOf(PressKind.Dip, PressKind.Squash, PressKind.Tilt, PressKind.Glow, PressKind.Lift)
private val PRESS_NAMES = listOf("ضغط: غطسة", "ضغط: عجن", "ضغط: ميلان", "ضغط: توهّج", "ضغط: رفع")
private val LOOPS = listOf(
    Fx("مستمر: نبض") { m, _ -> m.pulse() }, Fx("مستمر: تنفّس") { m, _ -> m.breathe() },
    Fx("مستمر: اهتزاز") { m, _ -> m.wiggle() }, Fx("مستمر: طفو") { m, _ -> m.floatY() },
    Fx("مستمر: دوران") { m, _ -> m.spin() }, Fx("مستمر: دقّة قلب") { m, _ -> m.heartbeat() },
    Fx("مستمر: وميض") { m, _ -> m.blink() }, Fx("مستمر: بندول") { m, _ -> m.pendulum() },
    Fx("مستمر: هالة") { m, _ -> m.glowRing(MaterialTheme.colorScheme.primary) }, Fx("مستمر: لمعان") { m, _ -> m.shimmer() },
)
private val EVENTS = listOf(
    Fx("حدث: رجّة") { m, t -> m.shake(t) }, Fx("حدث: تادا") { m, t -> m.tada(t) },
    Fx("حدث: جيلي") { m, t -> m.jelly(t) }, Fx("حدث: مطّاطة") { m, t -> m.rubberBand(t) },
    Fx("حدث: فلاش") { m, t -> m.flash(t) }, Fx("حدث: نطّ") { m, t -> m.hop(t) },
    Fx("حدث: انتفاخ") { m, t -> m.swell(t) },
)

@Composable
private fun Tile(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier.width(104.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.height(52.dp), contentAlignment = Alignment.Center) { content() }
        Text(title, fontSize = 10.sp, maxLines = 2, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun Chip() = Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.primary))

@Composable
private fun Section(t: String) = Text(t, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 6.dp))

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun AnimPage() {
    val on = AppSettings.now.animations
    Row(Modifier.fillMaxWidth().clickable { AppSettings.update { it.copy(animations = !on) } }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("الأنيميشن")
            Text("لو قفلته التطبيق يشتغل من غير حركات (أخف على الأجهزة الضعيفة)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = on, onCheckedChange = { v -> AppSettings.update { it.copy(animations = v) } })
    }
    Text("اضغط على أي مربع علشان الحركة تتعاد.", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall)

    Section("الدخول (${ENTER.size})")
    FlowRow(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ENTER.forEach { fx ->
            var replay by remember { mutableIntStateOf(0) }
            Tile(fx.name) { Box(Modifier.clickable { replay++ }) { key(replay) { Box(fx.block(Modifier, replay)) { Chip() } } } }
        }
    }
    Section("الضغط (${PRESS.size})")
    FlowRow(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PRESS.forEachIndexed { i, k -> Tile(PRESS_NAMES[i]) { Box(Modifier.pressEffect(k) {}) { Chip() } } }
    }
    Section("مستمرة (${LOOPS.size})")
    FlowRow(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        LOOPS.forEach { fx -> Tile(fx.name) { Box(fx.block(Modifier, 0)) { Chip() } } }
    }
    Section("أحداث (${EVENTS.size})")
    FlowRow(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        EVENTS.forEach { fx ->
            var t by remember { mutableIntStateOf(0) }
            Tile(fx.name) { Box(Modifier.clickable { t++ }) { Box(fx.block(Modifier, t)) { Chip() } } }
        }
    }
    Section("مكوّنات")
    FlowRow(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Tile("نقط الكتابة") { TypingDots() }
        Tile("عدّاد تصاعدي") { var r by remember { mutableIntStateOf(0) }; key(r) { Box(Modifier.clickable { r++ }) { CountUpText(1234) } } }
        Tile("كتابة حرف حرف") { var r by remember { mutableIntStateOf(0) }; key(r) { Box(Modifier.clickable { r++ }) { TypewriterText("أهلاً بيك") } } }
        Tile("رقم منزلق") { var n by remember { mutableIntStateOf(1) }; Box(Modifier.clickable { n++ }) { SlideNumber(n, fontSize = 22, color = MaterialTheme.colorScheme.onSurface) } }
        Tile("شرارات") { var t by remember { mutableIntStateOf(0) }; Box(Modifier.clickable { t++ }, contentAlignment = Alignment.Center) { Chip(); SparkleBurst(t) } }
        Tile("رادار") { RadarRipple(modifier = Modifier.size(48.dp)) }
        Tile("تدرّج متحرك") { AnimatedGradientBox(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary), Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))) }
        Tile("هيكل تحميل") { SkeletonRow(Modifier.width(90.dp)) }
        Tile("إيموجي طالع") { var r by remember { mutableIntStateOf(0) }; var show by remember { mutableStateOf(false) }
            Box(Modifier.clickable { show = true; r++ }) { Text("❤️"); if (show) key(r) { RisingEmoji("❤️") { show = false } } } }
    }
    Section("ظهور/اختفاء (${Vis.all.size})")
    FlowRow(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Vis.all.forEach { (n, pair) ->
            var shown by remember { mutableStateOf(true) }
            Tile("ظهور: $n") { Box(Modifier.clickable { shown = !shown }.size(40.dp), contentAlignment = Alignment.Center) { AnimatedVisibility(shown, enter = pair.first, exit = pair.second) { Chip() } } }
        }
    }
    Section("انتقالات الشاشات")
    Text("Fade-through • Shared-axis X/Y • Zoom • Slide-over • Rise • Drop • Spring-pop — بتتبدّل حسب الشاشة (شات/مكالمة/متصفح/قناة/بوت) واتجاه التابات.", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall)
}
