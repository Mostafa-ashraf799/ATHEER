package com.binarybeast.chatapp.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.serialization.json.Json

/** نسخة محلية من البروفايلات (بتاعي وبتوع اللي بكلّمهم) علشان التطبيق يفتح ويعرض من غير نت. */
object ProfileDisk {
    private var sp: SharedPreferences? = null
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun init(ctx: Context) { sp = ctx.applicationContext.getSharedPreferences("profiles_cache", Context.MODE_PRIVATE) }

    private fun key(id: String) = Accounts.name("p_$id")

    fun get(id: String): Profile? = runCatching {
        sp?.getString(key(id), null)?.let { json.decodeFromString(Profile.serializer(), it) }
    }.getOrNull()

    fun put(p: Profile) {
        runCatching { sp?.edit()?.putString(key(p.id), json.encodeToString(Profile.serializer(), p))?.apply() }
    }

    private fun meKey() = Accounts.name("me")
    fun getMe(): Profile? = runCatching {
        sp?.getString(meKey(), null)?.let { json.decodeFromString(Profile.serializer(), it) }
    }.getOrNull()
    fun putMe(p: Profile) {
        runCatching { sp?.edit()?.putString(meKey(), json.encodeToString(Profile.serializer(), p))?.apply() }
    }

    // ---- جهات الاتصال المحفوظة (قايمة محلية بتتحدّث من السيرفر بس لما نحتاج)
    fun getContacts(): List<Profile> = runCatching {
        val ids = sp?.getString(Accounts.name("contacts_ids"), "")?.split(',')?.filter { it.isNotBlank() } ?: emptyList()
        ids.mapNotNull { get(it) }
    }.getOrDefault(emptyList())
    fun putContacts(list: List<Profile>) {
        list.forEach { put(it) }
        sp?.edit()?.putString(Accounts.name("contacts_ids"), list.joinToString(",") { it.id })
            ?.putLong(Accounts.name("contacts_ts"), System.currentTimeMillis())?.apply()
    }
    fun contactsAgeMs(): Long = (sp?.getLong(Accounts.name("contacts_ts"), 0L) ?: 0L).let { if (it == 0L) Long.MAX_VALUE else System.currentTimeMillis() - it }
    fun getSyncSig(): String? = sp?.getString(Accounts.name("sync_sig"), null)
    fun putSyncSig(s: String) { sp?.edit()?.putString(Accounts.name("sync_sig"), s)?.apply() }
}
