package com.binarybeast.chatapp.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.serialization.json.Json

/** نسخة محلية من البروفايلات (بتاعي وبتوع اللي بكلّمهم) علشان التطبيق يفتح ويعرض من غير نت. */
object ProfileDisk {
    private var sp: SharedPreferences? = null
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun init(ctx: Context) { sp = ctx.applicationContext.getSharedPreferences("profiles_cache", Context.MODE_PRIVATE) }

    private fun key(id: String) = Accounts.name("p_$id")

    fun get(id: String): Profile? = runCatching {
        sp?.getString(key(id), null)?.let { json.decodeFromString(Profile.serializer(), it) }
    }.getOrNull()

    fun put(p: Profile) {
        runCatching { sp?.edit()?.putString(key(p.id), json.encodeToString(Profile.serializer(), p))?.apply() }
    }

    private fun meKey() = Accounts.name("me")
    fun getMe(): Profile? = runCatching {
        sp?.getString(meKey(), null)?.let { json.decodeFromString(Profile.serializer(), it) }
    }.getOrNull()
    fun putMe(p: Profile) {
        runCatching { sp?.edit()?.putString(meKey(), json.encodeToString(Profile.serializer(), p))?.apply() }
    }
}
