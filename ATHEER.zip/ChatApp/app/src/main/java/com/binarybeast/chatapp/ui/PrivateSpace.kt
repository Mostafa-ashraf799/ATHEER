package com.binarybeast.chatapp.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.binarybeast.chatapp.data.ChatEngine
import com.binarybeast.chatapp.data.Profile
import com.binarybeast.chatapp.data.SpaceStore
import com.binarybeast.chatapp.data.local.previewText

/** بيمنع لقطات الشاشة وتسجيلها (وبيخفي المحتوى في الـRecents) طول ما الشاشة دي ظاهرة. */
@Composable
fun SecureWindow() {
    val act = LocalContext.current.let { var c = it; while (c is android.content.ContextWrapper && c !is android.app.Activity) c = c.baseContext; c as? android.app.Activity }
    DisposableEffect(act) {
        act?.window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        onDispose {
            // نرجّع للإعداد العام بتاع التطبيق
            if (!com.binarybeast.chatapp.data.AppSettings.now.screenSecurity) act?.window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        }
    }
}

private sealed class SpaceItem(val key: String) {
    class Chat(val p: Profile, val m: com.binarybeast.chatapp.data.local.LocalMessage?, val n: Int) : SpaceItem("p" + p.id)
    class Chan(val c: com.binarybeast.chatapp.data.Channel) : SpaceItem("c" + c.id)
}

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun PrivateSpaceScreen(onClose: () -> Unit, onOpen: (Profile) -> Unit, onOpenChannel: (com.binarybeast.chatapp.data.Channel) -> Unit = { NavStore.channel = it }) {
    SecureWindow()
    BackHandler { onClose() }
    var items by remember { mutableStateOf<List<SpaceItem>>(emptyList()) }
    var adding by remember { mutableStateOf(false) }
    var removeFor by remember { mutableStateOf<SpaceItem?>(null) }
    var myChannels by remember { mutableStateOf<List<com.binarybeast.chatapp.data.Channel>>(emptyList()) }
    val hidden by SpaceStore.hidden.collectAsState()
    val last by ChatEngine.dao.observeLast().collectAsState(initial = emptyList())
    val unread by ChatEngine.dao.observeUnread().collectAsState(initial = emptyList())
    LaunchedEffect(Unit) { myChannels = runCatching { com.binarybeast.chatapp.data.ChannelRepository.mine() }.getOrDefault(emptyList()) }
    val spaceId = SpaceStore.active ?: "0"
    val spaceName = SpaceStore.list().firstOrNull { it.id == spaceId }?.name ?: "المساحة الخاصة"
    LaunchedEffect(last, unread, hidden, myChannels) {
        val mine = SpaceStore.hiddenIn(spaceId)
        val chats = last.filter { (SpaceStore.isSpace(it.peerId) && SpaceStore.spaceIdOf(it.peerId) == spaceId) || it.peerId in mine }.mapNotNull { m ->
            val p = ChatEngine.peerProfile(m.peerId) ?: return@mapNotNull null
            m to SpaceItem.Chat(p, m, unread.firstOrNull { it.peerId == m.peerId }?.n ?: 0)
        }.sortedByDescending { it.first.createdAt }.map { it.second }
        val chans = myChannels.filter { "c:${it.id}" in mine }.map { SpaceItem.Chan(it) }
        items = chats + chans
    }
    Scaffold(
        topBar = {
            GlassTopBar(
                title = { Text(Lang.raw(spaceName), fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onClose) { androidx.compose.material3.Icon(AIcons.ArrowBack, "رجوع") } },
                actions = { IconButton(onClick = { adding = true }) { androidx.compose.material3.Icon(AIcons.PersonAdd, "إضافة للمساحة") } },
            )
        },
    ) { pad ->
        if (items.isEmpty()) Box(Modifier.padding(pad).fillMaxSize(), Alignment.Center) {
            Text(
                "مفيش حاجة هنا لسه.\nدوس على ➕ فوق وضيف أي شخص أو مجموعة أو قناة من عندك. وأي حد يدوّر برقمك السري هيقدر يبعتلك هنا، ومحدش غيرك هيشوف ده.",
                Modifier.padding(32.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        } else LazyColumn(Modifier.padding(pad).fillMaxSize()) {
            items(items, key = { it.key }) { it ->
                when (it) {
                    is SpaceItem.Chat -> Row(
                        Modifier.fillMaxWidth().combinedClickable(onClick = { onOpen(it.p) }, onLongClick = { removeFor = it }).padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Avatar(it.p.avatarFileId, it.p.displayName.ifBlank { it.p.phone }, 48.dp)
                        Column(Modifier.weight(1f)) {
                            Text(Lang.raw(it.p.displayName.ifBlank { "مستخدم" }), fontWeight = FontWeight.SemiBold, maxLines = 1)
                            it.m?.let { m -> Text(m.previewText(), maxLines = 1, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                        if (it.n > 0) Text("${it.n}", Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.primary).padding(horizontal = 8.dp, vertical = 2.dp), color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelSmall)
                    }
                    is SpaceItem.Chan -> Row(
                        Modifier.fillMaxWidth().combinedClickable(onClick = { onOpenChannel(it.c) }, onLongClick = { removeFor = it }).padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Avatar(it.c.avatarFileId, it.c.name, 48.dp)
                        Column(Modifier.weight(1f)) {
                            Text(Lang.raw(it.c.name), fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text("📢 قناة", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
    removeFor?.let { r ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { removeFor = null },
            title = { Text("إرجاع للشات؟") },
            text = { Text("هيرجع يظهر في الشات والقنوات العادية.") },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    when (r) {
                        is SpaceItem.Chat -> if (SpaceStore.isSpace(r.p.id)) { /* محادثة جاية من رقم المساحة: بتفضل جوه */ } else SpaceStore.unhide(r.p.id)
                        is SpaceItem.Chan -> SpaceStore.unhide("c:${r.c.id}")
                    }
                    removeFor = null
                }) { Text("إرجاع") }
            },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { removeFor = null }) { Text("إلغاء") } },
        )
    }
    if (adding) AddToSpaceDialog(myChannels) { adding = false }
}

/** إضافة أشخاص/مجموعات/قنوات من عندي للمساحة الخاصة. */
@Composable
private fun AddToSpaceDialog(channels: List<com.binarybeast.chatapp.data.Channel>, onClose: () -> Unit) {
    val chats = rememberAllChats(includeGroups = true)
    val hidden by SpaceStore.hidden.collectAsState()
    val sel = remember { androidx.compose.runtime.mutableStateListOf<String>() }
    val rows = chats.filter { it.id !in hidden }.map { Triple(it.id, it.displayName.ifBlank { it.username ?: "مستخدم" }, it.avatarFileId) } +
        channels.filter { "c:${it.id}" !in hidden }.map { Triple("c:${it.id}", "📢 " + it.name, it.avatarFileId) }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onClose,
        title = { Text("إضافة للمساحة الخاصة") },
        text = {
            if (rows.isEmpty()) Text("مفيش حاجة تتضاف.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            else LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(rows, key = { it.first }) { (id, name, av) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { if (id in sel) sel.remove(id) else sel.add(id) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        androidx.compose.material3.Checkbox(id in sel, { if (it) sel.add(id) else sel.remove(id) })
                        Avatar(av, name, 36.dp)
                        Text(Lang.raw(name), fontWeight = FontWeight.SemiBold, maxLines = 1)
                    }
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton(enabled = sel.isNotEmpty(), onClick = { sel.forEach { SpaceStore.hide(it, SpaceStore.active) }; onClose() }) { Text("إضافة") } },
        dismissButton = { androidx.compose.material3.TextButton(onClick = onClose) { Text("إلغاء") } },
    )
}
