package com.binarybeast.chatapp.ui

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import com.binarybeast.chatapp.data.AppSettings

/**
 * اهتزاز موحّد. `LocalHapticFeedback` بيتجاهله النظام لو «ردّ فعل اللمس» مقفول في إعدادات الجهاز،
 * فبنكلّم الـVibrator مباشرة (لو الإعداد «اهتزاز إجباري» مفعّل) ونرجع للطريقة العادية لو الجهاز مفيهوش موتور اهتزاز.
 */
object Haptic {
    private fun vib(ctx: Context): Vibrator? = try {
        if (Build.VERSION.SDK_INT >= 31) (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        else @Suppress("DEPRECATION") ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    } catch (_: Throwable) { null }

    fun available(ctx: Context): Boolean = vib(ctx)?.hasVibrator() == true

    private fun direct(ctx: Context, ms: Long, amp: Int, predefined: Int?): Boolean {
        val v = vib(ctx) ?: return false
        if (!v.hasVibrator()) return false
        return try {
            if (Build.VERSION.SDK_INT >= 29 && predefined != null) v.vibrate(VibrationEffect.createPredefined(predefined))
            else if (Build.VERSION.SDK_INT >= 26) {
                val a = if (v.hasAmplitudeControl()) amp else VibrationEffect.DEFAULT_AMPLITUDE
                v.vibrate(VibrationEffect.createOneShot(ms, a))
            } else @Suppress("DEPRECATION") v.vibrate(ms)
            true
        } catch (_: Throwable) { false }
    }

    /** نقرة خفيفة (التنقل). */
    fun tick(ctx: Context, fallback: HapticFeedback? = null) {
        if (AppSettings.now.hapticForce && direct(ctx, 12, 90, if (Build.VERSION.SDK_INT >= 29) VibrationEffect.EFFECT_TICK else null)) return
        fallback?.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }

    /** نقرة أقوى (إرسال، لايك). */
    fun click(ctx: Context, fallback: HapticFeedback? = null) {
        if (AppSettings.now.hapticForce && direct(ctx, 25, 180, if (Build.VERSION.SDK_INT >= 29) VibrationEffect.EFFECT_CLICK else null)) return
        fallback?.performHapticFeedback(HapticFeedbackType.LongPress)
    }
}
