package com.binarybeast.chatapp.data

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import io.github.jan.supabase.auth.auth
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom

/**
 * تعدد الحسابات على نفس الجهاز.
 * - كل حساب له «مساحة بيانات» (ns) منفصلة: قاعدة الرسايل، مفاتيح التشفير، الستيكرات، المساحة الخاصة، الدعوات، الردود السريعة.
 *   الحساب الأول (القديم) ns فاضي، فبياناته متتغيرش.
 * - جلسات الدخول (التوكنز) متخزنة مشفّرة (EncryptedSharedPreferences).
 * - التبديل بيعمل إعادة تشغيل للتطبيق على الحساب التاني (أنضف وأأمن من تبديل البيانات والاتصالات وهي شغّالة).
 * - الرسايل بتوصل للحساب النشط بس؛ الحسابات التانية بتستلم اللي فاتها أول ما تفتحها.
 */
object Accounts {
    data class Acct(val id: String, val ns: String, val name: String, val phone: String, val access: String, val refresh: String)

    private lateinit var appCtx: Context
    private lateinit var gp: SharedPreferences

    /** مساحة بيانات الحساب النشط ("" للحساب الأول). */
    var ns: String = ""
        private set

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        gp = appCtx.getSharedPreferences("accounts_meta", Context.MODE_PRIVATE)
        ns = gp.getString("activeNs", "") ?: ""
    }

    /** اسم ملف/قاعدة بيانات داخل مساحة الحساب النشط. */
    fun name(base: String) = if (ns.isEmpty()) base else "${base}_$ns"
    fun nameFor(base: String, forNs: String) = if (forNs.isEmpty()) base else "${base}_$forNs"

    private fun sec(): SharedPreferences = SecurePrefs.open(appCtx, "accounts_sec")

    @Synchronized
    fun list(): List<Acct> {
        val raw = runCatching { sec().getString("list", null) }.getOrNull() ?: return emptyList()
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Acct(o.getString("id"), o.optString("ns"), o.optString("name"), o.optString("phone"), o.optString("a"), o.optString("r"))
            }
        }.getOrDefault(emptyList())
    }

    @Synchronized
    private fun save(l: List<Acct>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("ns", it.ns).put("name", it.name).put("phone", it.phone).put("a", it.access).put("r", it.refresh)) }
        runCatching { sec().edit().putString("list", a.toString()).apply() }
    }

    val activeId: String? get() = gp.getString("activeId", null)

    /** الحساب النشط المحفوظ (علشان نعمله استرجاع جلسة بعد إعادة التشغيل). */
    fun activeSaved(): Acct? = activeId?.let { id -> list().firstOrNull { it.id == id && it.refresh.isNotEmpty() } }

    /**
     * بيتنده كل ما الجلسة تتجدّد: بيحفظ التوكنز ويسجّل الحساب.
     * بيرجّع true لو الحساب ده متسجّل قبل كده في مساحة تانية (لازم نرجع لمساحته).
     */
    fun saveSession(userId: String, access: String, refresh: String): Boolean {
        val l = list().toMutableList()
        val ex = l.firstOrNull { it.id == userId }
        if (ex != null && ex.ns != ns) {
            // نفس الحساب اتسجّل دخول تاني من مساحة جديدة: نحدّث التوكنز ونرجع لمساحته الأصلية
            l[l.indexOf(ex)] = ex.copy(access = access, refresh = refresh)
            save(l)
            gp.edit().putString("activeNs", ex.ns).putString("activeId", userId).commit()
            return true
        }
        if (ex == null) l += Acct(userId, ns, "", "", access, refresh)
        else l[l.indexOf(ex)] = ex.copy(access = access, refresh = refresh)
        save(l)
        if (activeId != userId) gp.edit().putString("activeId", userId).apply()
        return false
    }

    fun updateInfo(userId: String, name: String, phone: String) {
        val l = list().toMutableList()
        val ex = l.firstOrNull { it.id == userId } ?: return
        if (ex.name == name && ex.phone == phone) return
        l[l.indexOf(ex)] = ex.copy(name = name, phone = phone)
        save(l)
    }

    private suspend fun detachSession() {
        // من غير ما نكلّم السيرفر (مش «تسجيل خروج»): الجلسة المحفوظة لازم تفضل صالحة
        runCatching { Supa.client.auth.clearSession() }
    }

    suspend fun switchTo(a: Acct, activity: Context) {
        gp.edit().putString("activeNs", a.ns).putString("activeId", a.id).commit()
        detachSession()
        restart(activity)
    }

    /** إضافة حساب جديد: مساحة بيانات جديدة وشاشة دخول. */
    suspend fun beginAdd(activity: Context) {
        val newNs = ByteArray(4).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        gp.edit().putString("activeNs", newNs).remove("activeId").commit()
        detachSession()
        restart(activity)
    }

    /** نسيان حساب (ومسح بياناته من الجهاز). لو هو النشط، بيتنقل لحساب تاني أو لشاشة الدخول. */
    suspend fun removeAndSwitch(userId: String, activity: Context) {
        val l = list().toMutableList()
        val gone = l.firstOrNull { it.id == userId }
        if (gone != null) {
            l.remove(gone); save(l)
            wipeNs(gone.ns)
        }
        val next = l.firstOrNull()
        if (activeId == userId) {
            if (next != null) gp.edit().putString("activeNs", next.ns).putString("activeId", next.id).commit()
            else gp.edit().putString("activeNs", "").remove("activeId").commit()
            detachSession()
            restart(activity)
        }
    }

    /** مسح بيانات مساحة حساب (من حساب مش نشط). */
    fun wipeNs(forNs: String) {
        runCatching { appCtx.deleteDatabase(nameFor("chat", forNs) + ".db") }
        listOf("stickers", "space", "invites", "quick_replies", "keys").forEach { runCatching { appCtx.deleteSharedPreferences(nameFor(it, forNs)) } }
    }

    fun restart(ctx: Context) {
        val target = appCtx.packageManager.getLaunchIntentForPackage(appCtx.packageName)!!
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        val i = Intent(appCtx, com.binarybeast.chatapp.RestartActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra("target", target).putExtra("pid", android.os.Process.myPid())
        appCtx.startActivity(i)
        (ctx as? Activity)?.finishAffinity()
    }
}
