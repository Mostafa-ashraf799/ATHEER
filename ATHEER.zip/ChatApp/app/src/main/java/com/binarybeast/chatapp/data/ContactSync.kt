package com.binarybeast.chatapp.data

import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.util.concurrent.ConcurrentHashMap

@Serializable
data class ContactRow(
    val owner: String,
    val contact: String,
    val backup: Boolean = true,
)

/**
 * بيحفظ على السيرفر "أنا بكلّم مين" (الأشخاص بس، مش الرسايل) علشان:
 *  1) أستعيدهم لو التطبيق اتمسح (بيتحكّم فيها الإعداد backupContacts، افتراضيًا شغّال)
 *  2) شرط ظهور الستوري: مين حفظته (بعتلي أو بعتله) هو بس اللي يشوف الستوريز بتاعتي.
 *     العلاقة دي بتتسجّل دايمًا، والإعداد بيتحكّم بس في ظهورها في الاستعادة (backup).
 */
object ContactSync {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val done = ConcurrentHashMap.newKeySet<String>()   // اللي اتسجّل في الجلسة دي (بقيمة backup الحالية)

    private fun uuidOrNull(s: String): String? =
        runCatching { java.util.UUID.fromString(s).toString() }.getOrNull()

    /** تسجيل شخص بعد رسالة مرسلة/مستلمة (محادثات فردية بس: مش مجموعات ولا نفسي ولا بوتات). */
    fun note(peerId: String) {
        val uid = AuthRepository.currentUserId ?: return
        val id = uuidOrNull(SpaceStore.realId(peerId)) ?: return
        if (id == uid) return
        val b = AppSettings.now.backupContacts
        if (!done.add("$id:$b")) return
        scope.launch {
            runCatching { Supa.client.from("contacts").upsert(ContactRow(uid, id, b)) }
                .onFailure { done.remove("$id:$b") }
        }
    }

    /** مزامنة كل اللي في المحادثات المحلية (بعد التحديث/تغيير الإعداد). */
    fun syncAll() {
        val uid = AuthRepository.currentUserId ?: return
        scope.launch {
            runCatching {
                val b = AppSettings.now.backupContacts
                val ids = ChatEngine.dao.observeLastOnce().map { it.peerId }
                    .filter { !it.startsWith("g:") }
                    .mapNotNull { uuidOrNull(SpaceStore.realId(it)) }
                    .filter { it != uid }.distinct()
                if (ids.isNotEmpty()) {
                    Supa.client.from("contacts").upsert(ids.map { ContactRow(uid, it, b) })
                    ids.forEach { done.add("$it:$b") }
                }
            }
        }
    }

    /** المحفوظين للاستعادة (backup = true). */
    suspend fun restorable(): List<Profile> {
        val uid = AuthRepository.currentUserId ?: return emptyList()
        val rows = Supa.client.from("contacts").select {
            filter { eq("owner", uid); eq("backup", true) }
        }.decodeList<ContactRow>()
        return ProfileRepository.byIds(rows.map { it.contact }).sortedBy { it.displayName.lowercase() }
    }

    // ------------------------------------------------------------ تحكمات الستوري

    @Serializable
    data class StoryContact(
        val contact: String,
        @SerialName("hide_stories") val hideStories: Boolean = false,
        @SerialName("allow_stories") val allowStories: Boolean = false,
    )

    @Serializable
    private data class PrefRow(val owner: String, val mode: String)

    @Serializable
    private data class HideRow(@SerialName("hide_stories") val hide: Boolean)

    @Serializable
    private data class AllowRow(@SerialName("allow_stories") val allow: Boolean)

    /** كل اللي حافظهم (بغض النظر عن إعداد الاستعادة) مع حالة الستوري لكل واحد. */
    suspend fun storyContacts(): List<Pair<Profile, StoryContact>> {
        val uid = AuthRepository.currentUserId ?: return emptyList()
        val rows = Supa.client.from("contacts").select { filter { eq("owner", uid) } }.decodeList<StoryContact>()
        val profs = ProfileRepository.byIds(rows.map { it.contact }).associateBy { it.id }
        return rows.mapNotNull { r -> profs[r.contact]?.let { it to r } }.sortedBy { it.first.displayName.lowercase() }
    }

    suspend fun storyMode(): String {
        val uid = AuthRepository.currentUserId ?: return "contacts"
        return Supa.client.from("story_prefs").select { filter { eq("owner", uid) } }
            .decodeList<PrefRow>().firstOrNull()?.mode ?: "contacts"
    }

    suspend fun setStoryMode(mode: String) {
        val uid = AuthRepository.currentUserId ?: return
        Supa.client.from("story_prefs").upsert(PrefRow(uid, mode))
    }

    private suspend fun ensure(uid: String, id: String) {
        runCatching { Supa.client.from("contacts").insert(ContactRow(uid, id, AppSettings.now.backupContacts)) }   // لو موجود بيفشل ولا يهم
    }

    suspend fun setHidden(peerId: String, hide: Boolean) {
        val uid = AuthRepository.currentUserId ?: return
        val id = uuidOrNull(SpaceStore.realId(peerId)) ?: return
        ensure(uid, id)
        Supa.client.from("contacts").update(HideRow(hide)) { filter { eq("owner", uid); eq("contact", id) } }
    }

    suspend fun setAllowed(peerId: String, allow: Boolean) {
        val uid = AuthRepository.currentUserId ?: return
        val id = uuidOrNull(SpaceStore.realId(peerId)) ?: return
        ensure(uid, id)
        Supa.client.from("contacts").update(AllowRow(allow)) { filter { eq("owner", uid); eq("contact", id) } }
    }

    suspend fun isHidden(peerId: String): Boolean {
        val uid = AuthRepository.currentUserId ?: return false
        val id = uuidOrNull(SpaceStore.realId(peerId)) ?: return false
        return Supa.client.from("contacts").select { filter { eq("owner", uid); eq("contact", id) } }
            .decodeList<StoryContact>().firstOrNull()?.hideStories ?: false
    }
}
