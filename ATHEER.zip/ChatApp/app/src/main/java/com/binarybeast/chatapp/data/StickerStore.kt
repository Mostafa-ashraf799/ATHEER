package com.binarybeast.chatapp.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** ستيكراتي وGIFاتي المحفوظة: بنحفظ بس file_id (الملف نفسه على تيليجرام)، فالإرسال فوري من غير رفع تاني. */
object StickerStore {
    data class Item(val fileId: String, val kind: String)   // kind = sticker | gif

    private lateinit var sp: SharedPreferences
    private val _items = MutableStateFlow<List<Item>>(emptyList())
    val items: StateFlow<List<Item>> = _items.asStateFlow()

    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences(Accounts.name("stickers"), Context.MODE_PRIVATE)
        _items.value = runCatching {
            val a = JSONArray(sp.getString("items", "[]"))
            List(a.length()) { val o = a.getJSONObject(it); Item(o.getString("id"), o.getString("k")) }
        }.getOrDefault(emptyList())
    }

    private fun save(list: List<Item>) {
        _items.value = list
        if (::sp.isInitialized) sp.edit().putString("items", JSONArray().apply {
            list.forEach { put(JSONObject().put("id", it.fileId).put("k", it.kind)) }
        }.toString()).apply()
    }

    fun add(fileId: String, kind: String) {
        if (_items.value.any { it.fileId == fileId }) return
        save(listOf(Item(fileId, kind)) + _items.value)
    }

    fun remove(fileId: String) = save(_items.value.filterNot { it.fileId == fileId })
    fun has(fileId: String) = _items.value.any { it.fileId == fileId }
    fun clear() = save(emptyList())
}
