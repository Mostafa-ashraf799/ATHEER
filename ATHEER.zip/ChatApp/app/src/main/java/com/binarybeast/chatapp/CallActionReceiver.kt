package com.binarybeast.chatapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.binarybeast.chatapp.call.CallManager

/** زر «رفض» في إشعار المكالمة: بيرفض من غير ما يفتح التطبيق. */
class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Notifier.ACTION_DECLINE) {
            runCatching { CallManager.reject() }
            Notifier.cancelCall(context)
        }
    }
}
