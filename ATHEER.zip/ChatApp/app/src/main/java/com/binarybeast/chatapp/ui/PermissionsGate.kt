package com.binarybeast.chatapp.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

/** أذونات التشغيل: بتتطلب كلها في الأول مرة، واستثناء البطارية إجباري (من غيره النظام بيقفل استقبال الرسايل). */
object Perms {
    fun batteryOk(ctx: Context): Boolean =
        runCatching { (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName) }.getOrDefault(true)

    fun runtimeList(): Array<String> = buildList {
        if (Build.VERSION.SDK_INT >= 33) {
            add(Manifest.permission.POST_NOTIFICATIONS)
            add(Manifest.permission.READ_MEDIA_IMAGES)
            add(Manifest.permission.READ_MEDIA_VIDEO)
        } else add(Manifest.permission.READ_EXTERNAL_STORAGE)
        add(Manifest.permission.CAMERA)
        add(Manifest.permission.RECORD_AUDIO)
    }.toTypedArray()

    fun missing(ctx: Context): List<String> =
        runtimeList().filter { ContextCompat.checkSelfPermission(ctx, it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
}

@Composable
fun PermissionsScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val battery = remember(tick) { Perms.batteryOk(ctx) }
    var askedRuntime by remember { mutableStateOf(false) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    androidx.compose.runtime.LaunchedEffect(battery) { if (battery) onDone() }

    val batteryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { tick++ }
    fun askBattery() {
        AppLock.skipNext()
        runCatching {
            batteryLauncher.launch(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)))
        }.onFailure {
            runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }
    val runtimeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        askedRuntime = true
        askBattery()
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Spacer(Modifier.height(24.dp))
        Text("خطوة أخيرة قبل ما نبدأ", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("🔋 استثناء البطارية (إجباري)", fontWeight = FontWeight.SemiBold)
        Text(
            "التطبيق مش بيستخدم Firebase ولا أي خدمة إشعارات من جوجل أو طرف تالت، علشان محتوى رسايلك ومين بتكلّمه مايعديش على أي سيرفر إشعارات خارجي، وده للأمان وخصوصيتك. " +
                "بدل كده بيفضل جزء صغير جدًا من التطبيق شغّال في الخلفية (بإشعار صامت) وبيستقبل الرسايل والمكالمات مباشرة. " +
                "لازم تسمح باستثناء البطارية علشان النظام ميقفلوش، ومن غيره الرسايل مش هتوصلك والتطبيق مقفول.",
            Modifier.padding(bottom = 16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text("🔔 باقي الأذونات", fontWeight = FontWeight.SemiBold)
        Text(
            "• الإشعارات: علشان تعرف إن وصلتك رسالة أو مكالمة.\n" +
                "• الكاميرا والميكروفون: للمكالمات والصور والفيديو والرسايل الصوتية.\n" +
                "• الصور والفيديو: علشان تبعت ملفات من جهازك.\n" +
                "كل ده بيتطلب مرة واحدة دلوقتي، وتقدر تغيّره بعدين من إعدادات الجهاز.",
            Modifier.padding(bottom = 24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Button(onClick = {
            val miss = Perms.missing(ctx)
            if (miss.isNotEmpty() && !askedRuntime) { AppLock.skipNext(); runtimeLauncher.launch(miss.toTypedArray()) } else askBattery()
        }, Modifier.fillMaxWidth()) { Text(if (askedRuntime) "اسمح باستثناء البطارية" else "السماح بكل الأذونات") }
        TextButton(onClick = {
            runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }, Modifier.fillMaxWidth()) { Text("لو الشاشة ماظهرتش: افتح إعدادات البطارية يدويًا واختار «بدون قيود»") }
    }
}
