package com.binarybeast.chatapp.data

import com.binarybeast.chatapp.BuildConfig
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import io.github.jan.supabase.postgrest.query.Columns
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * البوتات (زي بوتات تيليجرام): Bot API على Supabase Edge Function اسمها bot-api.
 * محادثات البوت بتعدّي على السيرفر (البوت لازم يقرأ الرسالة) فمش end-to-end زي الشات العادي.
 */
@Serializable
data class BotCommand(val command: String, val description: String = "")

@Serializable
data class BotInfo(
    val id: String,
    @SerialName("num_id") val numId: Long = 0,
    @SerialName("owner_id") val ownerId: String? = null,
    val username: String,
    val name: String,
    val about: String = "",
    val kind: String = "external",
    val commands: List<BotCommand> = emptyList(),
    val description: String = "",
    @SerialName("avatar_url") val avatarUrl: String? = null,
    @SerialName("join_groups") val joinGroups: Boolean = true,
    @SerialName("group_privacy") val groupPrivacy: Boolean = true,
) {
    val isBuiltin get() = kind == "builtin"
    val isQueenBee get() = kind == "builtin" && username.equals(BotRepository.QUEEN_USERNAME, true)
    val isMaker get() = kind == "builtin" && username.equals(BotRepository.MAKER_USERNAME, true)
}

@Serializable
data class GroupBotMsg(
    val id: Long,
    @SerialName("bot_id") val botId: String = "",
    val text: String? = null,
    @SerialName("parse_mode") val parseMode: String? = null,
    @SerialName("reply_markup") val replyMarkup: JsonObject? = null,
    @SerialName("reply_to") val replyTo: Long? = null,
    @SerialName("created_at") val createdAt: String = "",
)

@Serializable
data class GroupBotInfo(
    val id: String,
    @SerialName("num_id") val numId: Long = 0,
    val username: String,
    val name: String,
    @SerialName("avatar_url") val avatarUrl: String? = null,
    val kind: String = "external",
    @SerialName("group_privacy") val groupPrivacy: Boolean = true,
    @SerialName("added_by_me") val addedByMe: Boolean = false,
)

@Serializable
data class BotMsg(
    val id: Long,
    @SerialName("bot_id") val botId: String = "",
    @SerialName("from_bot") val fromBot: Boolean,
    val text: String? = null,
    @SerialName("photo_url") val photoUrl: String? = null,
    @SerialName("reply_markup") val replyMarkup: JsonObject? = null,
    @SerialName("parse_mode") val parseMode: String? = null,
    val edited: Boolean = false,
    @SerialName("created_at") val createdAt: String = "",
)

@Serializable
data class BotCallbackRow(
    val id: String,
    val answered: Boolean = false,
    @SerialName("answer_text") val answerText: String? = null,
    @SerialName("answer_alert") val answerAlert: Boolean = false,
)

@Serializable
data class ChannelBotRow(@SerialName("channel_id") val channelId: Long, @SerialName("bot_id") val botId: String)

data class BotButton(val text: String, val data: String?, val url: String?)

/** الأزرار اللي تحت الرسالة (inline_keyboard). */
fun JsonObject?.inlineButtons(): List<List<BotButton>> {
    val rows = this?.get("inline_keyboard") as? JsonArray ?: return emptyList()
    return rows.map { r ->
        (r as? JsonArray ?: JsonArray(emptyList())).mapNotNull { b ->
            val o = b as? JsonObject ?: return@mapNotNull null
            val t = (o["text"] as? JsonPrimitive)?.contentOrNull ?: return@mapNotNull null
            BotButton(t, (o["callback_data"] as? JsonPrimitive)?.contentOrNull, (o["url"] as? JsonPrimitive)?.contentOrNull)
        }
    }.filter { it.isNotEmpty() }
}

/** كيبورد الرد (reply keyboard). */
fun JsonObject?.replyKeyboard(): List<List<String>> {
    val rows = this?.get("keyboard") as? JsonArray ?: return emptyList()
    return rows.map { r ->
        (r as? JsonArray ?: JsonArray(emptyList())).mapNotNull { b -> ((b as? JsonObject)?.get("text") as? JsonPrimitive)?.contentOrNull }
    }.filter { it.isNotEmpty() }
}

object BotRepository {
    private val http = OkHttpClient.Builder().callTimeout(60, TimeUnit.SECONDS).build()
    private val me get() = AuthRepository.currentUserId ?: error("not signed in")
    private const val BOT_COLS = "id,num_id,owner_id,username,name,about,kind,commands,description,avatar_url,join_groups,group_privacy"

    const val QUEEN_USERNAME = "QwenBot"
    const val MAKER_USERNAME = "BotMakerBot"
    val baseUrl: String get() = BuildConfig.BOT_URL + "/bot"

    /** نداء بوابة التطبيق (JWT بتاع المستخدم). بيرمي Exception برسالة الخطأ لو فشل. */
    suspend fun gateway(body: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        val jwt = Supa.client.auth.currentAccessTokenOrNull() ?: error("مفيش جلسة")
        val req = Request.Builder().url(BuildConfig.BOT_URL + "/gateway")
            .header("Authorization", "Bearer $jwt").header("apikey", BuildConfig.SUPABASE_ANON_KEY)
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            val j = runCatching { JSONObject(txt) }.getOrNull() ?: error("رد غير متوقع من السيرفر (${r.code})")
            if (!j.optBoolean("ok", false)) error(j.optString("description").removePrefix("Bad Request: ").ifBlank { "فشل (${r.code})" })
            j
        }
    }

    /** بوتاتي أنا بس (البوتات مش بتتصفّح — الباقي بالبحث باليوزرنيم بالظبط). */
    suspend fun mine(): List<BotInfo> =
        Supa.client.from("bots").select(Columns.raw(BOT_COLS)) { filter { eq("owner_id", me) }; order("created_at", Order.ASCENDING) }.decodeList()

    /** بحث باليوزرنيم بالظبط (بدون @ أو معاه). */
    suspend fun byUsername(raw: String): BotInfo? {
        val u = raw.trim().removePrefix("@")
        if (!Regex("[A-Za-z][A-Za-z0-9_]{2,31}").matches(u)) return null
        return Supa.client.postgrest.rpc("find_bot", buildJsonObject { put("p_username", u) }).decodeList<BotInfo>().firstOrNull()
    }

    suspend fun byIds(ids: Collection<String>): List<BotInfo> {
        if (ids.isEmpty()) return emptyList()
        return Supa.client.postgrest.rpc("bots_by_ids", buildJsonObject { put("p_ids", JsonArray(ids.distinct().map { JsonPrimitive(it) })) }).decodeList()
    }

    /** البوتات اللي بدأت معاها محادثة (للظهور في قائمة الشات) + آخر رسالة. */
    suspend fun chatted(): List<Pair<BotInfo, BotMsg?>> {
        val rows = Supa.client.from("bot_messages").select(Columns.raw("id,bot_id,from_bot,text,created_at")) {
            filter { eq("user_id", me) }; order("id", Order.DESCENDING); limit(300)
        }.decodeList<BotMsg>()
        val last = rows.groupBy { it.botId }.mapValues { it.value.first() }
        val bots = byIds(last.keys).associateBy { it.id }
        return last.mapNotNull { (id, m) -> bots[id]?.let { it to m as BotMsg? } }
    }

    suspend fun messages(botId: String, limit: Long = 120): List<BotMsg> =
        Supa.client.from("bot_messages").select {
            filter { eq("bot_id", botId); eq("user_id", me) }
            order("id", Order.DESCENDING)
            limit(limit)
        }.decodeList<BotMsg>().reversed()

    suspend fun send(botId: String, text: String) {
        gateway(JSONObject().put("action", "send").put("bot_id", botId).put("text", text))
    }

    /** ضغط زرار. بيرجّع إجابة البوت (answerCallbackQuery) لو جت خلال ثواني. */
    suspend fun press(botId: String, messageId: Long, data: String, channelId: Long? = null): BotCallbackRow? {
        val j = gateway(JSONObject().put("action", "press").put("bot_id", botId).put("message_id", messageId).put("data", data)
            .apply { channelId?.let { put("channel_id", it) } })
        val id = j.optString("callback_id")
        if (id.isBlank()) return null
        repeat(10) {
            val row = runCatching {
                Supa.client.from("bot_callbacks").select { filter { eq("id", id) } }.decodeSingleOrNull<BotCallbackRow>()
            }.getOrNull()
            if (row?.answered == true) return row
            delay(400)
        }
        return null
    }

    suspend fun createBot(name: String, username: String): JSONObject =
        gateway(JSONObject().put("action", "create_bot").put("name", name).put("username", username))
    suspend fun rotateToken(botId: String): String = gateway(JSONObject().put("action", "rotate_token").put("bot_id", botId)).getString("token")
    suspend fun getToken(botId: String): String = gateway(JSONObject().put("action", "get_token").put("bot_id", botId)).getString("token")
    suspend fun deleteBot(botId: String) { gateway(JSONObject().put("action", "delete_bot").put("bot_id", botId)) }
    suspend fun clearChat(botId: String) { gateway(JSONObject().put("action", "clear_chat").put("bot_id", botId)) }
    suspend fun addToChannel(botId: String, channelId: Long) { gateway(JSONObject().put("action", "add_to_channel").put("bot_id", botId).put("channel_id", channelId)) }
    suspend fun removeFromChannel(botId: String, channelId: Long) { gateway(JSONObject().put("action", "remove_from_channel").put("bot_id", botId).put("channel_id", channelId)) }

    // ---- المجموعات
    suspend fun groupAddBot(groupId: String, title: String, botId: String) {
        gateway(JSONObject().put("action", "group_add_bot").put("group_id", groupId).put("title", title).put("bot_id", botId))
    }
    suspend fun groupRemoveBot(groupId: String, botId: String) {
        gateway(JSONObject().put("action", "group_remove_bot").put("group_id", groupId).put("bot_id", botId))
    }
    suspend fun groupBots(groupId: String): List<GroupBotInfo> {
        val arr = gateway(JSONObject().put("action", "group_bots").put("group_id", groupId)).getJSONArray("bots")
        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true; coerceInputValues = true }
        return json.decodeFromString(arr.toString())
    }
    /** بيبعت رسالة المجموعة للبوتات اللي المفروض تشوفها (حسب وضع الخصوصية). */
    suspend fun groupSend(groupId: String, text: String, replyBotId: String? = null) {
        gateway(JSONObject().put("action", "group_send").put("group_id", groupId).put("text", text).apply { replyBotId?.let { put("reply_bot_id", it) } })
    }
    suspend fun groupFetch(groupId: String): List<GroupBotMsg> {
        val arr = gateway(JSONObject().put("action", "group_fetch").put("group_id", groupId)).getJSONArray("messages")
        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true; coerceInputValues = true }
        return json.decodeFromString(arr.toString())
    }
    suspend fun groupPress(groupId: String, messageId: Long, data: String): BotCallbackRow? {
        val j = gateway(JSONObject().put("action", "group_press").put("group_id", groupId).put("message_id", messageId).put("data", data))
        val id = j.optString("callback_id")
        if (id.isBlank()) return null
        repeat(10) {
            val row = runCatching { Supa.client.from("bot_callbacks").select { filter { eq("id", id) } }.decodeSingleOrNull<BotCallbackRow>() }.getOrNull()
            if (row?.answered == true) return row
            delay(400)
        }
        return null
    }

    suspend fun channelBots(channelId: Long): List<String> =
        Supa.client.from("channel_bots").select { filter { eq("channel_id", channelId) } }.decodeList<ChannelBotRow>().map { it.botId }
}
