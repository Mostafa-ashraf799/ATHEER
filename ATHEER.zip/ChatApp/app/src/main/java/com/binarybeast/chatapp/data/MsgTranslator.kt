package com.binarybeast.chatapp.data

import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** ترجمة الرسايل على الجهاز (ML Kit). نص الرسالة مبيخرجش من الموبايل؛ بس نموذج اللغة بيتحمّل مرة واحدة. */
object MsgTranslator {
    private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { c ->
        addOnSuccessListener { c.resume(it) }
        addOnFailureListener { c.resumeWithException(it) }
    }

    /** يرجّع (النص المترجم، كود اللغة الأصلية). */
    suspend fun translate(text: String, targetCode: String): Pair<String, String> {
        val idClient = LanguageIdentification.getClient()
        val detected = try { idClient.identifyLanguage(text).await() } finally { idClient.close() }
        val srcCode = if (detected == "und") (if (text.any { it in '\u0600'..'\u06FF' }) "ar" else "en") else detected
        val src = TranslateLanguage.fromLanguageTag(srcCode) ?: error("unsupported source: $srcCode")
        val dst = TranslateLanguage.fromLanguageTag(targetCode) ?: error("unsupported target: $targetCode")
        if (src == dst) return text to srcCode
        val tr = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build())
        try {
            tr.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            return tr.translate(text).await() to srcCode
        } finally { tr.close() }
    }
}
