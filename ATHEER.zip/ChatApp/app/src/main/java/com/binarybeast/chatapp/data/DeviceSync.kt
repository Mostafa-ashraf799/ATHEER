package com.binarybeast.chatapp.data

import com.binarybeast.chatapp.call.CallManager
import com.binarybeast.chatapp.data.local.LocalMessage
import com.binarybeast.chatapp.data.local.MsgStatus
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * نفق P2P منفصل بين أجهزتك (WebRTC DataChannel) لمزامنة الشات.
 *  - بيانات المزامنة (رسايل، تفاعلات، تعديل، حذف، قراءة) بتمشي مباشرة بين الأجهزة، مش عن طريق أي سيرفر.
 *  - تأسيس الاتصال (SDP/ICE) بيعدّي كـ «blobs» مشفّرة بمفتاح الأجهزة (AES-GCM): السيرفر مبيشوفش غير نص مشفّر.
 *  - لو جهاز كان أوفلاين: أول ما النفق يفتح بنبعت له اللي فاته (آخر ٣٠ يوم).
 */
object DeviceSync {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val tuns = ConcurrentHashMap<String, Tun>()
    private var loopJob: Job? = null

    /** الأجهزة المتصلة بنفق مفتوح دلوقتي. */
    val connected = MutableStateFlow<Set<String>>(emptySet())
    private const val SYNC_DAYS = 30L

    private class Tun(val devId: String, val sid: String) {
        @Volatile var open = false
        @Volatile var failed = false
        val createdAt = System.currentTimeMillis()
        var pc: PeerConnection? = null
        var dc: DataChannel? = null
        var remoteSet = false
        val pendingIce = mutableListOf<IceCandidate>()
        val parts = HashMap<String, Array<String?>>()
        val sendLock = Mutex()
        fun close() {
            open = false
            runCatching { dc?.close() }; runCatching { dc?.dispose() }; runCatching { pc?.close() }
            dc = null; pc = null
        }
    }

    private val uid: String? get() = AuthRepository.currentUserId
    private fun sigKey(): ByteArray? = DeviceStore.syncKey(false)?.let { LinkCrypt.sha256(it, "sig".toByteArray()) }

    // ------------------------------------------------------------------ دورة الحياة
    fun start() {
        if (loopJob?.isActive == true) return
        loopJob = scope.launch {
            while (true) {
                runCatching { if (DeviceStore.isLinked()) ensureAll() }
                delay(40_000)
            }
        }
    }

    fun stop() {
        loopJob?.cancel(); loopJob = null
        tuns.values.forEach { it.close() }; tuns.clear(); connected.value = emptySet()
    }

    /** ابدأ/جدّد الاتصال دلوقتي (بعد الربط أو رجوع النت). */
    fun kick() { start(); scope.launch { runCatching { ensureAll() } } }

    private suspend fun ensureAll() {
        for (d in DeviceStore.list()) ensure(d.id)
    }

    private suspend fun ensure(devId: String) {
        if (uid == null || sigKey() == null) return
        val t = tuns[devId]
        if (t != null && (t.open || System.currentTimeMillis() - t.createdAt < 25_000)) return
        t?.close(); tuns.remove(devId); refreshConnected()
        if (DeviceStore.myId() < devId) startOffer(devId)
        else signal(UUID.randomUUID().toString(), "hello", JSONObject().put("src", DeviceStore.myId()).put("dst", devId))
    }

    private fun refreshConnected() { connected.value = tuns.values.filter { it.open }.map { it.devId }.toSet() }

    // ------------------------------------------------------------------ إشارات (مشفّرة)
    private suspend fun signal(sid: String, type: String, inner: JSONObject) {
        val me = uid ?: return
        val k = sigKey() ?: return
        val blob = LinkCrypt.b64(LinkCrypt.enc(k, inner.toString().toByteArray()))
        Supa.client.from("call_signals").insert(NewCallSignal(sid, me, me, type, false, buildJsonObject { put("e", blob) }, purpose = "chat"))
    }

    /** بتتنده من ChatEngine لما توصل إشارة من نفس حسابي (from == to == أنا). */
    suspend fun onSignal(s: CallSignal) {
        val k = sigKey() ?: return
        val blob = ((s.payload as? JsonObject)?.get("e"))?.jsonPrimitive?.contentOrNull ?: return
        val j = try { JSONObject(String(LinkCrypt.dec(k, LinkCrypt.unb64(blob)))) } catch (e: Exception) { return }
        val src = j.optString("src"); val dst = j.optString("dst")
        if (dst != DeviceStore.myId() || src == DeviceStore.myId() || src in DeviceStore.removedIds()) return
        if (DeviceStore.list().none { it.id == src }) return   // جهاز معروف بس
        when (s.type) {
            "hello" -> { if (DeviceStore.myId() < src && tuns[src]?.open != true) startOffer(src) }
            "offer" -> {
                tuns.remove(src)?.close()
                val t = Tun(src, s.callId); tuns[src] = t
                val pc = newPc(t); t.pc = pc
                pc.setRemote(SessionDescription(SessionDescription.Type.OFFER, j.optString("sdp")))
                t.remoteSet = true; drainIce(t)
                val ans = pc.createAnswerAwait(); pc.setLocal(ans)
                signal(s.callId, "answer", JSONObject().put("src", DeviceStore.myId()).put("dst", src).put("sdp", ans.description))
            }
            "answer" -> {
                val t = tuns[src] ?: return
                if (t.sid != s.callId) return
                t.pc?.setRemote(SessionDescription(SessionDescription.Type.ANSWER, j.optString("sdp")))
                t.remoteSet = true; drainIce(t)
            }
            "ice" -> {
                val t = tuns[src] ?: return
                if (t.sid != s.callId) return
                val c = IceCandidate(j.optString("mid"), j.optInt("idx"), j.optString("cand"))
                if (t.remoteSet) t.pc?.addIceCandidate(c) else synchronized(t.pendingIce) { t.pendingIce += c }
            }
        }
    }

    private fun drainIce(t: Tun) {
        val l = synchronized(t.pendingIce) { t.pendingIce.toList().also { t.pendingIce.clear() } }
        l.forEach { t.pc?.addIceCandidate(it) }
    }

    private suspend fun startOffer(devId: String) {
        tuns.remove(devId)?.close()
        val sid = UUID.randomUUID().toString()
        val t = Tun(devId, sid); tuns[devId] = t
        val pc = newPc(t); t.pc = pc
        attach(t, pc.createDataChannel("dev", DataChannel.Init().apply { ordered = true }))
        val offer = pc.createOfferAwait(); pc.setLocal(offer)
        signal(sid, "offer", JSONObject().put("src", DeviceStore.myId()).put("dst", devId).put("sdp", offer.description))
    }

    private fun newPc(t: Tun): PeerConnection {
        val cfg = PeerConnection.RTCConfiguration(CallManager.iceServers()).apply { sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN }
        return CallManager.factory.createPeerConnection(cfg, object : PeerConnection.Observer {
            override fun onIceCandidate(c: IceCandidate) {
                scope.launch { runCatching { signal(t.sid, "ice", JSONObject().put("src", DeviceStore.myId()).put("dst", t.devId).put("mid", c.sdpMid ?: "").put("idx", c.sdpMLineIndex).put("cand", c.sdp)) } }
            }
            override fun onDataChannel(d: DataChannel) { attach(t, d) }
            override fun onConnectionChange(s: PeerConnection.PeerConnectionState) {
                if (s == PeerConnection.PeerConnectionState.FAILED || s == PeerConnection.PeerConnectionState.CLOSED || s == PeerConnection.PeerConnectionState.DISCONNECTED) {
                    t.failed = true; t.open = false
                    if (tuns[t.devId] === t) tuns.remove(t.devId)
                    t.close(); refreshConnected()
                }
            }
            override fun onSignalingChange(s: PeerConnection.SignalingState) {}
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState) {}
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState) {}
            override fun onIceCandidatesRemoved(c: Array<out IceCandidate>) {}
            override fun onAddStream(s: MediaStream) {}
            override fun onRemoveStream(s: MediaStream) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(r: RtpReceiver, s: Array<out MediaStream>) {}
        })!!
    }

    private fun attach(t: Tun, dc: DataChannel) {
        t.dc = dc
        dc.registerObserver(object : DataChannel.Observer {
            override fun onBufferedAmountChange(previous: Long) {}
            override fun onStateChange() {
                val nowOpen = dc.state() == DataChannel.State.OPEN
                if (nowOpen && !t.open) { t.open = true; refreshConnected(); scope.launch { runCatching { onOpen(t) } } }
                if (!nowOpen) { t.open = false; refreshConnected() }
            }
            override fun onMessage(buffer: DataChannel.Buffer) {
                val bytes = ByteArray(buffer.data.remaining()).also { buffer.data.get(it) }
                scope.launch { runCatching { onFrame(t, String(bytes)) } }
            }
        })
        if (dc.state() == DataChannel.State.OPEN && !t.open) { t.open = true; refreshConnected(); scope.launch { runCatching { onOpen(t) } } }
    }

    // ------------------------------------------------------------------ إرسال (بتقطيع وضغط خفيف على الذاكرة)
    private suspend fun send(t: Tun, o: JSONObject) {
        val text = o.toString()
        t.sendLock.withLock {
            val ch = t.dc ?: return
            suspend fun raw(s: String) {
                var waits = 0
                while ((ch.bufferedAmount()) > 1_000_000L && waits++ < 500) delay(20)
                check(ch.send(DataChannel.Buffer(ByteBuffer.wrap(s.toByteArray()), false))) { "send failed" }
            }
            if (text.length <= 8000) { raw(text); return }
            val id = UUID.randomUUID().toString().take(8)
            val chunks = text.chunked(8000)
            chunks.forEachIndexed { i, d -> raw(JSONObject().put("k", "part").put("id", id).put("i", i).put("n", chunks.size).put("d", d).toString()) }
        }
    }

    private suspend fun broadcast(o: JSONObject) {
        for (t in tuns.values.toList()) if (t.open) runCatching { send(t, o) }
    }

    // ------------------------------------------------------------------ عند فتح النفق: تعريف + اللي فات
    private suspend fun onOpen(t: Tun) {
        DeviceStore.seen(t.devId)
        val devs = JSONArray()
        DeviceStore.list().forEach { devs.put(JSONObject().put("id", it.id).put("name", it.name).put("at", it.addedAt)) }
        devs.put(JSONObject().put("id", DeviceStore.myId()).put("name", DeviceStore.myName()).put("at", 0))
        send(t, JSONObject().put("k", "hello").put("devs", devs).put("removed", JSONArray(DeviceStore.removedIds().toList())))
        val groups = JSONArray(); runCatching { ChatEngine.groups.all() }.getOrDefault(emptyList()).forEach { groups.put(it.toSyncJson()) }
        send(t, JSONObject().put("k", "groups").put("list", groups))
        val since = System.currentTimeMillis() - SYNC_DAYS * 86_400_000L
        val have = JSONArray()
        ChatEngine.dao.since(since).filter { syncable(it) }.forEach { have.put(it.msgId.take(12)) }
        send(t, JSONObject().put("k", "have").put("since", since).put("ids", have))
    }

    // ------------------------------------------------------------------ استقبال
    private suspend fun onFrame(t: Tun, text: String) {
        var j = JSONObject(text)
        if (j.optString("k") == "part") {
            val id = j.getString("id"); val n = j.getInt("n")
            if (n !in 1..2000) return
            val arr = t.parts.getOrPut(id) { arrayOfNulls(n) }
            arr[j.getInt("i")] = j.getString("d")
            if (arr.any { it == null }) return
            t.parts.remove(id)
            j = JSONObject(arr.joinToString(""))
        }
        when (j.optString("k")) {
            "hello" -> {
                val removed = j.optJSONArray("removed")?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()
                if (DeviceStore.myId() in removed) { DeviceControl.removedByOwner(); return }
                DeviceStore.mergeRemoved(removed)
                j.optJSONArray("devs")?.let { a -> for (i in 0 until a.length()) { val o = a.getJSONObject(i); DeviceStore.upsert(DeviceStore.Dev(o.getString("id"), o.optString("name"), o.optLong("at").takeIf { it > 0 } ?: System.currentTimeMillis(), System.currentTimeMillis())) } }
                DeviceStore.seen(t.devId)
                scope.launch { runCatching { ensureAll() } }   // أجهزة جديدة اتعرّفنا عليها
            }
            "unlink" -> DeviceControl.removedByOwner()
            "groups" -> j.optJSONArray("list")?.let { a ->
                for (i in 0 until a.length()) runCatching { val g = groupFromSync(a.getJSONObject(i)); if (ChatEngine.groups.get(g.groupId) == null) ChatEngine.groups.upsert(g) }
            }
            "have" -> {
                val theirs = j.optJSONArray("ids")?.let { a -> (0 until a.length()).map { a.getString(it) }.toHashSet() } ?: hashSetOf()
                val since = j.optLong("since", System.currentTimeMillis() - SYNC_DAYS * 86_400_000L)
                val missing = ChatEngine.dao.since(since).filter { syncable(it) && it.msgId.take(12) !in theirs }
                for (chunk in missing.chunked(60)) {
                    val a = JSONArray(); chunk.forEach { a.put(it.toSyncJson()) }
                    send(t, JSONObject().put("k", "msgs").put("list", a))
                }
            }
            "msgs" -> j.optJSONArray("list")?.let { a ->
                for (i in 0 until a.length()) runCatching {
                    val m = msgFromSync(a.getJSONObject(i))
                    if (SpaceStore.isSpace(m.peerId)) return@runCatching
                    ChatEngine.dao.insert(if (m.mine && m.status == MsgStatus.SENDING) m.copy(status = MsgStatus.SENT) else m)
                }
            }
            "op" -> applyOp(j)
        }
    }

    private suspend fun applyOp(o: JSONObject) {
        val dao = ChatEngine.dao
        val id = o.optString("id"); val p = o.optString("p")
        when (o.optString("o")) {
            "myreact" -> dao.setMyReaction(id, o.optString("e").ifEmpty { null })
            "theirreact" -> dao.setTheirReaction(p, id, o.optString("e").ifEmpty { null })
            "edit" -> dao.editBody(p, id, o.optString("b"), o.optBoolean("mine"), o.optString("s"))
            "purge" -> dao.purge(p, id, o.optBoolean("mine"), o.optString("s"))
            "readby" -> o.optJSONArray("ids")?.let { a -> dao.setReadByPeer(p, (0 until minOf(a.length(), 200)).map { a.getString(it) }) }
            "opened" -> dao.markOpenedMine(p, id, System.currentTimeMillis())
            "markread" -> dao.markRead(p)
            "delme" -> dao.deleteLocal(id)
        }
    }

    // ------------------------------------------------------------------ نقاط الربط مع ChatEngine
    fun pushMsg(m: LocalMessage) {
        if (!DeviceStore.isLinked() || !syncable(m)) return
        scope.launch { runCatching {
            val mm = if (m.mine && m.status == MsgStatus.SENDING) m.copy(status = MsgStatus.SENT) else m
            broadcast(JSONObject().put("k", "msgs").put("list", JSONArray().put(mm.toSyncJson())))
        } }
    }

    fun pushOp(o: JSONObject) {
        if (!DeviceStore.isLinked()) return
        scope.launch { runCatching { broadcast(JSONObject().put("k", "op").also { r -> o.keys().forEach { k -> r.put(k, o.get(k)) } }) } }
    }

    suspend fun sendUnlink(devId: String) {
        val t = tuns[devId] ?: return
        if (t.open) runCatching { send(t, JSONObject().put("k", "unlink")) }
    }

    // ------------------------------------------------------------------ SDP helpers
    private open class Sdp : SdpObserver {
        override fun onCreateSuccess(d: SessionDescription) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(e: String?) {}
        override fun onSetFailure(e: String?) {}
    }
    private suspend fun PeerConnection.createOfferAwait(): SessionDescription = suspendCancellableCoroutine { c ->
        createOffer(object : Sdp() {
            override fun onCreateSuccess(d: SessionDescription) = c.resumeWith(Result.success(d))
            override fun onCreateFailure(e: String?) = c.resumeWith(Result.failure(RuntimeException(e)))
        }, MediaConstraints())
    }
    private suspend fun PeerConnection.createAnswerAwait(): SessionDescription = suspendCancellableCoroutine { c ->
        createAnswer(object : Sdp() {
            override fun onCreateSuccess(d: SessionDescription) = c.resumeWith(Result.success(d))
            override fun onCreateFailure(e: String?) = c.resumeWith(Result.failure(RuntimeException(e)))
        }, MediaConstraints())
    }
    private suspend fun PeerConnection.setLocal(d: SessionDescription) = suspendCancellableCoroutine { c ->
        setLocalDescription(object : Sdp() {
            override fun onSetSuccess() = c.resumeWith(Result.success(Unit))
            override fun onSetFailure(e: String?) = c.resumeWith(Result.failure(RuntimeException(e)))
        }, d)
    }
    private suspend fun PeerConnection.setRemote(d: SessionDescription) = suspendCancellableCoroutine { c ->
        setRemoteDescription(object : Sdp() {
            override fun onSetSuccess() = c.resumeWith(Result.success(Unit))
            override fun onSetFailure(e: String?) = c.resumeWith(Result.failure(RuntimeException(e)))
        }, d)
    }
}
