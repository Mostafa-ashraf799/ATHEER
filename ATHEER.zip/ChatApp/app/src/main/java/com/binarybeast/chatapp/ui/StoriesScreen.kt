package com.binarybeast.chatapp.ui

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import com.binarybeast.chatapp.data.AppSettings
import com.binarybeast.chatapp.data.AuthRepository
import com.binarybeast.chatapp.data.ContactSync
import com.binarybeast.chatapp.data.StoryRepository
import kotlinx.coroutines.launch
import com.binarybeast.chatapp.data.Profile
import com.binarybeast.chatapp.data.StoryGroup
import kotlinx.coroutines.delay

private val DURATIONS = listOf(1.0 to "ساعة", 6.0 to "6 ساعات", 12.0 to "12 ساعة", 24.0 to "يوم", 48.0 to "يومين", 72.0 to "3 أيام", 168.0 to "أسبوع")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoriesScreen(me: Profile?, vm: StoriesVm = viewModel()) {
    val groups by vm.groups.collectAsState()
    val uploading by vm.uploading.collectAsState()
    val notice by vm.notice.collectAsState()
    var editing by remember { mutableStateOf<Pair<Uri, Boolean>?>(null) }
    var viewing by remember { mutableStateOf<StoryGroup?>(null) }
    var addMenu by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<com.binarybeast.chatapp.ui.EditedMedia?>(null) }
    var hours by remember { mutableStateOf(24.0) }
    var custom by remember { mutableStateOf("") }
    var allowRepost by remember { mutableStateOf(false) }
    var picks by remember { mutableStateOf<List<Profile>>(emptyList()) }
    var showPick by remember { mutableStateOf(false) }
    var showPrivacy by remember { mutableStateOf(false) }
    val prefs by AppSettings.prefs.collectAsState()

    val source = rememberMediaSource(onMedia = { uri, isVideo -> editing = uri to isVideo }, onFile = {})

    // المحرر (صور وفيديو بحد أقصى 30 ثانية) ثم النشر
    editing?.let { (uri, isVideo) ->
        MediaEditorScreen(
            uri = uri, isVideo = isVideo,
            onDone = { em -> editing = null; pending = em },
            onCancel = { editing = null },
        )
        return
    }

    pending?.let { em ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("الستوري تفضل قد إيه؟") },
            text = {
                Column {
                    DURATIONS.chunked(3).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            row.forEach { (h, label) ->
                                androidx.compose.material3.FilterChip(selected = hours == h && custom.isBlank(),
                                    onClick = { hours = h; custom = "" }, label = { Text(label) })
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("السماح بإعادة النشر", Modifier.weight(1f))
                        androidx.compose.material3.Switch(checked = allowRepost, onCheckedChange = { allowRepost = it })
                    }
                    androidx.compose.material3.TextButton(onClick = { showPick = true }) {
                        Text(if (picks.isEmpty()) "🏷 إشارة لأشخاص/مجموعات" else "🏷 اتشار لـ ${picks.size} — تعديل")
                    }
                    androidx.compose.material3.OutlinedTextField(
                        value = custom, onValueChange = { custom = it.filter { c -> c.isDigit() || c == '.' }.take(6) },
                        label = { Text("أو اكتب عدد الساعات (لحد 720)") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    )
                }
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    val h = custom.toDoubleOrNull() ?: hours
                    pending = null; vm.post(em.bytes, em.name, em.mime, em.caption, h, allowRepost, picks); allowRepost = false; picks = emptyList()
                }) { Text("نشر") }
            },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { pending = null }) { Text("إلغاء") } },
        )
    }

    if (showPick) PickChatsDialog("إشارة في الستوري", includeGroups = true, confirmLabel = "إشارة",
        onDone = { picks = it }, onClose = { showPick = false })

    val mine = groups.firstOrNull { it.user.id == AuthRepository.currentUserId }
    val othersAll = groups.filter { it.user.id != AuthRepository.currentUserId }
    val others = othersAll.filter { it.user.id !in prefs.mutedStories }
    val mutedGroups = othersAll.filter { it.user.id in prefs.mutedStories }
    var showMuted by remember { mutableStateOf(false) }

    Scaffold(topBar = { GlassTopBar(
        title = { Text("الستوريز", fontWeight = FontWeight.Bold) },
        actions = { androidx.compose.material3.TextButton(onClick = { showPrivacy = true }) { Text("🔒 الخصوصية") } },
    ) }) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize()) {
            // ستوري بتاعتي
            item {
                Row(
                    Modifier.fillMaxWidth().clickable { if (mine != null) viewing = mine else addMenu = true }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box {
                        Avatar(me?.avatarFileId, me?.displayName.orEmpty(), 56.dp,
                            ring = if (mine != null) MaterialTheme.colorScheme.primary else null)
                        Box(
                            Modifier.align(Alignment.BottomEnd).size(20.dp).clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary).clickable { addMenu = true },
                            contentAlignment = Alignment.Center,
                        ) { Icon(AIcons.Add, null, Modifier.size(14.dp), tint = Color.White) }
                        DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }) {
                            DropdownMenuItem(text = { Text("المعرض") }, leadingIcon = { Icon(AIcons.PhotoLibrary, null) },
                                onClick = { addMenu = false; source.gallery() })
                            DropdownMenuItem(text = { Text("كاميرا (صورة)") }, leadingIcon = { Icon(AIcons.CameraAlt, null) },
                                onClick = { addMenu = false; source.photo() })
                            DropdownMenuItem(text = { Text("كاميرا (فيديو)") }, leadingIcon = { Icon(AIcons.Videocam, null) },
                                onClick = { addMenu = false; source.video() })
                        }
                    }
                    Column(Modifier.padding(horizontal = 14.dp).weight(1f)) {
                        Text("ستوريتي", fontWeight = FontWeight.SemiBold)
                        Text(
                            notice ?: if (uploading) "جاري الرفع…" else if (mine != null) "${mine.stories.size}/5 ستوري نشطة" else "اضغط ➕ علشان تنزّل ستوري",
                            color = if (notice != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (uploading) CircularProgressIndicator(Modifier.size(20.dp))
                }
            }
            item {
                Text("آخر التحديثات", Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            }
            if (others.isEmpty()) item {
                Text("مفيش ستوريز من حد دلوقتي.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(others, key = { it.user.id }) { g ->
                Row(
                    Modifier.fillMaxWidth().clickable { viewing = g }.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Avatar(
                        g.user.avatarFileId, g.user.displayName.ifBlank { g.user.phone }, 56.dp,
                        ring = if (g.seen) Color.Gray else MaterialTheme.colorScheme.primary,
                    )
                    Column(Modifier.padding(horizontal = 14.dp).weight(1f)) {
                        Text(g.user.displayName.ifBlank { g.user.phone }, fontWeight = FontWeight.SemiBold)
                        Text(hhmm(g.stories.last().createdAt), color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.labelMedium)
                    }
                    androidx.compose.material3.TextButton(onClick = { AppSettings.toggleStoryMute(g.user.id) }) { Text("🔕 كتم") }
                }
            }
            if (mutedGroups.isNotEmpty()) {
                item {
                    androidx.compose.material3.TextButton(onClick = { showMuted = !showMuted }, modifier = Modifier.padding(horizontal = 8.dp)) {
                        Text("المكتومة (${mutedGroups.size}) " + if (showMuted) "▲" else "▼")
                    }
                }
                if (showMuted) items(mutedGroups, key = { "m" + it.user.id }) { g ->
                    Row(
                        Modifier.fillMaxWidth().clickable { viewing = g }.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Avatar(g.user.avatarFileId, g.user.displayName.ifBlank { g.user.phone }, 44.dp, ring = Color.Gray)
                        Text(g.user.displayName.ifBlank { g.user.phone }, Modifier.padding(horizontal = 14.dp).weight(1f),
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        androidx.compose.material3.TextButton(onClick = { AppSettings.toggleStoryMute(g.user.id) }) { Text("إلغاء الكتم") }
                    }
                }
            }
        }
    }

    if (showPrivacy) StoryPrivacyDialog { showPrivacy = false }

    viewing?.let { g ->
        StoryViewer(
            group = g,
            isMine = g.user.id == AuthRepository.currentUserId,
            onSeen = { vm.seen(it) },
            onDelete = { vm.delete(it) },
            onRepost = { vm.repost(it) },
            onClose = { viewing = null; vm.load() },
        )
    }
}

@Composable
private fun StoryViewer(group: StoryGroup, isMine: Boolean, onSeen: (Long) -> Unit, onDelete: (Long) -> Unit, onRepost: (com.binarybeast.chatapp.data.Story) -> Unit, onClose: () -> Unit) {
    var paused by remember { mutableStateOf(false) }
    var index by remember { mutableIntStateOf(0) }
    var progress by remember { mutableStateOf(0f) }
    val story = group.stories.getOrNull(index)

    fun next() { if (index < group.stories.lastIndex) index++ else onClose() }
    var viewersOf by remember { mutableStateOf<List<Profile>?>(null) }
    var viewerCount by remember { mutableIntStateOf(0) }
    LaunchedEffect(index) {
        viewerCount = 0
        if (isMine) group.stories.getOrNull(index)?.let { st ->
            viewerCount = runCatching { StoryRepository.viewers(st.id).size }.getOrDefault(0)
        }
    }
    val scopeV = androidx.compose.runtime.rememberCoroutineScope()

    LaunchedEffect(index) {
        val s = group.stories.getOrNull(index) ?: return@LaunchedEffect onClose()
        onSeen(s.id)
        if (s.mediaType == "video") { progress = 1f; return@LaunchedEffect }   // الفيديو بيكمّل لوحده ويعدّي للي بعده لما يخلص
        progress = 0f
        val steps = 100
        repeat(steps) { while (paused) delay(100); delay(50); progress = (it + 1) / steps.toFloat() }   // 5 ثواني لكل صورة (بتقف لو ضغطت)
        next()
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black).pointerInput(index) {
            detectTapGestures(
                onPress = { paused = true; tryAwaitRelease(); paused = false },
                onTap = { o -> if (o.x < size.width / 3f) { if (index > 0) index-- } else next() },
            )
        }) {
            if (story != null) {
                if (story.mediaType == "image")
                    TgImage(story.fileId, Modifier.fillMaxSize(), ContentScale.Fit)
                else
                    TgVideoPlayer(story.fileId, Modifier.fillMaxSize(), onEnded = { next() })

                story.caption?.let {
                    Text(it, Modifier.align(Alignment.BottomCenter).padding(32.dp), color = Color.White,
                        style = MaterialTheme.typography.titleMedium)
                }
            }
            if (story != null && (story.origName != null || story.mentioned)) {
                Text(
                    listOfNotNull(story.origName?.let { "🔁 أعاد نشرها من $it" }, if (story.mentioned) "🏷 اتذكرت في الستوري دي" else null).joinToString("  ·  "),
                    color = Color.White, style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 96.dp),
                )
            }
            if (!isMine && story != null && story.allowRepost) androidx.compose.material3.TextButton(
                onClick = { onRepost(story); onClose() },
                modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp),
            ) { Text("🔁 إعادة نشر", color = Color.White) }
            if (isMine && story != null) androidx.compose.material3.TextButton(
                onClick = { scopeV.launch { viewersOf = runCatching { StoryRepository.viewers(story.id) }.getOrDefault(emptyList()) } },
                modifier = Modifier.align(Alignment.BottomStart).padding(12.dp),
            ) { Text("👁 $viewerCount مشاهدة", color = Color.White) }
            viewersOf?.let { list ->
                androidx.compose.material3.AlertDialog(
                    onDismissRequest = { viewersOf = null },
                    title = { Text("شاهدوا الستوري") },
                    text = {
                        if (list.isEmpty()) Text("لسه محدش شافها")
                        else Column { list.forEach { p -> androidx.compose.material3.Text(p.displayName.ifBlank { p.phone }, Modifier.padding(vertical = 4.dp)) } }
                    },
                    confirmButton = { androidx.compose.material3.TextButton(onClick = { viewersOf = null }) { Text("تمام") } },
                )
            }
            Column(Modifier.fillMaxWidth().padding(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    group.stories.forEachIndexed { i, _ ->
                        LinearProgressIndicator(
                            progress = { if (i < index) 1f else if (i == index) progress else 0f },
                            modifier = Modifier.weight(1f).height(3.dp),
                            color = Color.White, trackColor = Color.White.copy(alpha = 0.3f),
                        )
                    }
                }
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(group.user.avatarFileId, group.user.displayName, 36.dp)
                    Text(group.user.displayName.ifBlank { group.user.phone }, color = Color.White,
                        modifier = Modifier.weight(1f).padding(horizontal = 10.dp))
                    androidx.compose.material3.TextButton(onClick = { paused = !paused }) { Text(if (paused) "▶" else "⏸", color = Color.White) }
                    if (isMine && story != null) IconButton(onClick = { onDelete(story.id); onClose() }) {
                        Icon(AIcons.Delete, "حذف", tint = Color.White)
                    }
                    IconButton(onClick = onClose) { Icon(AIcons.Close, "إغلاق", tint = Color.White) }
                }
            }
        }
    }
}


/** خصوصية الستوري: مين يشوفها (كل اللي حافظهم / ناس مختارين / محدش) + تحكم لكل شخص. */
@Composable
private fun StoryPrivacyDialog(onClose: () -> Unit) {
    var mode by remember { mutableStateOf("contacts") }
    var list by remember { mutableStateOf<List<Pair<Profile, ContactSync.StoryContact>>>(emptyList()) }
    var err by remember { mutableStateOf<String?>(null) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    LaunchedEffect(Unit) {
        runCatching { mode = ContactSync.storyMode(); list = ContactSync.storyContacts() }.onFailure { err = "تعذّر التحميل" }
    }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onClose,
        title = { Text("مين يشوف ستوريزي؟") },
        text = {
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                listOf("contacts" to "كل اللي بكلّمهم (إلا اللي أستثنيهم)", "selected" to "ناس مختارين بس", "nobody" to "محدش").forEach { (m, label) ->
                    Row(Modifier.fillMaxWidth().clickable {
                        mode = m; scope.launch { runCatching { ContactSync.setStoryMode(m) }.onFailure { err = "تعذّر الحفظ" } }
                    }, verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.RadioButton(selected = mode == m, onClick = null)
                        Text(label, Modifier.padding(8.dp))
                    }
                }
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (mode != "nobody") {
                    androidx.compose.material3.Text(
                        if (mode == "contacts") "شغّل = يشوف · قفل = مخفي عنه" else "شغّل = مسموح له يشوف",
                        style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 10.dp),
                    )
                    if (list.isEmpty()) Text("مفيش حد محفوظ لسه (بيتحفظ لما تتبادلوا رسايل).")
                    list.forEachIndexed { i, (p, c) ->
                        val on = if (mode == "contacts") !c.hideStories else c.allowStories
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(p.avatarFileId, p.displayName.ifBlank { p.phone }, 36.dp)
                            androidx.compose.material3.Text(p.displayName.ifBlank { p.phone }, Modifier.weight(1f).padding(horizontal = 10.dp))
                            androidx.compose.material3.Switch(checked = on, onCheckedChange = { v ->
                                val nc = if (mode == "contacts") c.copy(hideStories = !v) else c.copy(allowStories = v)
                                list = list.toMutableList().also { it[i] = p to nc }
                                scope.launch {
                                    runCatching {
                                        if (mode == "contacts") ContactSync.setHidden(p.id, !v) else ContactSync.setAllowed(p.id, v)
                                    }.onFailure { err = "تعذّر الحفظ" }
                                }
                            })
                        }
                    }
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton(onClick = onClose) { Text("تم") } },
    )
}
