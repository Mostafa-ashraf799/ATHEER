package com.binarybeast.chatapp.data

import com.binarybeast.chatapp.BuildConfig
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.realtime.Realtime

object Supa {
    val client by lazy {
        createSupabaseClient(
            supabaseUrl = BuildConfig.SUPABASE_URL,
            supabaseKey = BuildConfig.SUPABASE_ANON_KEY,
        ) {
            requestTimeout = kotlin.time.Duration.parse("45s")   // النت الضعيف: وقت أطول بدل ما الطلب يفشل بدري
            install(Auth)
            install(Postgrest)
            install(Realtime)
        }
    }
}
