package com.binarybeast.chatapp.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.ui.Modifier
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.coerceAtMost
import com.binarybeast.chatapp.data.AppSettings

/** يفتح رابط (في المتصفح المدمج أو الخارجي حسب الإعدادات). AppRoot هو اللي بيوفّره. */
val LocalOpenLink = staticCompositionLocalOf<(String) -> Unit> { {} }

/** لوحة ألوان نمط (فاتح أو داكن). */
class Pal(
    val bg: Color, val surface: Color, val surfaceHi: Color,
    val text: Color, val textDim: Color, val line: Color,
    val accent: Color, val onAccent: Color,
    val bubbleIn: Color, val bubbleOut: Color, val onBubbleOut: Color,
)

/** مواصفات نمط التصميم. shadow: soft = طين ناعم، hard = ظل صلب مزاح، flat = من غير ظل. */
class StyleSpec(
    val key: String, val name: String, val desc: String,
    val shadow: String, val border: Dp, val offset: Dp, val radius: Dp, val bubbleRadius: Dp,
    val light: Pal, val dark: Pal,
)

private fun c(h: Long) = Color(0xFF000000 or h)

val STYLES = listOf(
    StyleSpec("clay", "طين ناعم", "أسطح بارزة ناعمة وزوايا دايرية كبيرة", "soft", 0.dp, 0.dp, 26.dp, 22.dp,
        Pal(c(0xE9E5F3), c(0xE9E5F3), c(0xF4F1FB), c(0x2B2840), c(0x7A7595), c(0xD6D0E6), c(0x7C6CF0), Color.White, c(0xF4F1FB), c(0x7C6CF0), Color.White),
        Pal(c(0x1D1E2D), c(0x25273A), c(0x2E3047), c(0xECEBFA), c(0x9A9DBD), c(0x34364F), c(0x8B7CFF), Color.White, c(0x2A2C42), c(0x7C6CF0), Color.White)),
    StyleSpec("tg", "كلاسيكي", "مسطّح ونضيف زي تطبيقات المراسلة المعروفة", "flat", 0.dp, 0.dp, 14.dp, 16.dp,
        Pal(c(0xFFFFFF), c(0xFFFFFF), c(0xF1F3F5), c(0x101418), c(0x707579), c(0xE3E7EA), c(0x2AABEE), Color.White, c(0xF1F3F5), c(0xD9F2FF), c(0x101418)),
        Pal(c(0x0F1621), c(0x17212B), c(0x1F2C3A), c(0xF5F7FA), c(0x7F91A4), c(0x24313F), c(0x2AABEE), Color.White, c(0x182533), c(0x2B5278), Color.White)),
    StyleSpec("pop", "بوب", "حدود سودا وظلال صلبة وألوان مبهجة", "hard", 2.dp, 4.dp, 14.dp, 14.dp,
        Pal(c(0xFFF3D1), c(0xFFFFFF), c(0xFFE7A8), c(0x111111), c(0x5A5340), c(0x111111), c(0xFF4F86), Color.White, c(0xFFFFFF), c(0xFF4F86), Color.White),
        Pal(c(0x17141F), c(0x241F31), c(0x2F2942), c(0xFFF3D1), c(0xB3A9C9), c(0xFFF3D1), c(0xFF6B9A), c(0x111111), c(0x241F31), c(0xFF6B9A), c(0x111111))),
    StyleSpec("mono", "مونو", "أبيض وأسود بسيط وحدود رفيعة", "flat", 1.dp, 0.dp, 10.dp, 12.dp,
        Pal(c(0xFFFFFF), c(0xFFFFFF), c(0xF2F2F2), c(0x0B0B0B), c(0x6E6E6E), c(0xD0D0D0), c(0x0B0B0B), Color.White, c(0xF2F2F2), c(0x0B0B0B), Color.White),
        Pal(c(0x000000), c(0x0E0E0E), c(0x1A1A1A), c(0xF5F5F5), c(0x8C8C8C), c(0x2E2E2E), c(0xF5F5F5), c(0x000000), c(0x151515), c(0xF5F5F5), c(0x000000))),
    StyleSpec("lux", "فخم", "ألوان داكنة مع لمسات دهبية", "soft", 1.dp, 0.dp, 18.dp, 18.dp,
        Pal(c(0xF7F2E8), c(0xFFFDF8), c(0xEFE6D2), c(0x1B1710), c(0x7B6E55), c(0xE0D3B4), c(0xB8892B), Color.White, c(0xFFFDF8), c(0xB8892B), Color.White),
        Pal(c(0x0C0C10), c(0x16161D), c(0x1F1F28), c(0xF3ECDD), c(0x9C927C), c(0x34301F), c(0xD4AF5A), c(0x1B1710), c(0x1A1A22), c(0xD4AF5A), c(0x1B1710))),
    StyleSpec("earth", "ترابي", "ألوان دافية طبيعية وزوايا ناعمة", "soft", 0.dp, 0.dp, 20.dp, 20.dp,
        Pal(c(0xF3ECDD), c(0xFBF6EA), c(0xE8DDC6), c(0x2A2118), c(0x7D6E58), c(0xDCCFB4), c(0xB5593C), Color.White, c(0xFBF6EA), c(0xB5593C), Color.White),
        Pal(c(0x1F1A16), c(0x2A231D), c(0x352C24), c(0xF3E9D8), c(0xA89A83), c(0x40362C), c(0xD9825F), c(0x1F1A16), c(0x2A231D), c(0xD9825F), c(0x1F1A16))),
    StyleSpec("retro", "ريترو", "ألوان قديمة وحدود سميكة وظل صلب", "hard", 2.dp, 3.dp, 6.dp, 8.dp,
        Pal(c(0xFBEFD2), c(0xFFF8E6), c(0xF3DFAE), c(0x2B2118), c(0x7A6A4C), c(0x2B2118), c(0x1F8A8A), Color.White, c(0xFFF8E6), c(0x1F8A8A), Color.White),
        Pal(c(0x1B2430), c(0x253141), c(0x2F3E52), c(0xF8EBD0), c(0xA6B0BF), c(0xF8EBD0), c(0xF2A541), c(0x1B2430), c(0x253141), c(0xF2A541), c(0x1B2430))),
)
fun styleOf(key: String): StyleSpec = STYLES.firstOrNull { it.key == key } ?: STYLES[0]

/** ألوان اختيارية بتغلب لون النمط. "auto" = لون النمط. أي قيمة قديمة تتعامل كـ auto. */
val ACCENTS = listOf(
    "auto" to ("لون النمط" to Color(0xFF7C6CF0)),
    "c_violet" to ("بنفسجي" to Color(0xFF7C6CF0)),
    "c_blue" to ("أزرق" to Color(0xFF2A7BEF)),
    "c_teal" to ("تركواز" to Color(0xFF14B8A6)),
    "c_green" to ("أخضر" to Color(0xFF22A06B)),
    "c_orange" to ("برتقالي" to Color(0xFFF08A24)),
    "c_pink" to ("وردي" to Color(0xFFEC4899)),
    "c_red" to ("أحمر" to Color(0xFFE5484D)),
)
fun accentOverride(key: String): Color? = ACCENTS.firstOrNull { it.first == key && key != "auto" }?.second?.second

val LocalDark = staticCompositionLocalOf { true }
val LocalAccent = staticCompositionLocalOf { Color(0xFF7C6CF0) }
val LocalStyle = staticCompositionLocalOf { STYLES[0] }
val LocalPal = staticCompositionLocalOf { STYLES[0].dark }

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val prefs by AppSettings.prefs.collectAsState()
    val dark = when (prefs.darkMode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val base = LocalDensity.current
    val lang = Lang.resolve(prefs.language)
    CompositionLocalProvider(
        LocalLayoutDirection provides (if (Lang.isRtl(lang)) LayoutDirection.Rtl else LayoutDirection.Ltr),
        LocalLang provides lang,
        LocalDensity provides Density(base.density, base.fontScale * prefs.fontScale),
        LocalDark provides dark,
    ) {
        val style = styleOf(prefs.uiStyle)
        val pal = if (dark) style.dark else style.light
        val c = accentOverride(prefs.accent) ?: pal.accent
        val onC = if (accentOverride(prefs.accent) != null) Color.White else pal.onAccent
        val scheme = (if (dark) darkColorScheme() else lightColorScheme()).copy(
            primary = c, onPrimary = onC,
            primaryContainer = c.copy(alpha = 0.18f), onPrimaryContainer = pal.text,
            secondary = c, onSecondary = onC, tertiary = Color(0xFF22A06B),
            background = Color.Transparent, onBackground = pal.text,
            surface = pal.surface, onSurface = pal.text,
            surfaceVariant = pal.surfaceHi, onSurfaceVariant = pal.textDim,
            surfaceContainer = pal.surface, surfaceContainerHigh = pal.surfaceHi, surfaceContainerHighest = pal.surfaceHi,
            outline = pal.line, outlineVariant = pal.line.copy(alpha = 0.6f),
            error = if (dark) Color(0xFFFF6B7A) else Color(0xFFD62839),
        )
        MaterialTheme(
            colorScheme = scheme,
            shapes = androidx.compose.material3.Shapes(
                extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(style.radius * 0.5f),
                small = androidx.compose.foundation.shape.RoundedCornerShape(style.radius * 0.75f),
                medium = androidx.compose.foundation.shape.RoundedCornerShape(style.radius),
                large = androidx.compose.foundation.shape.RoundedCornerShape(style.radius * 1.25f),
                extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(style.radius * 1.5f),
            ),
        ) {
            CompositionLocalProvider(LocalAccent provides c, LocalStyle provides style, LocalPal provides pal) {
                Box(Modifier.fillMaxSize()) {
                    AuroraBackground()
                    CompositionLocalProvider(androidx.compose.material3.LocalContentColor provides scheme.onBackground) { Box(Modifier.fillMaxSize().imePadding()) { content() } }
                }
            }
        }
    }
}
