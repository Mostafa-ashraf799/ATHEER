package com.binarybeast.chatapp.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.getValue
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binarybeast.chatapp.data.AppSettings
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

/**
 * إيموجي كبيرة بتتحرك دايمًا (زي تليجرام/آيفون). الحركة بتتحسب على الجهاز نفسه (من غير تحميل ولا إنترنت)،
 * وبتتختار حسب نوع الإيموجي: قلوب بتنبض، ضحك بيهتز، إيد بتلوّح، كورة بتلف، وهكذا.
 */
enum class EMotion { Bounce, Sway, Heartbeat, Laugh, Spin, Float, Wave, Pop }

private val HEARTS = setOf("❤", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💖", "💗", "💓", "💕", "💞", "💘", "💝", "😍", "🥰", "😘", "😻", "♥")
private val LAUGH = setOf("😂", "🤣", "😆", "😹", "😄", "😁", "😅", "😝", "😜", "🤪")
private val WAVE = setOf("👋", "🤚", "🖐", "✋", "🙌", "👏", "🤝", "🙏", "👍", "👌", "✌", "🤞", "💪", "🫶")
private val SPIN = setOf("🌀", "🔄", "⚽", "🏀", "🏈", "⚾", "🎾", "🏐", "🌍", "🌎", "🌏", "⚙", "☸", "🎡", "💿", "📀", "🌞", "☀")
private val POP = setOf("🎉", "🎊", "✨", "⭐", "🌟", "💫", "🔥", "💥", "🎂", "🎁", "🏆", "💯", "⚡")

fun emojiMotion(e: String): EMotion {
    val first = e.codePointAt(0).let { String(Character.toChars(it)) }
    return when {
        first in HEARTS -> EMotion.Heartbeat
        first in LAUGH -> EMotion.Laugh
        first in WAVE -> EMotion.Wave
        first in SPIN -> EMotion.Spin
        first in POP -> EMotion.Pop
        else -> when (abs(e.hashCode()) % 3) { 0 -> EMotion.Bounce; 1 -> EMotion.Sway; else -> EMotion.Float }
    }
}

private fun period(m: EMotion) = when (m) {
    EMotion.Bounce -> 1100; EMotion.Sway -> 1800; EMotion.Heartbeat -> 1000; EMotion.Laugh -> 1300
    EMotion.Spin -> 3200; EMotion.Float -> 2400; EMotion.Wave -> 1600; EMotion.Pop -> 1200
}

@Composable
fun AnimatedEmoji(emoji: String, size: TextUnit = 56.sp, modifier: Modifier = Modifier, animate: Boolean = true) {
    if (animate && AppSettings.now.animations && AppSettings.now.lottieEmoji) {
        val ctx = androidx.compose.ui.platform.LocalContext.current
        val json by androidx.compose.runtime.produceState<String?>(null, emoji) { value = EmojiPack.get(ctx, emoji) }
        val j = json
        if (j != null) {
            val comp by com.airbnb.lottie.compose.rememberLottieComposition(com.airbnb.lottie.compose.LottieCompositionSpec.JsonString(j))
            com.airbnb.lottie.compose.LottieAnimation(comp, modifier.size(with(androidx.compose.ui.platform.LocalDensity.current) { size.toDp() * 1.25f }), iterations = com.airbnb.lottie.compose.LottieConstants.IterateForever)
            return
        }
    }
    val live = animate && AppSettings.now.animations && AppSettings.now.bigAnimEmoji
    if (!live) { Text(emoji, modifier, fontSize = size); return }
    val m = remember(emoji) { emojiMotion(emoji) }
    val t = remember { Animatable(0f) }
    val offset = remember(emoji) { abs(emoji.hashCode()) % 500 }
    LaunchedEffect(m) {
        fast { t.animateTo(1f, infiniteRepeatable(tween(period(m), easing = LinearEasing), RepeatMode.Restart, StartOffset(offset))) }
    }
    val tau = (2 * PI).toFloat()
    val em = size.value
    Text(
        emoji, modifier.graphicsLayer {
            val p = t.value
            val h = em * density
            when (m) {
                EMotion.Bounce -> {
                    val b = abs(sin(p * PI.toFloat() * 2f))
                    translationY = -b * h * 0.14f
                    scaleX = 1f + (1f - b) * 0.06f; scaleY = 1f - (1f - b) * 0.06f
                    transformOrigin = TransformOrigin(0.5f, 1f)
                }
                EMotion.Sway -> { rotationZ = sin(p * tau) * 11f; transformOrigin = TransformOrigin(0.5f, 0.9f) }
                EMotion.Heartbeat -> {
                    val s = if (p < 0.5f) 1f + 0.16f * max(0f, sin(p * tau * 2f)) else 1f + 0.04f * sin(p * tau)
                    scaleX = s; scaleY = s
                }
                EMotion.Laugh -> {
                    val on = if (p < 0.55f) 1f else 0f
                    rotationZ = sin(p * tau * 7f) * 9f * on
                    translationY = -abs(sin(p * tau * 3.5f)) * h * 0.05f * on
                    val s = 1f + 0.05f * on; scaleX = s; scaleY = s
                }
                EMotion.Spin -> { rotationZ = p * 360f }
                EMotion.Float -> {
                    translationY = sin(p * tau) * h * 0.07f
                    val s = 1f + 0.04f * sin(p * tau + 1f); scaleX = s; scaleY = s
                }
                EMotion.Wave -> {
                    rotationZ = if (p < 0.6f) sin(p / 0.6f * tau * 2f) * 16f else 0f
                    transformOrigin = TransformOrigin(0.5f, 0.95f)
                }
                EMotion.Pop -> {
                    val s = 1f + 0.18f * abs(sin(p * tau)); scaleX = s; scaleY = s
                    rotationZ = sin(p * tau) * 6f
                }
            }
        },
        fontSize = size,
    )
}

/** رسالة إيموجي بس (١–٣): بتتعرض كبيرة ومتحركة. */
@Composable
fun BigEmojiRow(text: String) {
    val list = remember(text) { graphemes(text.trim()) }
    val size = when (list.size) { 1 -> 72.sp; 2 -> 56.sp; else -> 46.sp }
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { list.forEach { AnimatedEmoji(it, size) } }
}

/** تقسيم النص لحروف مرئية (الإيموجي المركّبة بتفضل واحدة). */
fun graphemes(t: String): List<String> {
    val bi = android.icu.text.BreakIterator.getCharacterInstance()
    bi.setText(t)
    val out = ArrayList<String>()
    var s = bi.first(); var e = bi.next()
    while (e != android.icu.text.BreakIterator.DONE) { val g = t.substring(s, e); if (g.isNotBlank()) out.add(g); s = e; e = bi.next() }
    return out
}

fun isBigAnimEmoji(t: String): Boolean = isEmojiOnly(t) && graphemes(t.trim()).size in 1..3

val ANIM_EMOJI = listOf(
    "😂","🤣","😍","🥰","😘","😎","🥳","🤩","😭","😡","🤯","🥺","😴","🤔","😱","😇",
    "❤️","💖","💕","🧡","💛","💚","💙","💜","🖤","🔥","✨","⭐","🎉","💯","⚡","🎁",
    "👋","👏","🙌","👍","🙏","💪","✌️","🤝","⚽","🏀","🌍","🌞","🌀","🐶","🐱","🦋",
    "🐢","🦁","🐼","🦄","🌹","🍕","🍔","☕","🎂","🚀","👑","💎","🎈","🎵","💃","🕺",
)

fun dropLastGrapheme(t: String): String {
    if (t.isEmpty()) return t
    val bi = android.icu.text.BreakIterator.getCharacterInstance(); bi.setText(t)
    val i = bi.preceding(t.length)
    return if (i == android.icu.text.BreakIterator.DONE) "" else t.substring(0, i)
}


/** تحميل حركات Noto Animated Emoji (CC BY 4.0) مرة واحدة وتخزينها. لو فشل التحميل بنرجع للحركة المحلية. */
object EmojiPack {
    private val mem = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val failed = java.util.Collections.synchronizedSet(HashSet<String>())

    suspend fun get(ctx: android.content.Context, emoji: String): String? = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        mem[emoji]?.let { return@withContext it }
        if (emoji in failed) return@withContext null
        val cps = ArrayList<String>(); var i = 0
        while (i < emoji.length) { val c = emoji.codePointAt(i); cps.add(Integer.toHexString(c)); i += Character.charCount(c) }
        val full = cps.joinToString("_")
        val noVs = cps.filter { it != "fe0f" }.joinToString("_")
        val dir = java.io.File(ctx.cacheDir, "emoji_lottie").apply { mkdirs() }
        for (code in listOf(full, noVs).distinct()) {
            val f = java.io.File(dir, "$code.json")
            if (f.exists()) return@withContext f.readText().also { mem[emoji] = it }
        }
        for (code in listOf(full, noVs).distinct()) {
            val txt = runCatching {
                val c = java.net.URL("https://fonts.gstatic.com/s/e/notoemoji/latest/$code/lottie.json").openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 6000; c.readTimeout = 8000
                if (c.responseCode != 200) null else c.inputStream.bufferedReader().readText()
            }.getOrNull()
            if (txt != null && txt.startsWith("{")) {
                runCatching { java.io.File(dir, "$code.json").writeText(txt) }
                mem[emoji] = txt
                return@withContext txt
            }
        }
        failed.add(emoji); null
    }
}
