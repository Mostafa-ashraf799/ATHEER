package com.binarybeast.chatapp

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.net.Uri
import com.binarybeast.chatapp.data.AppSettings

/**
 * صوت التطبيق الرسمي (App Sound Kit): Nimbus Notify / Echo Reply / Swift Send / Vivid Mention / Aurora Ring.
 * الملفات مضغوطة (ogg) في res/raw. الإشعارات بتستخدم نفس الملفات كصوت للقنوات.
 */
object Sounds {
    enum class Kind { NOTIFY, REPLY, SEND, MENTION }

    private var pool: SoundPool? = null
    private val ids = HashMap<Kind, Int>()
    private val loaded = HashSet<Int>()
    private var last = 0L

    fun rawUri(ctx: Context, res: Int): Uri = Uri.parse("android.resource://${ctx.packageName}/$res")

    fun init(ctx: Context) {
        val app = ctx.applicationContext
        val p = SoundPool.Builder().setMaxStreams(3)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .build()
        p.setOnLoadCompleteListener { _, id, status -> if (status == 0) synchronized(loaded) { loaded.add(id) } }
        ids[Kind.NOTIFY] = p.load(app, R.raw.nimbus_notify, 1)
        ids[Kind.REPLY] = p.load(app, R.raw.echo_reply, 1)
        ids[Kind.SEND] = p.load(app, R.raw.swift_send, 1)
        ids[Kind.MENTION] = p.load(app, R.raw.vivid_mention, 1)
        pool = p
    }

    /** صوت داخل التطبيق (بيحترم إعداد «أصوات التطبيق»). */
    fun play(k: Kind) {
        if (!AppSettings.now.appSounds) return
        val now = System.currentTimeMillis()
        if (now - last < 120) return
        last = now
        val id = ids[k] ?: return
        if (synchronized(loaded) { id in loaded }) pool?.play(id, 0.9f, 0.9f, 1, 0, 1f)
    }
}
