package com.binarybeast.chatapp.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binarybeast.chatapp.data.StickerStore
import com.binarybeast.chatapp.data.TelegramStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

private val EMOJI_GROUPS = listOf(
    "😀" to "😀 😃 😄 😁 😆 😅 😂 🤣 🥲 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥸 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕",
    "👍" to "👍 👎 👌 🤌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐 🖖 👋 🤝 🙏 ✍️ 💪 🙌 👏 🤲 🫶 🫡 🫰 💅 👀 👁 🧠 🫀 🦴 👂 👃 👄",
    "❤️" to "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ♥️ 💯 💢 💥 💫 💦 💨 🕳 💬 💭 💤 ✨ ⭐ 🌟 🔥 🎉 🎊 🎁 🏆 🥇 🎈",
    "🐶" to "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🦅 🦉 🦇 🐺 🐴 🦄 🐝 🦋 🐌 🐞 🐢 🐍 🐙 🦑 🐠 🐬 🐳 🐘 🦒 🐪 🌵 🌴 🌸 🌹 🌻 🍀 🍁",
    "🍔" to "🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🥭 🍍 🥥 🥑 🍅 🥕 🌽 🍞 🧀 🍗 🍖 🍔 🍟 🍕 🌭 🥪 🌮 🌯 🍣 🍜 🍝 🍩 🍪 🎂 🍰 🍫 🍬 🍭 ☕ 🍵 🥤 🍺 🍷",
    "⚽" to "⚽ 🏀 🏈 ⚾ 🎾 🏐 🎱 🏓 🥊 🎮 🕹 🎲 🎯 🎸 🎹 🥁 🎧 🎤 🎬 📷 📱 💻 ⌚ 💡 🔑 🔒 📌 📎 ✏️ 📚 🚗 ✈️ 🚀 🏠 🌍 🌙 ☀️ ⛅ 🌧 ⚡ ❄️ 🌈",
)

/** لوحة: ستيكراتي / GIF / إيموجي. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun StickerSheet(
    onSend: (fileId: String, kind: String) -> Unit,
    onEmoji: (String) -> Unit,
    onMaker: () -> Unit,
    onDismiss: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val all by StickerStore.items.collectAsState()
    var tab by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var delete by remember { mutableStateOf<StickerStore.Item?>(null) }
    var emojiGroup by remember { mutableStateOf(0) }

    // إضافة ملف جاهز (WebP/PNG للستيكر أو GIF)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val kind = if (tab == 1) "gif" else "sticker"
        scope.launch {
            busy = true
            runCatching {
                val (bytes, name, mime) = withContext(Dispatchers.IO) { readUri(ctx, uri) }
                require(mime.startsWith("image/")) { "اختار صورة" }
                require(bytes.size <= 8 * 1024 * 1024) { "الملف كبير (الحد 8 ميجا)" }
                val id = TelegramStorage.upload(bytes, name, mime, "image_hq")
                StickerStore.add(id, kind)
            }.onFailure { Toast.makeText(ctx, it.message ?: "تعذّر الإضافة", Toast.LENGTH_SHORT).show() }
            busy = false
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxWidth().height(380.dp).navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ستيكراتي", "GIF", "إيموجي", "متحركة").forEachIndexed { i, t ->
                    Box(
                        Modifier.weight(1f).height(40.dp).then(if (tab == i) Modifier.glass(RoundedCornerShape(20.dp), MaterialTheme.colorScheme.primary) else Modifier)
                            .clip(RoundedCornerShape(20.dp)).clickable { tab = i },
                        contentAlignment = Alignment.Center,
                    ) { Text(t, color = if (tab == i) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold) }
                }
            }
            Spacer(Modifier.height(8.dp))
            when (tab) {
                2 -> {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        EMOJI_GROUPS.forEachIndexed { i, (icon, _) ->
                            Text(icon, Modifier.clip(CircleShape).clickable { emojiGroup = i }.padding(8.dp), style = MaterialTheme.typography.titleLarge,
                                color = if (i == emojiGroup) MaterialTheme.colorScheme.primary else Color.Unspecified)
                        }
                    }
                    val list = remember(emojiGroup) { EMOJI_GROUPS[emojiGroup].second.split(" ").filter { it.isNotBlank() } }
                    LazyVerticalGrid(GridCells.Adaptive(46.dp), Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
                        items(list) { e -> Text(e, Modifier.clip(CircleShape).clickable { onEmoji(e) }.padding(6.dp), fontSize = 26.sp) }
                    }
                }
                3 -> {
                    LazyVerticalGrid(GridCells.Adaptive(76.dp), Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
                        items(ANIM_EMOJI) { e -> androidx.compose.foundation.layout.Box(Modifier.clip(CircleShape).clickable { onEmoji(e) }.padding(8.dp), contentAlignment = Alignment.Center) { AnimatedEmoji(e, 44.sp) } }
                    }
                }
                else -> {
                    val kind = if (tab == 1) "gif" else "sticker"
                    val mine = all.filter { it.kind == kind }
                    LazyVerticalGrid(GridCells.Fixed(4), Modifier.fillMaxSize().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (tab == 0) item {
                            Column(Modifier.aspectRatio(1f).clip(RoundedCornerShape(16.dp)).glass(RoundedCornerShape(16.dp), MaterialTheme.colorScheme.primary).clickable { onDismiss(); onMaker() },
                                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Icon(AIcons.AutoAwesome, null, tint = MaterialTheme.colorScheme.onPrimary)
                                Text("اعمل ستيكر", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                            }
                        }
                        item {
                            Column(Modifier.aspectRatio(1f).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable(enabled = !busy) { AppLock.skipNext(); picker.launch("image/*") },
                                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Icon(AIcons.Add, null, tint = MaterialTheme.colorScheme.primary)
                                Text(if (busy) "جاري الرفع…" else if (tab == 1) "ضيف GIF" else "ضيف ملف", fontSize = 11.sp)
                            }
                        }
                        items(mine, key = { it.fileId }) { s ->
                            Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(12.dp)).combinedClickable(onClick = { onSend(s.fileId, s.kind) }, onLongClick = { delete = s })) {
                                TgImage(s.fileId, Modifier.fillMaxSize(), ContentScale.Fit)
                            }
                        }
                    }
                }
            }
        }
    }

    delete?.let { s ->
        AlertDialog(
            onDismissRequest = { delete = null },
            title = { Text("مسح من ${if (s.kind == "gif") "الـGIF" else "الستيكرات"}؟") },
            confirmButton = { TextButton(onClick = { StickerStore.remove(s.fileId); delete = null }) { Text("مسح") } },
            dismissButton = { TextButton(onClick = { delete = null }) { Text("إلغاء") } },
        )
    }
}

// ============================================================ صفحة صنع الستيكر

private fun decodeScaled(ctx: android.content.Context, uri: android.net.Uri, maxSide: Int = 2048): Bitmap? = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
}.getOrNull()

/** مسح خلفية الأشخاص بموديل ML Kit المدمج (شغّال أوفلاين). */
private suspend fun removePersonBg(srcIn: Bitmap): Bitmap = withContext(Dispatchers.Default) {
    val maxSide = 1024
    val k = minOf(1f, maxSide.toFloat() / maxOf(srcIn.width, srcIn.height))
    val src = if (k < 1f) Bitmap.createScaledBitmap(srcIn, (srcIn.width * k).toInt().coerceAtLeast(1), (srcIn.height * k).toInt().coerceAtLeast(1), true) else srcIn
    val seg = com.google.mlkit.vision.segmentation.Segmentation.getClient(
        com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions.Builder()
            .setDetectorMode(com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .enableRawSizeMask().build(),
    )
    try {
        val mask = kotlinx.coroutines.suspendCancellableCoroutine<com.google.mlkit.vision.segmentation.SegmentationMask> { c ->
            seg.process(com.google.mlkit.vision.common.InputImage.fromBitmap(src, 0))
                .addOnSuccessListener { c.resumeWith(Result.success(it)) }
                .addOnFailureListener { c.resumeWith(Result.failure(it)) }
        }
        val fb = mask.buffer.order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer()
        val mw = mask.width; val mh = mask.height
        val w = src.width; val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        for (y in 0 until h) {
            val my = (y * mh / h).coerceIn(0, mh - 1)
            for (x in 0 until w) {
                val mx = (x * mw / w).coerceIn(0, mw - 1)
                val conf = fb.get(my * mw + mx)
                val a = ((conf - 0.35f) / 0.35f).coerceIn(0f, 1f)
                val i = y * w + x
                px[i] = ((a * 255).toInt() shl 24) or (px[i] and 0x00FFFFFF)
            }
        }
        Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    } finally { seg.close() }
}

/** مسح لون الخلفية: بيمسح المنطقة المتصلة بالحواف اللي لونها قريب من لون الأركان (tol من 0 لـ100). */
private suspend fun eraseBgColor(src: Bitmap, tol: Int): Bitmap = withContext(Dispatchers.Default) {
    val w = src.width; val h = src.height
    val px = IntArray(w * h)
    src.getPixels(px, 0, w, 0, 0, w, h)
    fun ch(c: Int, s: Int) = (c shr s) and 0xFF
    val corners = intArrayOf(px[0], px[w - 1], px[(h - 1) * w], px[h * w - 1])
    val rr = corners.sumOf { ch(it, 16) } / 4; val gg = corners.sumOf { ch(it, 8) } / 4; val bb = corners.sumOf { ch(it, 0) } / 4
    val limit = tol * 3
    fun close(c: Int) = ((c ushr 24) < 10) || (kotlin.math.abs(ch(c, 16) - rr) + kotlin.math.abs(ch(c, 8) - gg) + kotlin.math.abs(ch(c, 0) - bb) <= limit)
    val seen = BooleanArray(w * h)
    val q = IntArray(w * h)
    var head = 0; var tail = 0
    fun push(i: Int) { if (!seen[i] && close(px[i])) { seen[i] = true; q[tail++] = i } }
    for (x in 0 until w) { push(x); push((h - 1) * w + x) }
    for (y in 0 until h) { push(y * w); push(y * w + w - 1) }
    while (head < tail) {
        val i = q[head++]
        val x = i % w; val y = i / w
        if (x > 0) push(i - 1); if (x < w - 1) push(i + 1)
        if (y > 0) push(i - w); if (y < h - 1) push(i + w)
    }
    for (i in 0 until w * h) if (seen[i]) px[i] = 0
    Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
}

private fun renderSticker(
    src: Bitmap, scale: Float, ox: Float, oy: Float, shape: Int, text: String, border: Boolean, pv: Float, textPx: Float,
): Bitmap {
    val size = 512
    val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(out)
    val f = size / pv
    val s0 = maxOf(pv / src.width, pv / src.height)
    val k = s0 * scale * f
    val path = Path().apply {
        when (shape) {
            1 -> addCircle(size / 2f, size / 2f, size / 2f, Path.Direction.CW)
            0 -> addRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), size * 0.13f, size * 0.13f, Path.Direction.CW)
            else -> addRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), Path.Direction.CW)
        }
    }
    c.save()
    c.clipPath(path)
    val m = Matrix().apply {
        postTranslate(-src.width / 2f, -src.height / 2f)
        postScale(k, k)
        postTranslate(size / 2f + ox * f, size / 2f + oy * f)
    }
    c.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
    c.restore()
    if (border && shape != 2) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.WHITE; strokeWidth = 14f }
        c.drawPath(path, p)
    }
    if (text.isNotBlank()) {
        val ts = textPx * f
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = ts; isFakeBoldText = true; style = Paint.Style.STROKE; strokeWidth = ts * 0.22f; color = android.graphics.Color.BLACK }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = ts; isFakeBoldText = true; color = android.graphics.Color.WHITE }
        val y = size - 44f
        c.drawText(text, size / 2f, y, stroke)
        c.drawText(text, size / 2f, y, fill)
    }
    return out
}

/** صفحة عمل ستيكر: اختار صورة، كبّر/حرّك بصباعك، شكل (مربع/دايرة/حر)، كلام اختياري، وحفظ. */
@Composable
fun StickerMakerScreen(onClose: () -> Unit, onSaved: (fileId: String, send: Boolean) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    BackHandler(onBack = onClose)
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var scale by remember { mutableStateOf(1f) }
    var ox by remember { mutableStateOf(0f) }
    var oy by remember { mutableStateOf(0f) }
    var shape by remember { mutableStateOf(0) }
    var text by remember { mutableStateOf("") }
    var border by remember { mutableStateOf(true) }
    var pv by remember { mutableStateOf(1f) }
    var busy by remember { mutableStateOf(false) }
    var original by remember { mutableStateOf<Bitmap?>(null) }
    var cutBusy by remember { mutableStateOf(false) }
    var tol by remember { mutableStateOf(40f) }
    val textPx = with(LocalDensity.current) { 30.sp.toPx() }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val b = withContext(Dispatchers.IO) { decodeScaled(ctx, uri) }
            if (b == null) Toast.makeText(ctx, "تعذّر فتح الصورة", Toast.LENGTH_SHORT).show()
            else { bmp = b; original = b; scale = 1f; ox = 0f; oy = 0f }
        }
    }

    fun save(send: Boolean) {
        val b = bmp ?: return
        scope.launch {
            busy = true
            runCatching {
                val bytes = withContext(Dispatchers.Default) {
                    val out = renderSticker(b, scale, ox, oy, shape, text.trim(), border, pv, textPx)
                    ByteArrayOutputStream().also { out.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
                }
                val id = TelegramStorage.upload(bytes, "sticker.png", "image/png", "image_hq")
                StickerStore.add(id, "sticker")
                id
            }.onSuccess { onSaved(it, send) }
                .onFailure { Toast.makeText(ctx, "تعذّر الحفظ: ${it.message ?: ""}", Toast.LENGTH_LONG).show() }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        GlassTopBar(
            title = { Text("اعمل ستيكر", fontWeight = FontWeight.Bold) },
            navigationIcon = { IconButton(onClick = onClose) { Icon(AIcons.ArrowBack, "رجوع") } },
        )
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            val shapeC = when (shape) { 1 -> CircleShape; 0 -> RoundedCornerShape(percent = 13); else -> RoundedCornerShape(0.dp) }
            Box(
                Modifier.size(300.dp).clip(shapeC).background(Color(0x22888888))
                    .border(if (border && shape != 2) 3.dp else 0.dp, Color.White, shapeC)
                    .onSizeChanged { pv = it.width.toFloat() }
                    .pointerInput(bmp) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(0.5f, 6f); ox += pan.x; oy += pan.y
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                val b = bmp
                if (b == null) Text("اختار صورة الأول", color = MaterialTheme.colorScheme.onSurfaceVariant)
                else {
                    Image(b.asImageBitmap(), null, Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale; translationX = ox; translationY = oy }, contentScale = ContentScale.Crop)
                    if (text.isNotBlank()) Text(
                        text, Modifier.align(Alignment.BottomCenter).padding(bottom = 14.dp),
                        style = TextStyle(fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White, shadow = Shadow(Color.Black, Offset(2f, 2f), 6f)),
                        maxLines = 1,
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            if (bmp != null) Text("كبّر وحرّك الصورة بصباعين", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().height(52.dp).glass(CircleShape).clickable { AppLock.skipNext(); pick.launch("image/*") }, contentAlignment = Alignment.Center) {
                Text(if (bmp == null) "اختار صورة من الجهاز" else "غيّر الصورة", fontWeight = FontWeight.SemiBold)
            }
            if (bmp != null) {
                Spacer(Modifier.height(16.dp))
                Text("مسح الخلفية", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f).height(44.dp).glass(RoundedCornerShape(22.dp)).clickable(enabled = !cutBusy) {
                        val b = bmp ?: return@clickable
                        scope.launch {
                            cutBusy = true
                            runCatching { removePersonBg(b) }
                                .onSuccess { bmp = it }
                                .onFailure { Toast.makeText(ctx, Lang.trNow("تعذّر المسح التلقائي") + ": " + (it.message ?: ""), Toast.LENGTH_LONG).show() }
                            cutBusy = false
                        }
                    }, contentAlignment = Alignment.Center) { Text(if (cutBusy) "جاري المعالجة…" else "مسح الخلفية", fontWeight = FontWeight.SemiBold) }
                    Box(Modifier.weight(1f).height(44.dp).glass(RoundedCornerShape(22.dp)).clickable(enabled = !cutBusy) {
                        val b = bmp ?: return@clickable
                        scope.launch { cutBusy = true; runCatching { eraseBgColor(b, tol.toInt()) }.onSuccess { bmp = it }; cutBusy = false }
                    }, contentAlignment = Alignment.Center) { Text("مسح لون الخلفية", fontWeight = FontWeight.SemiBold) }
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("الحساسية", style = MaterialTheme.typography.labelMedium)
                    androidx.compose.material3.Slider(tol, { tol = it }, valueRange = 5f..100f, modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
                    if (bmp !== original) Text("رجوع للأصل", Modifier.clip(RoundedCornerShape(10.dp)).clickable { bmp = original }.padding(6.dp), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                }
                Text("المسح التلقائي بيشتغل على الأشخاص بس. لو الصورة غير كده استخدم «مسح لون الخلفية».", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("مربع مدوّر", "دايرة", "حر").forEachIndexed { i, t ->
                        Box(
                            Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(20.dp))
                                .then(if (shape == i) Modifier.glass(RoundedCornerShape(20.dp), MaterialTheme.colorScheme.primary) else Modifier.background(MaterialTheme.colorScheme.surfaceVariant))
                                .clickable { shape = i },
                            contentAlignment = Alignment.Center,
                        ) { Text(t, color = if (shape == i) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface) }
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = text, onValueChange = { text = it.take(24) }, label = { Text("كلام على الستيكر (اختياري)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("حافة بيضا", Modifier.weight(1f))
                    Switch(border, { border = it })
                }
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f).height(52.dp).glass(CircleShape).clickable(enabled = !busy) { save(false) }, contentAlignment = Alignment.Center) {
                        Text(if (busy) "جاري الحفظ…" else "حفظ في ستيكراتي", fontWeight = FontWeight.SemiBold)
                    }
                    Box(Modifier.weight(1f).height(52.dp).glass(CircleShape, MaterialTheme.colorScheme.primary).clickable(enabled = !busy) { save(true) }, contentAlignment = Alignment.Center) {
                        Text("حفظ وإرسال", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
