package com.binarybeast.chatapp.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.coerceAtMost
import androidx.compose.ui.unit.sp

/*
 * نظام الأنماط: 7 أنماط تصميم (طين ناعم، كلاسيكي، بوب، مونو، فخم، ترابي، ريترو) × فاتح/داكن.
 * الافتراضي «طين ناعم». كل المكوّنات هنا بتقرا LocalStyle/LocalPal فبتتغير مع الإعدادات.
 */

/** ضغطة بترتدّ: بتصغّر العنصر شوية وهو مضغوط وترجّعه بنطّة ناعمة. */
@Composable
fun Modifier.bounceClick(enabled: Boolean = true, role: Role? = Role.Button, onClick: () -> Unit): Modifier {
    val src = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatFast(if (pressed) 0.94f else 1f, androidx.compose.animation.core.spring(dampingRatio = 0.45f, stiffness = 600f), "bounce")
    return this.graphicsLayer { scaleX = sc; scaleY = sc }
        .clickable(interactionSource = src, indication = null, enabled = enabled, role = role, onClick = onClick)
}

/** شكل العناصر الكبيرة (الشرائط) حسب النمط. */
@Composable
fun barShape(): Shape = RoundedCornerShape((LocalStyle.current.radius * 1.1f).coerceAtMost(30.dp))

/** خلفية التطبيق حسب النمط. */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier.fillMaxSize()) {
    val pal = LocalPal.current
    val st = LocalStyle.current
    val a = LocalAccent.current
    val dark = LocalDark.current
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(pal.bg)
        when (st.key) {
            "clay", "lux", "earth" -> {
                drawRect(Brush.radialGradient(listOf(a.copy(alpha = if (dark) 0.10f else 0.12f), Color.Transparent), Offset(w * 0.5f, 0f), w * 0.9f))
                drawRect(Brush.radialGradient(listOf(a.copy(alpha = if (dark) 0.05f else 0.07f), Color.Transparent), Offset(w, h * 0.8f), w * 0.9f))
            }
            "pop", "retro" -> {
                val step = 24.dp.toPx()
                val col = pal.line.copy(alpha = if (dark) 0.10f else 0.08f)
                var y = step / 2
                while (y < h) {
                    var x = step / 2
                    while (x < w) { drawCircle(col, 1.3.dp.toPx(), Offset(x, y)); x += step }
                    y += step
                }
            }
            else -> {}
        }
    }
}

/**
 * سطح النمط: طين ناعم (ظل مزدوج) / ظل صلب مزاح + حد / مسطّح.
 * tint = لون ممتلئ (للأزرار المميزة زي زر الإرسال).
 */
@Composable
fun Modifier.glass(shape: Shape = CircleShape, tint: Color? = null): Modifier {
    val st = LocalStyle.current
    val pal = LocalPal.current
    val dark = LocalDark.current
    val flatNoBorder = st.shadow == "flat" && st.border == 0.dp
    val fill = tint ?: if (flatNoBorder) pal.surfaceHi else pal.surface
    val borderColor = if (tint != null && st.shadow != "hard") Color.Transparent else pal.line
    val bw = st.border
    return when (st.shadow) {
        "hard" -> this
            .drawBehind {
                val o = shape.createOutline(size, layoutDirection, this)
                translate(st.offset.toPx(), st.offset.toPx()) { drawOutline(o, pal.line) }
            }
            .clip(shape)
            .drawBehind {
                val o = shape.createOutline(size, layoutDirection, this)
                drawOutline(o, fill)
                drawOutline(o, pal.line, style = Stroke(bw.toPx()))
            }
        "soft" -> {
            val sh = if (dark) Color.Black else Color(0xFF5A4E8C)
            this
                .shadow(if (dark) 10.dp else 8.dp, shape, clip = false, ambientColor = sh.copy(alpha = if (dark) 0.6f else 0.30f), spotColor = sh.copy(alpha = if (dark) 0.6f else 0.30f))
                .clip(shape)
                .drawBehind {
                    val o = shape.createOutline(size, layoutDirection, this)
                    drawOutline(o, fill)
                    // لمعة علوية خفيفة تدي إحساس البروز
                    drawOutline(o, Brush.verticalGradient(listOf(Color.White.copy(alpha = if (dark) 0.07f else 0.55f), Color.Transparent), 0f, size.height * 0.55f))
                    if (bw > 0.dp) drawOutline(o, borderColor, style = Stroke(bw.toPx()))
                    else drawOutline(o, Brush.verticalGradient(listOf(Color.White.copy(alpha = if (dark) 0.12f else 0.8f), Color.Transparent)), style = Stroke(1.dp.toPx()))
                }
        }
        else -> this
            .clip(shape)
            .drawBehind {
                val o = shape.createOutline(size, layoutDirection, this)
                drawOutline(o, fill)
                if (bw > 0.dp) drawOutline(o, borderColor, style = Stroke(bw.toPx()))
            }
    }
}

@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    tint: Color? = null,
    content: @Composable () -> Unit,
) {
    Box(modifier.glass(shape, tint)) { content() }
}

/** زر دايري زجاجي (accent = زجاج ملوّن بلون التطبيق، زي زر الإرسال). */
@Composable
fun GlassCircleButton(
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    accent: Boolean = false,
    enabled: Boolean = true,
    contentDescription: String? = null,
) {
    val tint = if (accent) LocalAccent.current else null
    val fg = if (accent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    val src = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatFast(if (pressed) 0.92f else 1f, androidx.compose.animation.core.spring(), "press")
    Box(
        modifier.size(size).enterPop().graphicsLayer { scaleX = sc; scaleY = sc; rotationZ = if (pressed && Motion.on) -6f else 0f }.glass(CircleShape, tint)
            .clickable(interactionSource = src, indication = null, enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription, Modifier.size(size * 0.5f), tint = if (enabled) fg else fg.copy(alpha = 0.4f))
    }
}

/** الشريط العلوي: جزيرة عائمة بدل TopAppBar. */
@Composable
fun GlassTopBar(
    title: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    navigationIcon: @Composable () -> Unit = {},
    actions: @Composable RowScope.() -> Unit = {},
) {
    Box(modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 6.dp).enterSlideDown(key = "topbar")) {
        Row(
            Modifier.fillMaxWidth().height(56.dp).glass(barShape()).padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            navigationIcon()
            Box(Modifier.weight(1f).padding(horizontal = 8.dp), contentAlignment = Alignment.CenterStart) {
                androidx.compose.material3.ProvideTextStyle(
                    MaterialTheme.typography.titleMedium.copy(fontSize = 18.sp, fontWeight = FontWeight.SemiBold),
                ) { title() }
            }
            actions()
        }
    }
}

/** الشريط السفلي العائم: كبسولة زجاجية، والعنصر المختار دايرة ملوّنة. */
@Composable
fun FloatingNavBar(
    items: List<Pair<ImageVector, String>>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val hapticNav = androidx.compose.ui.platform.LocalHapticFeedback.current
    val ctxNav = androidx.compose.ui.platform.LocalContext.current
    Box(modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 10.dp).enterSlideUp(key = "navbar")) {
        Row(
            Modifier.fillMaxWidth().glass(barShape()).padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            items.forEachIndexed { i, (icon, label) ->
                val sel = i == selected
                val pop by animateFloatFast(if (sel) 1.15f else 1f, androidx.compose.animation.core.spring(dampingRatio = 0.4f, stiffness = 500f), "pop")
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).bounceClick(role = Role.Tab) {
                        if (com.binarybeast.chatapp.data.AppSettings.now.hapticNav) Haptic.tick(ctxNav, hapticNav)
                        onSelect(i)
                    }.padding(vertical = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    val itemShape: Shape = if (LocalStyle.current.radius >= 18.dp) CircleShape else RoundedCornerShape(LocalStyle.current.radius)
                    Box(
                        Modifier.size(40.dp).tada(if (sel) i + 1 else 0).graphicsLayer { scaleX = pop; scaleY = pop }.then(if (sel) Modifier.glass(itemShape, LocalAccent.current) else Modifier),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            icon, label, Modifier.size(22.dp),
                            tint = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text(
                        label, fontSize = 10.sp, maxLines = 1,
                        color = if (sel) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                    )
                }
            }
        }
    }
}

private val DOODLES get() = listOf(
    AIcons.Chat, AIcons.Heart, AIcons.Star, AIcons.Smile, AIcons.Music, AIcons.Moon,
    AIcons.Sun, AIcons.Cloud, AIcons.Bolt, AIcons.Gift, AIcons.Coffee, AIcons.Send,
    AIcons.CameraAlt, AIcons.Call, AIcons.Mic, AIcons.Public,
)

/** خلفية الشات: doodle (أيقونات SVG متكررة زي واتساب) / aurora / dots / plain. */
@Composable
fun ChatWallpaper(style: String, modifier: Modifier = Modifier.fillMaxSize()) {
    val dark = LocalDark.current
    val a = LocalAccent.current
    val bgc = LocalPal.current.bg
    when (style) {
        "plain" -> Box(modifier.background(bgc))
        "aurora" -> AuroraBackground(modifier)
        "dots" -> Canvas(modifier.background(bgc)) {
            val step = 22.dp.toPx()
            val c = if (dark) a.copy(alpha = 0.18f) else a.copy(alpha = 0.25f)
            var y = step / 2
            while (y < size.height) {
                var x = step / 2
                while (x < size.width) { drawCircle(c, 1.4.dp.toPx(), Offset(x, y)); x += step }
                y += step
            }
        }
        else -> {
            val painters = DOODLES.map { rememberVectorPainter(it) }
            val color = LocalPal.current.textDim.copy(alpha = if (dark) 0.10f else 0.13f)
            Box(modifier.background(bgc)) {
                AuroraBackground(Modifier.fillMaxSize())
                Canvas(Modifier.fillMaxSize()) {
                    val cell = 76.dp.toPx()
                    val s = 26.dp.toPx()
                    var row = 0
                    var y = 0f
                    while (y < size.height + cell) {
                        var col = 0
                        var x = if (row % 2 == 0) 0f else cell / 2
                        while (x < size.width + cell) {
                            val k = (row * 7 + col * 3) % painters.size
                            val rot = ((row * 31 + col * 17) % 60 - 30).toFloat()
                            val jx = ((row * 13 + col * 29) % 20 - 10).dp.toPx()
                            val jy = ((row * 19 + col * 11) % 20 - 10).dp.toPx()
                            rotate(rot, Offset(x + jx + s / 2, y + jy + s / 2)) {
                                translate(x + jx, y + jy) {
                                    with(painters[k]) { draw(Size(s, s), 1f, ColorFilter.tint(color)) }
                                }
                            }
                            x += cell; col++
                        }
                        y += cell * 0.9f; row++
                    }
                }
            }
        }
    }
}
