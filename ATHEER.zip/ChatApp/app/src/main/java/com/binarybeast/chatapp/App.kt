package com.binarybeast.chatapp

import android.app.Application
import com.binarybeast.chatapp.call.CallManager
import com.binarybeast.chatapp.data.ChatEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // process الإعادة (:restart) مبتحتاجش أي تهيئة
        val proc = runCatching { java.io.File("/proc/self/cmdline").readText().trim('\u0000') }.getOrDefault(packageName)
        if (proc != packageName) return
        com.binarybeast.chatapp.data.Accounts.init(this)
        com.binarybeast.chatapp.data.AppSettings.init(this)
        com.binarybeast.chatapp.data.ProfileDisk.init(this)
        com.binarybeast.chatapp.data.TelegramStorage.init(this)
        com.binarybeast.chatapp.data.StickerStore.init(this)
        com.binarybeast.chatapp.ui.Lang.init(this)
        com.binarybeast.chatapp.data.SpaceStore.init(this)
        Sounds.init(this)
        com.binarybeast.chatapp.data.Invites.init(this)
        com.binarybeast.chatapp.data.QuickReplies.init(this)
        Notifier.init(this)
        CallManager.init(this)
        ChatEngine.init(this)
        ChatEngine.onIncoming = { msg, profile ->
            CoroutineScope(Dispatchers.IO).launch {
                // نوع الرسالة: 2 منشن (@username بتاعي) | 1 رد على رسالة ليا | 0 عادية
                val myName = ChatEngine.profile(com.binarybeast.chatapp.data.AuthRepository.currentUserId ?: "")?.username
                val kind = when {
                    myName != null && msg.body?.contains("@$myName", ignoreCase = true) == true -> 2
                    msg.replyToId != null && ChatEngine.dao.isMine(msg.replyToId) == true -> 1
                    else -> 0
                }
                val hidden = com.binarybeast.chatapp.data.SpaceStore.isSpace(msg.peerId) || com.binarybeast.chatapp.data.SpaceStore.isHidden(msg.peerId)
                if (ChatEngine.openPeerId == msg.peerId) {
                    // المحادثة مفتوحة قدامك: صوت التطبيق بس من غير إشعار
                    Sounds.play(when (kind) { 2 -> Sounds.Kind.MENTION; 1 -> Sounds.Kind.REPLY; else -> Sounds.Kind.NOTIFY })
                } else if (hidden) {
                    Notifier.important(this@App)
                } else {
                    val who = profile?.displayName?.ifBlank { profile.phone } ?: "رسالة جديدة"
                    if (ChatEngine.isGroup(msg.peerId)) {
                        // في المجموعات: «اسم المجموعة — اسم المرسل»
                        val gn = ChatEngine.groups.get(msg.peerId.removePrefix("g:"))?.name ?: "مجموعة"
                        Notifier.message(this@App, msg, "$gn — $who", kind)
                    } else Notifier.message(this@App, msg, who, kind)
                }
            }
        }
    }
}
