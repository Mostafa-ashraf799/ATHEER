package com.binarybeast.chatapp.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.binarybeast.chatapp.data.AuthRepository
import com.binarybeast.chatapp.data.CallLog
import com.binarybeast.chatapp.data.ChatPreview
import com.binarybeast.chatapp.data.ChatEngine
import com.binarybeast.chatapp.data.local.LocalMessage
import com.binarybeast.chatapp.data.Profile
import com.binarybeast.chatapp.data.ProfileRepository
import com.binarybeast.chatapp.data.StoryGroup
import com.binarybeast.chatapp.data.StoryRepository
import com.binarybeast.chatapp.data.Supa
import com.binarybeast.chatapp.data.TelegramStorage
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

// ------------------------------------------------------------------ Session / Profile

class SessionVm : ViewModel() {
    // بنبدأ بآخر نسخة محفوظة من بروفايلي: التطبيق بيفتح فورًا حتى من غير نت وبيتحدّث لما الاتصال يرجع
    private val _me = MutableStateFlow<Profile?>(com.binarybeast.chatapp.data.ProfileDisk.getMe())
    val me: StateFlow<Profile?> = _me.asStateFlow()

    fun load() = viewModelScope.launch {
        runCatching { ProfileRepository.me() }.onSuccess {
            if (it != null) {
                _me.value = it
                com.binarybeast.chatapp.data.ProfileDisk.putMe(it)
                com.binarybeast.chatapp.data.Accounts.updateInfo(it.id, it.displayName, it.phone)
            }
        }
        runCatching { ProfileRepository.touchLastSeen() }
    }

    /** يرجّع null لو نجح أو رسالة خطأ. */
    suspend fun saveUsername(raw: String): String? {
        val err = ProfileRepository.setUsername(raw)
        if (err == null) load()
        return err
    }

    fun saveProfile(name: String, about: String) = viewModelScope.launch {
        runCatching { ProfileRepository.updateProfile(name = name, about = about) }
        load()
    }

    fun setAvatar(bytes: ByteArray, mime: String, onResult: (String?) -> Unit = {}) = viewModelScope.launch {
        val r = runCatching {
            val small = shrinkAvatar(bytes)
            val id = TelegramStorage.upload(small, "avatar.jpg", "image/jpeg", "image", "avatar")
            ProfileRepository.updateProfile(avatarFileId = id)
        }
        onResult(r.exceptionOrNull()?.let { "تعذّر تغيير الصورة: " + (it.message ?: it.javaClass.simpleName).take(120) })
        load()
    }

    fun setSetting(key: String, value: Any) = viewModelScope.launch {
        runCatching { ProfileRepository.updateSetting(_me.value?.settings, key, value) }
        load()
    }

    fun signOut(ctx: android.content.Context) = viewModelScope.launch {
        val uid = AuthRepository.currentUserId
        ChatEngine.wipeLocal()          // امسح الرسايل المحلية والمفاتيح المؤقتة من الجهاز
        runCatching { AuthRepository.signOut() }
        if (uid != null) com.binarybeast.chatapp.data.Accounts.removeAndSwitch(uid, ctx)
    }
}

// ------------------------------------------------------------------ Login

class LoginVm : ViewModel() {
    val waiting = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    private var token: String? = null
    private var url: String? = null
    private var pollJob: kotlinx.coroutines.Job? = null

    /** بيعمل طلب دخول جديد، يفتح رابط البوت، ويبدأ يسأل السيرفر كل ثانيتين. */
    fun start(openUrl: (String) -> Unit) {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            error.value = null; waiting.value = true
            val (t, u) = runCatching { AuthRepository.startTelegramLogin() }.getOrElse {
                error.value = "تعذّر بدء الدخول: ${it.message}"; waiting.value = false; return@launch
            }
            token = t; url = u
            openUrl(u)
            val deadline = System.currentTimeMillis() + 5 * 60_000
            while (System.currentTimeMillis() < deadline) {
                kotlinx.coroutines.delay(2000)
                val ok = runCatching { AuthRepository.pollTelegramLogin(t) }.getOrElse {
                    error.value = "الطلب انتهى. جرّب تاني."; waiting.value = false; return@launch
                }
                if (ok) { waiting.value = false; return@launch }   // الـ session اتفتحت، AppRoot هيتنقل لوحده
            }
            error.value = "الوقت خلص. جرّب تاني."; waiting.value = false
        }
    }

    fun reopen(openUrl: (String) -> Unit) { url?.let(openUrl) }

    fun cancel() { pollJob?.cancel(); waiting.value = false; token = null; url = null }
}

// ------------------------------------------------------------------ Chats

class ChatListVm : ViewModel() {
    private val _chats = MutableStateFlow<List<ChatPreview>>(emptyList())
    val chats: StateFlow<List<ChatPreview>> = _chats.asStateFlow()
    val searchError = MutableStateFlow<String?>(null)

    init {
        // قايمة المحادثات بتتبني من قاعدة البيانات المحلية وبتتحدّث لحظيًا
        viewModelScope.launch {
            kotlinx.coroutines.flow.combine(ChatEngine.dao.observeLast(), ChatEngine.dao.observeUnread()) { last, unread -> last to unread.associate { it.peerId to it.n } }
                .collect { (last, unread) ->
                    val previews = last.filter { !com.binarybeast.chatapp.data.SpaceStore.isSpace(it.peerId) }.mapNotNull { msg ->
                        val peer = ChatEngine.peerProfile(msg.peerId) ?: return@mapNotNull null
                        ChatPreview(peer, msg, unread[msg.peerId] ?: 0)
                    }.sortedByDescending { it.last.createdAt }
                    _chats.value = previews
                }
        }
    }

    fun load() { /* مفيش حاجة: الـ Flow بيحدّث لوحده */ }

    /** ينشئ مجموعة من أرقام (بفاصلة أو سطر جديد). الأرقام اللي مش مسجّلة بتتجاهل وبنقول كام واحد اتجاهل. */
    fun createGroup(name: String, phonesRaw: String, extra: List<Profile> = emptyList(), onDone: (Profile?) -> Unit) = viewModelScope.launch {
        searchError.value = null
        val phones = phonesRaw.split(',', '\n', '،', ' ').map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        val byPhone = phones.mapNotNull { runCatching { ProfileRepository.findByPhone(it) }.getOrNull() }
        val found = (byPhone + extra)
            .filter { it.id != AuthRepository.currentUserId }.distinctBy { it.id }
        if (name.isBlank() || found.isEmpty()) { searchError.value = "اكتب اسم وأرقام مسجّلة في التطبيق"; onDone(null); return@launch }
        if (byPhone.size < phones.size) searchError.value = "${phones.size - byPhone.size} رقم مش مسجّل واتجاهل"
        onDone(ChatEngine.createGroup(name, found))
    }

    /** يدوّر على مستخدم برقمه ويفتح معاه محادثة. */
    fun findUser(phone: String, onFound: (Profile) -> Unit) = viewModelScope.launch {
        searchError.value = null
        var p = runCatching { ProfileRepository.find(phone) }.getOrNull()
        if (p == null) {
            // ممكن يكون رقم «مساحة خاصة» لحد: الرسايل ليه بتروح لمساحته
            p = runCatching { ProfileRepository.findBySpace(phone) }.getOrNull()?.takeIf { it.id != AuthRepository.currentUserId }
            if (p != null) com.binarybeast.chatapp.data.SpaceStore.markPeer(p.id)
        }
        if (p == null) searchError.value = "الرقم ده مش مسجّل في التطبيق"
        else if (p.id == AuthRepository.currentUserId) searchError.value = "ده رقمك انت 🙂"
        else onFound(p)
    }
}

class ChatVm(val peer: Profile) : ViewModel() {
    private val _messages = MutableStateFlow<List<LocalMessage>>(emptyList())
    val messages: StateFlow<List<LocalMessage>> = _messages.asStateFlow()
    val sending = MutableStateFlow(false)
    /** حجم نافذة الرسايل المحمّلة (بيزيد لما تطلب رسايل أقدم). */
    val limit = MutableStateFlow(150)
    fun loadMore() { limit.value += 150 }

    val typing = ChatEngine.typing
    val isGroup = ChatEngine.isGroup(peer.id)
    val group = MutableStateFlow<com.binarybeast.chatapp.data.local.GroupEntity?>(null)
    val votes = MutableStateFlow<List<com.binarybeast.chatapp.data.local.PollVote>>(emptyList())
    val names = MutableStateFlow<Map<String, String>>(emptyMap())   // id -> اسم (لعرض المرسل في المجموعات)

    // ---- بوتات المجموعة (رسايل البوتات بتيجي من السيرفر وبتتدمج عرضًا بس، مش جوه قاعدة البيانات المحلية)
    val groupBots = MutableStateFlow<List<com.binarybeast.chatapp.data.GroupBotInfo>>(emptyList())
    val botMsgs = MutableStateFlow<List<com.binarybeast.chatapp.data.GroupBotMsg>>(emptyList())
    val botNotice = MutableStateFlow<String?>(null)
    private var roomList: List<LocalMessage> = emptyList()
    private var fastUntil = 0L
    private val gid get() = peer.id.removePrefix("g:")

    private fun isoMs(s: String): Long = runCatching { java.time.OffsetDateTime.parse(s).toInstant().toEpochMilli() }.getOrDefault(System.currentTimeMillis())
    private fun merge() {
        val bots = botMsgs.value.map {
            LocalMessage(
                id = -it.id, msgId = "botg:${it.id}", peerId = peer.id, mine = false, body = it.text, mediaFileId = null, mediaType = null,
                createdAt = isoMs(it.createdAt), status = com.binarybeast.chatapp.data.local.MsgStatus.SENT, read = true, senderId = "bot:" + it.botId,
            )
        }
        _messages.value = if (bots.isEmpty()) roomList else (roomList + bots).sortedBy { it.createdAt }
    }
    fun refreshGroupBots() {
        viewModelScope.launch {
            val l = runCatching { com.binarybeast.chatapp.data.BotRepository.groupBots(gid) }.getOrNull() ?: return@launch
            groupBots.value = l
            names.update { it + l.associate { b -> "bot:" + b.id to (b.name + " 🤖") } }
        }
    }
    private suspend fun fetchBotMsgs() {
        runCatching { com.binarybeast.chatapp.data.BotRepository.groupFetch(gid) }.onSuccess { if (it != botMsgs.value) { botMsgs.value = it; merge() } }
    }
    fun pressGroupButton(m: com.binarybeast.chatapp.data.GroupBotMsg, data: String) {
        viewModelScope.launch {
            val ans = runCatching { com.binarybeast.chatapp.data.BotRepository.groupPress(gid, m.id, data) }.onFailure { botNotice.value = it.message }.getOrNull()
            ans?.answerText?.let { botNotice.value = it }
            fastUntil = System.currentTimeMillis() + 8000
            fetchBotMsgs()
        }
    }
    /** بيبعت للبوتات رسالة المجموعة لو فيها أمر / منشن / رد على بوت، أو لو فيه بوت خصوصيته مقفولة. */
    private fun forwardToBots(text: String, reply: LocalMessage?) {
        val bots = groupBots.value
        if (bots.isEmpty()) return
        val t = text.trim()
        val replyBot = reply?.senderId?.takeIf { it.startsWith("bot:") }?.removePrefix("bot:")
        val q = bots.any { b -> !b.groupPrivacy || t.startsWith("/") || t.contains("@" + b.username, ignoreCase = true) || replyBot == b.id }
        if (!q) return
        viewModelScope.launch {
            runCatching { com.binarybeast.chatapp.data.BotRepository.groupSend(gid, t, replyBot) }.onFailure { botNotice.value = it.message }
            fastUntil = System.currentTimeMillis() + 25_000
            fetchBotMsgs()
        }
    }

    init {
        ChatEngine.openPeerId = peer.id
        ChatEngine.ensureLink(peer.id)          // افتح قناة P2P مع الطرف التاني لو أونلاين
        if (isGroup) {
            val gid = peer.id.removePrefix("g:")
            viewModelScope.launch {
                ChatEngine.groups.observe(gid).collect { g ->
                    group.value = g
                    g?.memberList()?.forEach { id ->
                        if (names.value[id] == null) {
                            val p = ChatEngine.profile(id)
                            if (p != null) names.update { it + (id to p.displayName.ifBlank { p.phone }) }
                        }
                    }
                }
            }
            viewModelScope.launch { ChatEngine.groups.observeVotes(peer.id).collect { votes.value = it } }
            viewModelScope.launch {
                var n = 0
                while (true) {
                    if (n % 6 == 0) refreshGroupBots()
                    if (groupBots.value.isNotEmpty()) fetchBotMsgs()
                    n++
                    kotlinx.coroutines.delay(if (System.currentTimeMillis() < fastUntil) 1000 else 4000)
                }
            }
        }
        viewModelScope.launch {
            @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
            limit.flatMapLatest { n -> ChatEngine.dao.observeRecent(peer.id, n) }.collect { list ->
                roomList = list
                merge()
                if (list.any { !it.mine && !it.read }) ChatEngine.markRead(peer.id)
            }
        }
    }

    override fun onCleared() {
        if (ChatEngine.openPeerId == peer.id) ChatEngine.openPeerId = null
    }

    /** إرسال صامت: المستلم مبيجيلوش إشعار. */
    var silent = false

    fun sendText(text: String, reply: LocalMessage? = null) {
        if (text.isBlank()) return
        com.binarybeast.chatapp.Sounds.play(com.binarybeast.chatapp.Sounds.Kind.SEND)
        viewModelScope.launch { ChatEngine.send(peer, text.trim(), reply = reply, silent = silent) }
        if (isGroup) forwardToBots(text, reply)
    }

    /** إرسال ستيكر/GIF محفوظ (file_id موجود، مفيش رفع). */
    fun sendStored(fileId: String, kind: String) { viewModelScope.launch { runCatching { ChatEngine.send(peer, null, fileId, kind, silent = silent) } } }

    fun react(m: LocalMessage, emoji: String) { viewModelScope.launch { ChatEngine.react(peer, m, emoji) } }
    fun edit(m: LocalMessage, newBody: String) { viewModelScope.launch { ChatEngine.editMessage(peer, m, newBody) } }
    fun deleteForEveryone(m: LocalMessage) { viewModelScope.launch { ChatEngine.deleteForEveryone(peer, m) } }
    fun vote(m: LocalMessage, option: Int) { viewModelScope.launch { ChatEngine.vote(peer, m, option) } }
    fun sendPoll(q: String, options: List<String>) { viewModelScope.launch { ChatEngine.sendPoll(peer, q, options) } }
    fun renameGroup(name: String) { viewModelScope.launch { ChatEngine.updateGroup(peer.id.removePrefix("g:"), name = name) } }
    fun setTtl(sec: Long) { viewModelScope.launch { ChatEngine.updateGroup(peer.id.removePrefix("g:"), ttlSec = sec) } }
    fun setGroupAvatar(bytes: ByteArray, mime: String) { viewModelScope.launch {
        runCatching {
            val id = TelegramStorage.upload(bytes, "group.jpg", mime, "image", "avatar")
            ChatEngine.updateGroup(peer.id.removePrefix("g:"), avatar = id)
        }.onFailure { notice.value = "تعذّر رفع صورة المجموعة" }
    } }
    fun removeMember(id: String) { viewModelScope.launch { ChatEngine.updateGroup(peer.id.removePrefix("g:"), remove = id) } }
    fun addMembers(phonesRaw: String) = viewModelScope.launch {
        val found = phonesRaw.split(',', '\n', '،', ' ').map { it.trim() }.filter { it.isNotEmpty() }
            .mapNotNull { runCatching { ProfileRepository.find(it) }.getOrNull() }
        if (found.isEmpty()) notice.value = "مفيش أرقام مسجّلة" else ChatEngine.updateGroup(peer.id.removePrefix("g:"), add = found.map { it.id })
    }
    fun addProfiles(ps: List<Profile>) { viewModelScope.launch { if (ps.isNotEmpty()) ChatEngine.updateGroup(peer.id.removePrefix("g:"), add = ps.map { it.id }) } }
    fun leaveGroup(onDone: () -> Unit) { viewModelScope.launch { ChatEngine.leaveGroup(peer.id.removePrefix("g:")); onDone() } }
    fun deleteForMe(m: LocalMessage) { viewModelScope.launch { ChatEngine.deleteForMe(m) } }

    /** رسالة نصها/خطأها بيظهر للمستخدم (مثلًا: الملف أكبر من 20 ميجا). */
    val notice = MutableStateFlow<String?>(null)

    fun sendMedia(bytes: ByteArray, name: String, mime: String, caption: String? = null, viewMode: Int = 0, viewSecs: Int = 0) = viewModelScope.launch {
        sending.value = true
        notice.value = null
        runCatching {
            val kind = when {
                mime.startsWith("image/") -> "image"
                mime.startsWith("video/") -> "video"
                mime.startsWith("audio/") -> "audio"
                else -> "file"
            }
            // جودة "عالية" للصور بتترفع كـ document علشان تيليجرام ميصغّرهاش
            val uploadKind = if (kind == "image" && com.binarybeast.chatapp.data.AppSettings.now.uploadQuality == "high") "image_hq" else kind
            val id = TelegramStorage.upload(bytes, name, mime, uploadKind)
            ChatEngine.send(peer, body = caption, fileId = id, mediaType = kind, viewMode = if (kind == "file") 0 else viewMode, viewSecs = viewSecs, silent = silent)
        }.onFailure { notice.value = it.message?.takeIf { m -> m.contains("20") } ?: "تعذّر إرسال الملف" }
        sending.value = false
    }
}

// ------------------------------------------------------------------ Stories

class StoriesVm : ViewModel() {
    private val _groups = MutableStateFlow<List<StoryGroup>>(emptyList())
    val groups: StateFlow<List<StoryGroup>> = _groups.asStateFlow()
    val uploading = MutableStateFlow(false)
    val notice = MutableStateFlow<String?>(null)

    init { load() }

    fun load() = viewModelScope.launch {
        runCatching { StoryRepository.feed() }.onSuccess { _groups.value = it }
    }

    fun repost(src: com.binarybeast.chatapp.data.Story) = viewModelScope.launch {
        notice.value = null
        val active = runCatching { StoryRepository.myActiveCount() }.getOrDefault(0)
        if (active >= StoryRepository.MAX_ACTIVE) { notice.value = "عندك ${StoryRepository.MAX_ACTIVE} ستوريز شغّالة، احذف واحدة الأول"; return@launch }
        runCatching { StoryRepository.repost(src) }
            .onSuccess { notice.value = "اتعاد نشرها في ستوريتك ✅" }
            .onFailure { notice.value = "تعذّر إعادة النشر (ممكن صاحبها منع ده): " + (it.message ?: "").take(100) }
        load()
    }

    /** يحوّل اختيارات (أشخاص + مجموعات) لخريطة userId -> اسم المجموعة اللي اتفردت منها. */
    suspend fun expandMentions(picks: List<Profile>): Map<String, String?> {
        val out = linkedMapOf<String, String?>()
        for (p in picks) {
            if (p.id.startsWith("g:")) {
                val g = ChatEngine.groups.get(p.id.removePrefix("g:")) ?: continue
                g.memberList().forEach { out.putIfAbsent(it, g.name) }
            } else out[p.id] = null
        }
        return out
    }

    fun post(bytes: ByteArray, name: String, mime: String, caption: String?, hours: Double,
             allowRepost: Boolean = false, picks: List<Profile> = emptyList()) = viewModelScope.launch {
        uploading.value = true
        notice.value = null
        val active = runCatching { StoryRepository.myActiveCount() }.getOrDefault(0)
        if (active >= StoryRepository.MAX_ACTIVE) {
            notice.value = "عندك ${StoryRepository.MAX_ACTIVE} ستوريز شغّالة، احذف واحدة أو استنى تخلص"
            uploading.value = false
            return@launch
        }
        runCatching {
            val kind = if (mime.startsWith("video/")) "video" else "image"
            val uploadKind = if (kind == "image" && com.binarybeast.chatapp.data.AppSettings.now.uploadQuality == "high") "image_hq" else kind
            val id = TelegramStorage.upload(bytes, name, mime, uploadKind, "story")
            StoryRepository.post(id, kind, caption, hours, allowRepost, expandMentions(picks))
        }.onFailure { notice.value = "تعذّر نشر الستوري: " + (it.message ?: it.javaClass.simpleName).take(140) }
        uploading.value = false
        load()
    }

    fun seen(id: Long) = viewModelScope.launch { StoryRepository.markSeen(id) }

    fun delete(id: Long) = viewModelScope.launch {
        runCatching { StoryRepository.delete(id) }
        load()
    }
}

// ------------------------------------------------------------------ Calls history

data class CallRow(val log: CallLog, val peer: Profile?, val outgoing: Boolean)

class CallsVm : ViewModel() {
    private val _rows = MutableStateFlow<List<CallRow>>(emptyList())
    val rows: StateFlow<List<CallRow>> = _rows.asStateFlow()

    init { load() }

    fun load() = viewModelScope.launch {
        val uid = AuthRepository.currentUserId ?: return@launch
        runCatching {
            val logs = Supa.client.from("call_logs").select {
                filter { or { eq("caller_id", uid); eq("callee_id", uid) } }
                order("started_at", Order.DESCENDING)
                limit(100)
            }.decodeList<CallLog>()
            val peers = ProfileRepository.byIds(
                logs.map { if (it.callerId == uid) it.calleeId else it.callerId }.toSet()
            ).associateBy { it.id }
            _rows.value = logs.map {
                val outgoing = it.callerId == uid
                CallRow(it, peers[if (outgoing) it.calleeId else it.callerId], outgoing)
            }
        }
    }
}


/** يصغّر صورة البروفايل (حد أقصى 768px، JPEG) — تيليجرام بيرفض الصور الكبيرة (>10MB أو أبعاد ضخمة). */
internal fun shrinkAvatar(bytes: ByteArray): ByteArray {
    val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
    require(o.outWidth > 0 && o.outHeight > 0) { "الملف مش صورة مدعومة" }
    var s = 1
    while (o.outWidth / s > 1536 || o.outHeight / s > 1536) s *= 2
    val bmp = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size,
        android.graphics.BitmapFactory.Options().apply { inSampleSize = s })
        ?: error("تعذّر قراءة الصورة")
    val m = 768f / maxOf(bmp.width, bmp.height)
    val out = if (m < 1f) android.graphics.Bitmap.createScaledBitmap(bmp, (bmp.width * m).toInt().coerceAtLeast(1), (bmp.height * m).toInt().coerceAtLeast(1), true) else bmp
    val bos = java.io.ByteArrayOutputStream()
    out.compress(android.graphics.Bitmap.CompressFormat.JPEG, 88, bos)
    return bos.toByteArray()
}
