package com.binarybeast.chatapp

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * بتشتغل في process منفصل (:restart): بتقتل process التطبيق الأساسي وتفتحه من جديد.
 * (بنستخدمها لتبديل الحسابات.)
 */
class RestartActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pid = intent.getIntExtra("pid", -1)
        @Suppress("DEPRECATION")
        val target = intent.getParcelableExtra<Intent>("target")
        if (pid > 0) android.os.Process.killProcess(pid)
        if (target != null) startActivity(target)
        finish()
        Runtime.getRuntime().exit(0)
    }
}
