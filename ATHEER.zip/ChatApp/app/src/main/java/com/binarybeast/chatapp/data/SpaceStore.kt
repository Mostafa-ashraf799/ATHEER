package com.binarybeast.chatapp.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * «المساحات الخاصة»: لحد 5 مساحات مخفية، كل واحدة برقم سري مختلف (بيدوّر عليه في البحث).
 * - الرقم نفسه مبيتخزّنش: بصمة محلية PBKDF2-SHA256 بملح عشوائي (متخزّنة مشفّرة بمفتاح الجهاز)، وبصمة تانية بتتنشر في البروفايل علشان الناس توصلك.
 * - كل مساحة لها محادثاتها المخفية وأشخاصها. محادثات المساحة 0 معرّفها "s:<userId>"، وباقي المساحات "s:<رقم المساحة>~<userId>".
 * - تغيير الرقم أو حذف المساحة بيطلبوا الرقم الحالي.
 */
object SpaceStore {
    data class Space(val id: String, val name: String)

    private class Rec(val id: String, var name: String, val salt: String?, val hash: String, val pub: String?)

    private lateinit var plain: SharedPreferences      // الأشياء غير السرية (المخفي/الأشخاص)
    private lateinit var secret: SharedPreferences     // بصمات الأرقام
    const val MAX = 5
    const val PREFIX = "s:"
    private const val ITER = 60_000

    fun init(ctx: Context) {
        val app = ctx.applicationContext
        plain = app.getSharedPreferences(Accounts.name("space"), Context.MODE_PRIVATE)
        secret = runCatching {
            SecurePrefs.open(app, Accounts.name("space_sec"))
        }.getOrElse { app.getSharedPreferences(Accounts.name("space_sec_plain"), Context.MODE_PRIVATE) }
        loadHidden()
    }

    fun isSpace(peerId: String) = peerId.startsWith(PREFIX)
    /** المعرّف الحقيقي للمستخدم (من معرّف محادثة المساحة). */
    fun realId(peerId: String) = peerId.removePrefix(PREFIX).substringAfter('~')
    fun spaceIdOf(peerId: String): String = peerId.removePrefix(PREFIX).let { if ('~' in it) it.substringBefore('~') else "0" }
    fun chatId(spaceId: String, uid: String) = if (spaceId == "0") PREFIX + uid else "$PREFIX$spaceId~$uid"

    val valid: (String) -> Boolean = { it.length in 8..15 && it.all(Char::isDigit) }
    private fun norm(n: String) = n.filter { it.isDigit() }

    /** رقم ضعيف؟ (أرقام متكررة أو متسلسلة أو قليلة التنوع) — للأرقام الجديدة بس. */
    fun weak(number: String): Boolean {
        val n = norm(number)
        if (n.toSet().size < 4) return true
        if ("01234567890123456789".contains(n) || "98765432109876543210".contains(n)) return true
        return false
    }
    const val MIN_NEW = 10

    // ---------------- البصمات
    private fun sha(s: String, rounds: Int): String {
        val md = MessageDigest.getInstance("SHA-256")
        var b = s.toByteArray()
        repeat(rounds) { b = md.digest(b) }
        return b.joinToString("") { "%02x".format(it) }
    }

    /** بصمة بتتنشر في البروفايل (بتتحسب كده علشان اللي بيدوّر عليك يوصل لنفس القيمة). */
    fun publicHash(number: String): String = sha("athr-space-pub:" + norm(number), 20000)
    private fun legacyLocalHash(number: String): String = sha("athr-space-loc:" + norm(number), 20000)

    private fun pbkdf2(password: String, salt: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(password.toByteArray(), "HmacSHA256"))
        var u = mac.doFinal(salt + byteArrayOf(0, 0, 0, 1))
        val out = u.copyOf()
        repeat(ITER - 1) { u = mac.doFinal(u); for (i in out.indices) out[i] = (out[i].toInt() xor u[i].toInt()).toByte() }
        return out
    }
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    // ---------------- المساحات
    private fun recs(): MutableList<Rec> {
        val out = mutableListOf<Rec>()
        val raw = secret.getString("spaces", null)
        if (raw != null) runCatching {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out += Rec(o.getString("id"), o.optString("name"), o.optString("salt").ifEmpty { null }, o.getString("h"), o.optString("pub").ifEmpty { null })
            }
        }
        // مساحة قديمة (قبل التعدد): بصمة قديمة في الـ prefs العادية → مساحة رقم 0
        val legacy = plain.getString("lh", null)
        if (legacy != null && out.none { it.id == "0" }) out += Rec("0", "المساحة الأولى", null, legacy, null)
        return out.sortedBy { it.id }.toMutableList()
    }
    private fun save(l: List<Rec>) {
        val a = JSONArray()
        l.forEach { r -> a.put(JSONObject().put("id", r.id).put("name", r.name).put("salt", r.salt ?: "").put("h", r.hash).put("pub", r.pub ?: "")) }
        secret.edit().putString("spaces", a.toString()).apply()
        plain.edit().remove("lh").apply()   // البصمة القديمة اتنقلت
    }

    val enabled: Boolean get() = ::plain.isInitialized && recs().isNotEmpty()
    fun list(): List<Space> = if (::plain.isInitialized) recs().map { Space(it.id, it.name) } else emptyList()

    private fun check(r: Rec, number: String): Boolean {
        val n = norm(number)
        if (!valid(n)) return false
        return if (r.salt == null) legacyLocalHash(n) == r.hash
        else MessageDigest.isEqual(unhex(r.hash), pbkdf2(n, unhex(r.salt)))
    }

    /** المساحة المفتوحة حاليًا (بعد كتابة رقمها). بتتصفّر لما التطبيق يروح للخلفية. */
    @Volatile var active: String? = null
        private set
    fun lock() { active = null }

    /** لو الرقم ده بتاع مساحة: يفتحها (active) ويرجّع true. تقيل شوية (PBKDF2) فمتتندهش من الـ Main. */
    fun matches(q: String): Boolean {
        if (!enabled) return false
        val n = norm(q)
        if (!valid(n)) return false
        for (r in recs()) if (check(r, n)) { active = r.id; return true }
        return false
    }

    /** إضافة مساحة جديدة. بيرجّع رسالة الخطأ أو null لو نجح. */
    fun add(name: String, number: String): String? {
        val n = norm(number)
        if (n.length < MIN_NEW || n.length > 15) return "الرقم السري من $MIN_NEW لـ 15 رقم"
        if (weak(n)) return "الرقم ضعيف (أرقام متكررة أو متسلسلة). اختار رقم عشوائي"
        val l = recs()
        if (l.size >= MAX) return "الحد الأقصى $MAX مساحات"
        if (l.any { check(it, n) }) return "الرقم ده مستخدم في مساحة تانية"
        val id = (0 until MAX).map { it.toString() }.first { s -> l.none { it.id == s } }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        l += Rec(id, name.trim().ifBlank { "مساحة ${l.size + 1}" }, hex(salt), hex(pbkdf2(n, salt)), publicHash(n))
        save(l)
        return null
    }

    /** تغيير رقم مساحة (لازم الرقم الحالي). */
    fun change(id: String, old: String, new: String): String? {
        val l = recs()
        val r = l.firstOrNull { it.id == id } ?: return "المساحة مش موجودة"
        if (!check(r, old)) return "الرقم الحالي غلط"
        val n = norm(new)
        if (n.length < MIN_NEW || n.length > 15) return "الرقم الجديد من $MIN_NEW لـ 15 رقم"
        if (weak(n)) return "الرقم الجديد ضعيف. اختار رقم عشوائي"
        if (l.any { it.id != id && check(it, n) }) return "الرقم ده مستخدم في مساحة تانية"
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val i = l.indexOf(r)
        l[i] = Rec(id, r.name, hex(salt), hex(pbkdf2(n, salt)), publicHash(n))
        save(l)
        return null
    }

    fun rename(id: String, name: String) {
        val l = recs(); l.firstOrNull { it.id == id }?.name = name.trim().ifBlank { return }; save(l)
    }

    /** حذف مساحة (لازم رقمها). محادثاتها بترجع للشات العادي. */
    fun remove(id: String, number: String): String? {
        val l = recs()
        val r = l.firstOrNull { it.id == id } ?: return "المساحة مش موجودة"
        if (!check(r, number)) return "الرقم غلط"
        l.remove(r); save(l)
        if (active == id) active = null
        // رجّع محادثاتها للشات: المخفية بتتشال من الخريطة، ومحادثات الأرقام (s:) بتفضل محلية بس مخفية
        _hmap = _hmap.filterValues { it != id }; saveHidden()
        return null
    }

    /** تعديل لإعدادات البروفايل المنشورة: sh لمساحة 0، sh1..sh4 للباقي. بيتجاهل مساحة 0 القديمة (بصمتها منشورة أصلًا). */
    fun publishPatch(): Map<String, String> {
        val l = recs()
        val out = linkedMapOf<String, String>()
        for (slot in 0 until MAX) {
            val key = if (slot == 0) "sh" else "sh$slot"
            val r = l.firstOrNull { it.id == slot.toString() }
            if (r == null) out[key] = ""
            else if (r.pub != null) out[key] = r.pub
        }
        return out
    }
    val publishKeys: List<String> get() = (0 until MAX).map { if (it == 0) "sh" else "sh$it" }

    // ---------------- المحادثات/المجموعات/القنوات المخفية: معرّف → رقم المساحة. المعرّفات: uid | g:<id> | c:<channelId>
    private var _hmap: Map<String, String> = emptyMap()
    private val _hidden = kotlinx.coroutines.flow.MutableStateFlow<Set<String>>(emptySet())
    val hidden: kotlinx.coroutines.flow.StateFlow<Set<String>> = _hidden

    private fun loadHidden() {
        val m = linkedMapOf<String, String>()
        runCatching {
            val o = JSONObject(plain.getString("hmap", "{}") ?: "{}")
            o.keys().forEach { k -> m[k] = o.getString(k) }
        }
        // القديم: مجموعة ids من غير مساحة → مساحة 0
        plain.getStringSet("hidden", null)?.forEach { m.putIfAbsent(it, "0") }
        _hmap = m
        _hidden.value = m.keys
    }
    private fun saveHidden() {
        _hidden.value = _hmap.keys
        if (!::plain.isInitialized) return
        val o = JSONObject(); _hmap.forEach { (k, v) -> o.put(k, v) }
        plain.edit().putString("hmap", o.toString()).remove("hidden").apply()
    }
    fun isHidden(id: String) = id in _hmap
    fun hiddenIn(spaceId: String): Set<String> = _hmap.filterValues { it == spaceId }.keys
    fun hide(id: String, spaceId: String? = null) {
        val sid = spaceId ?: active ?: list().firstOrNull()?.id ?: "0"
        _hmap = _hmap + (id to sid); saveHidden()
    }
    fun unhide(id: String) { _hmap = _hmap - id; saveHidden() }

    // ---------------- أشخاص بعتناهم عن طريق رقم مساحتهم (علشان رسايلنا ليهم تروح لمساحتهم)
    private fun peerMap(): JSONObject = runCatching { JSONObject(plain.getString("peers2", "{}") ?: "{}") }.getOrDefault(JSONObject())
    fun isSpacePeer(userId: String): Boolean =
        ::plain.isInitialized && (peerMap().has(userId) || userId in (plain.getStringSet("peers", emptySet()) ?: emptySet()))
    /** بادئة بصمة المساحة اللي الشخص ده بعتنا له عن طريقها (بتتبعت في الرسالة علشان توصل للمساحة الصح عنده). */
    fun peerKey(userId: String): String? = if (::plain.isInitialized) peerMap().optString(userId).ifEmpty { null } else null
    fun markPeer(userId: String, number: String? = null) {
        if (!::plain.isInitialized) return
        val m = peerMap()
        m.put(userId, number?.let { publicHash(it).take(12) } ?: m.optString(userId))
        plain.edit().putString("peers2", m.toString()).apply()
    }

    /** رسالة جاية بعلامة مساحة: تروح لأنهي مساحة؟ (null لو مفيش مساحات). */
    fun route(senderId: String, key: String?): String? {
        val l = recs()
        if (l.isEmpty()) return null
        val sid = key?.takeIf { it.isNotEmpty() }?.let { k -> l.firstOrNull { it.pub?.startsWith(k) == true }?.id } ?: l.first().id
        return chatId(sid, senderId)
    }

    fun clearAll() {
        if (::plain.isInitialized) plain.edit().clear().apply()
        if (::secret.isInitialized) secret.edit().clear().apply()
        _hmap = emptyMap(); _hidden.value = emptySet(); active = null
    }
}
