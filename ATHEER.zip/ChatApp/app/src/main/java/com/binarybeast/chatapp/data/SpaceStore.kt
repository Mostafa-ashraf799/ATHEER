package com.binarybeast.chatapp.data

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest

/**
 * «المساحة الخاصة»: مساحة مخفية بتتفتح برقم سري بيحدده المستخدم (بيدوّر عليه في البحث).
 * - الرقم نفسه مبيتخزّنش في أي مكان: بس بصمة (hash) محلية، وبصمة تانية بتتنشر في البروفايل علشان الناس تقدر توصلك بيه.
 * - محادثات المساحة بتتخزن محليًا بمعرّف "s:<userId>" ومبتظهرش في قايمة الشات ولا في البحث العادي.
 */
object SpaceStore {
    private lateinit var sp: SharedPreferences
    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences(Accounts.name("space"), Context.MODE_PRIVATE)
        _hidden.value = sp.getStringSet("hidden", emptySet()) ?: emptySet()
    }

    const val PREFIX = "s:"
    fun isSpace(peerId: String) = peerId.startsWith(PREFIX)
    fun realId(peerId: String) = peerId.removePrefix(PREFIX)

    val valid: (String) -> Boolean = { it.length in 8..15 && it.all(Char::isDigit) }

    private fun sha(s: String, rounds: Int): String {
        val md = MessageDigest.getInstance("SHA-256")
        var b = s.toByteArray()
        repeat(rounds) { b = md.digest(b) }
        return b.joinToString("") { "%02x".format(it) }
    }
    private fun norm(n: String) = n.filter { it.isDigit() }

    /** بصمة بتتنشر في البروفايل (بطيئة عمدًا علشان التخمين يبقى صعب). */
    fun publicHash(number: String): String = sha("athr-space-pub:" + norm(number), 20000)
    private fun localHash(number: String): String = sha("athr-space-loc:" + norm(number), 20000)

    val enabled: Boolean get() = ::sp.isInitialized && sp.getString("lh", null) != null
    fun set(number: String) { sp.edit().putString("lh", localHash(number)).apply() }
    fun disable() { sp.edit().remove("lh").apply() }
    fun matches(q: String): Boolean {
        if (!enabled) return false
        val n = norm(q)
        if (!valid(n)) return false
        return sp.getString("lh", null) == localHash(n)
    }

    // ---- محادثات/مجموعات/قنوات «اتضافت» للمساحة (بتختفي من الشات وبتظهر في المساحة). المعرّفات: uid | g:<id> | c:<channelId>
    private val _hidden = kotlinx.coroutines.flow.MutableStateFlow<Set<String>>(emptySet())
    val hidden: kotlinx.coroutines.flow.StateFlow<Set<String>> = _hidden
    fun isHidden(id: String) = id in _hidden.value
    fun hide(id: String) { _hidden.value = _hidden.value + id; saveHidden() }
    fun unhide(id: String) { _hidden.value = _hidden.value - id; saveHidden() }
    private fun saveHidden() { if (::sp.isInitialized) sp.edit().putStringSet("hidden", _hidden.value).apply() }

    /** مستخدمين بعتلهم رسايل عن طريق رقم المساحة بتاعهم (علشان رسايلنا ليهم تروح لمساحتهم). */
    fun isSpacePeer(userId: String): Boolean = ::sp.isInitialized && userId in (sp.getStringSet("peers", emptySet()) ?: emptySet())
    fun markPeer(userId: String) {
        if (!::sp.isInitialized) return
        sp.edit().putStringSet("peers", (sp.getStringSet("peers", emptySet()) ?: emptySet()) + userId).apply()
    }
    fun clearAll() { if (::sp.isInitialized) sp.edit().clear().apply(); _hidden.value = emptySet() }
}
