package com.binarybeast.chatapp.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binarybeast.chatapp.data.AppSettings
import com.binarybeast.chatapp.data.AuthRepository
import com.binarybeast.chatapp.data.ChatEngine
import com.binarybeast.chatapp.data.Invites
import com.binarybeast.chatapp.data.Profile
import com.binarybeast.chatapp.data.local.LocalMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ======================================================= بث رسالة لأكتر من شخص

@Composable
fun BroadcastDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var pick by remember { mutableStateOf(false) }
    if (pick) {
        PickChatsDialog("ابعت لمين؟", includeGroups = true, confirmLabel = "إرسال", onDone = { ps ->
            val t = text.trim()
            scope.launch {
                var ok = 0
                ps.forEach { p -> if (runCatching { ChatEngine.send(p, t) }.isSuccess) ok++ }
                Toast.makeText(ctx, "اتبعتت لـ $ok", Toast.LENGTH_SHORT).show()
            }
            pick = false; onClose()
        }, onClose = { pick = false })
        return
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("📣 رسالة لأكتر من شخص") },
        text = { OutlinedTextField(text, { text = it.take(2000) }, label = { Text("الرسالة") }, maxLines = 6) },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { pick = true }) { Text("اختار المستلمين") } },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } },
    )
}

// ======================================================= ملاحظة خاصة + كتم مؤقت + إحصائيات محادثة

@Composable
fun NoteDialog(peerId: String, onClose: () -> Unit) {
    var t by remember { mutableStateOf(AppSettings.note(peerId)) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("📝 ملاحظة خاصة") },
        text = { OutlinedTextField(t, { t = it.take(300) }, placeholder = { Text("بتظهر ليك انت بس، مش بتتبعت لحد") }, maxLines = 5) },
        confirmButton = { TextButton(onClick = { AppSettings.setNote(peerId, t); onClose() }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } },
    )
}

@Composable
fun MuteForDialog(peerId: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    ChoiceDialog(
        "كتم الإشعارات لمدة", listOf("1" to "ساعة", "8" to "٨ ساعات", "168" to "أسبوع", "0" to "إلغاء الكتم المؤقت"), "1",
        { v ->
            val h = v.toInt()
            AppSettings.muteUntil(peerId, if (h > 0) System.currentTimeMillis() + h * 3600_000L else 0L)
            Toast.makeText(ctx, if (h > 0) "اتكتمت مؤقتًا 🔕" else "اتلغى الكتم", Toast.LENGTH_SHORT).show()
        },
        onClose,
    )
}

private class Stat(val total: Int, val mine: Int, val media: Int, val firstAt: Long, val avgLen: Int)

private fun statOf(l: List<LocalMessage>): Stat {
    val mine = l.filter { it.mine && !it.deleted }
    val lens = mine.mapNotNull { it.body?.length }
    return Stat(l.size, mine.size, l.count { it.mediaFileId != null }, l.minOfOrNull { it.createdAt } ?: 0L, if (lens.isEmpty()) 0 else lens.sum() / lens.size)
}

@Composable
fun ChatStatsDialog(peer: Profile, onClose: () -> Unit) {
    val st by produceState<Stat?>(null, peer.id) { value = withContext(Dispatchers.IO) { statOf(runCatching { ChatEngine.dao.chatAll(peer.id) }.getOrDefault(emptyList())) } }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("📊 إحصائيات المحادثة") },
        text = {
            val s = st
            if (s == null) Text("بيتحسب…") else Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("إجمالي الرسايل: ${s.total}")
                Text("اللي بعتّها: ${s.mine} • اللي جتلك: ${s.total - s.mine}")
                Text("ميديا وملفات: ${s.media}")
                Text("متوسط طول رسايلك: ${s.avgLen} حرف")
                if (s.firstAt > 0) {
                    val days = ((System.currentTimeMillis() - s.firstAt) / 86_400_000L).coerceAtLeast(1)
                    Text("أول رسالة من ${days} يوم • بمعدّل ${"%.1f".format(s.total / days.toDouble())} رسالة/يوم")
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("تمام") } },
    )
}

// ======================================================= صفحة الإحصائيات العامة (في الإعدادات)

private class Overall(
    val total: Int, val sent: Int, val media: Int, val chats: Int, val busiestHour: Int, val streak: Int,
    val days: List<Int>, val top: List<Pair<String, Int>>,
)

@Composable
fun StatsPage() {
    val data by produceState<Overall?>(null) {
        value = withContext(Dispatchers.IO) {
            val all = runCatching { ChatEngine.dao.observeAll().first() }.getOrDefault(emptyList()).filter { !it.deleted }
            val zone = java.time.ZoneId.systemDefault()
            val today = java.time.LocalDate.now(zone)
            fun dayOf(ms: Long) = java.time.Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()
            val perDay = all.groupingBy { dayOf(it.createdAt) }.eachCount()
            val last7 = (6 downTo 0).map { perDay[today.minusDays(it.toLong())] ?: 0 }
            var streak = 0
            var d = today
            while ((perDay[d] ?: 0) > 0) { streak++; d = d.minusDays(1) }
            val hours = all.groupingBy { java.time.Instant.ofEpochMilli(it.createdAt).atZone(zone).hour }.eachCount()
            val byPeer = all.groupingBy { it.peerId }.eachCount().entries.sortedByDescending { it.value }.take(5)
            val top = byPeer.map { (id, n) ->
                val nm = runCatching { ChatEngine.peerProfile(id) }.getOrNull()?.let { it.displayName.ifBlank { it.phone } } ?: if (id == AuthRepository.currentUserId) "الرسائل المحفوظة" else id.take(8)
                nm to n
            }
            Overall(all.size, all.count { it.mine }, all.count { it.mediaFileId != null }, all.map { it.peerId }.distinct().size,
                hours.maxByOrNull { it.value }?.key ?: -1, streak, last7, top)
        }
    }
    val o = data
    if (o == null) { Text("بيتحسب…", Modifier.padding(16.dp)); return }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("إجمالي الرسايل: ${o.total}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("اللي بعتّها ${o.sent} • اللي استلمتها ${o.total - o.sent}")
        Text("ميديا وملفات: ${o.media} • محادثات: ${o.chats}")
        if (o.busiestHour >= 0) Text("أكتر وقت بتكلّم فيه: الساعة %02d:00".format(o.busiestHour))
        Text("أيام متتالية بتتكلّم فيها: ${o.streak} 🔥")
        Text("آخر ٧ أيام", Modifier.padding(top = 10.dp), fontWeight = FontWeight.SemiBold)
        val mx = (o.days.maxOrNull() ?: 1).coerceAtLeast(1)
        Row(Modifier.fillMaxWidth().height(90.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
            o.days.forEachIndexed { i, n ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$n", fontSize = 10.sp)
                    Box(Modifier.fillMaxWidth().height((60f * n / mx + 3f).dp).clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.primary).enterBounce(delayMs = i * 60))
                }
            }
        }
        if (o.top.isNotEmpty()) {
            Text("أكتر ٥ محادثات", Modifier.padding(top = 10.dp), fontWeight = FontWeight.SemiBold)
            o.top.forEach { (n, c) -> Row(Modifier.fillMaxWidth()) { Text(n, Modifier.weight(1f), maxLines = 1); Text("$c") } }
        }
    }
}

// ======================================================= صفحة «ميزات إضافية»

@Composable
private fun Sw(title: String, sub: String?, v: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!v) }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            sub?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        Switch(v, onChange)
    }
}

@Composable
fun FeaturesPage() {
    val p by AppSettings.prefs.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    fun u(f: com.binarybeast.chatapp.data.Prefs.() -> com.binarybeast.chatapp.data.Prefs) = AppSettings.update { it.f() }

    Text("الشات", Modifier.padding(16.dp, 12.dp, 16.dp, 2.dp), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
    Sw("نظام ٢٤ ساعة", "لو مقفول الوقت بيظهر ١٢ ساعة (ص/م)", p.time24) { v -> u { copy(time24 = v) } }
    Sw("اهتزاز خفيف", "عند إرسال رسالة وعند ❤️ بالضغط المزدوج", p.haptics) { v -> u { copy(haptics = v) } }
    Sw("إيموجي كبيرة", "الرسالة اللي كلها إيموجي بتظهر بحجم كبير", p.bigEmoji) { v -> u { copy(bigEmoji = v) } }
    Sw("ضغطتين = ❤️", "ضغطتين على رسالة تحط عليها ❤️", p.doubleTapLike) { v -> u { copy(doubleTapLike = v) } }
    Sw("خط عريض للرسايل", null, p.boldText) { v -> u { copy(boldText = v) } }
    Sw("عدّاد الحروف", "يظهر لما الرسالة تعدّي ٤٠٠ حرف", p.charCounter) { v -> u { copy(charCounter = v) } }
    Sw("الشاشة تفضل منوّرة في الشات", null, p.keepScreenOn) { v -> u { copy(keepScreenOn = v) } }
    Sw("إخفاء علامات الإرسال (✓✓)", null, p.hideTicks) { v -> u { copy(hideTicks = v) } }

    Text("قايمة المحادثات", Modifier.padding(16.dp, 12.dp, 16.dp, 2.dp), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
    Sw("«بيكتب…» في القايمة", null, p.typingInList) { v -> u { copy(typingInList = v) } }
    Sw("عدد غير المقروء جنب العنوان", null, p.unreadInTitle) { v -> u { copy(unreadInTitle = v) } }
    Sw("قايمة مضغوطة", "صفوف أصغر عشان تشوف محادثات أكتر", p.compactList) { v -> u { copy(compactList = v) } }
    Text("الترتيب بيتغيّر من قايمة ⋮ في شاشة المحادثات.", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall)

    Text("المظهر", Modifier.padding(16.dp, 12.dp, 16.dp, 2.dp), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
    Sw("أسود كامل (AMOLED)", "في الثيم الداكن: خلفية سودا تماماً بتوفّر بطارية", p.amoled) { v -> u { copy(amoled = v) } }
    Sw("اهتزاز عند تبديل التابات", null, p.hapticNav) { v -> u { copy(hapticNav = v) } }
    TextButton(onClick = {
        u { copy(bigEmoji = true, haptics = true, boldText = false, compactList = false, amoled = false, time24 = true, hideTicks = false) }
        Toast.makeText(ctx, "اترجّعت إعدادات المظهر", Toast.LENGTH_SHORT).show()
    }, Modifier.padding(horizontal = 8.dp)) { Text("ترجيع إعدادات المظهر للافتراضي") }

    Text("أدوات", Modifier.padding(16.dp, 12.dp, 16.dp, 2.dp), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
    TextButton(onClick = {
        scope.launch {
            val me = runCatching { ChatEngine.profile(AuthRepository.currentUserId ?: "") }.getOrNull()
            if (me != null) shareText(ctx, Invites.user(me)) else Toast.makeText(ctx, "الحساب لسه بيتحمّل", Toast.LENGTH_SHORT).show()
        }
    }, Modifier.padding(horizontal = 8.dp)) { Text("🔗 شارك لينك حسابي") }
    TextButton(onClick = {
        scope.launch {
            val txt = withContext(Dispatchers.IO) {
                val f = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                val all = runCatching { ChatEngine.dao.observeAll().first() }.getOrDefault(emptyList()).filter { !it.deleted }.sortedByDescending { it.createdAt }.take(1500).sortedBy { it.createdAt }
                all.joinToString("\n") { m -> "[" + f.format(java.util.Date(m.createdAt)) + "] " + (if (m.mine) "أنا" else m.peerId.take(6)) + ": " + (m.body ?: ("<" + (m.mediaType ?: "ملف") + ">")) }
            }
            shareText(ctx, txt.ifBlank { "—" }.take(200_000))
        }
    }, Modifier.padding(horizontal = 8.dp)) { Text("📤 تصدير آخر ١٥٠٠ رسالة (كل المحادثات)") }
}
