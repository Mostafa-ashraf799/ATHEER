package com.binarybeast.chatapp.ui

import android.content.Intent
import android.provider.Settings
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import com.binarybeast.chatapp.data.local.previewText
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.coerceAtMost
import com.binarybeast.chatapp.data.AppSettings
import com.binarybeast.chatapp.data.ChatEngine
import com.binarybeast.chatapp.data.Profile
import com.binarybeast.chatapp.data.ProfileRepository
import kotlinx.coroutines.launch
import java.io.File

private enum class Page(val title: String) {
    Main("حسابي"), Account("الحساب"), Privacy("الخصوصية والأمان"), Chats("الشات"),
    Notifications("الإشعارات"), Storage("التخزين والبيانات"), Calls("المكالمات"),
    Browser("المتصفح"), Blocked("المحظورين"), About("عن التطبيق"), Style("نمط التصميم"), Space("المساحة الخاصة"), Starred("الرسايل المميّزة"), Anim("الحركات"), Stats("إحصائياتي"), Devices("الأجهزة المرتبطة"), Extras("ميزات إضافية"),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(session: SessionVm) {
    var page by remember { mutableStateOf(Page.Main) }
    BackHandler(enabled = page != Page.Main) { page = Page.Main }

    Scaffold(
        topBar = {
            GlassTopBar(
                title = { Text(page.title, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    if (page != Page.Main) IconButton(onClick = { page = Page.Main }) {
                        Icon(AIcons.ArrowBack, "رجوع")
                    }
                },
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())) {
            when (page) {
                Page.Main -> MainPage(session) { page = it }
                Page.Account -> AccountPage(session)
                Page.Privacy -> PrivacyPage { page = it }
                Page.Chats -> ChatsPage()
                Page.Notifications -> NotificationsPage()
                Page.Storage -> StoragePage()
                Page.Calls -> CallsPage()
                Page.Browser -> BrowserPage()
                Page.Blocked -> BlockedPage()
                Page.About -> AboutPage()
                Page.Style -> StylePage()
                Page.Space -> SpacePage(session)
                Page.Starred -> StarredPage()
                Page.Anim -> AnimPage()
                Page.Stats -> StatsPage()
                Page.Devices -> DevicesPage()
                Page.Extras -> FeaturesPage()
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

// ============================================================ الرئيسية

@Composable
private fun MainPage(session: SessionVm, go: (Page) -> Unit) {
    val me by session.me.collectAsState()
    val ctx = LocalContext.current
    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { val (b, _, m) = readUri(ctx, it); session.setAvatar(b, m) { err -> android.widget.Toast.makeText(ctx, err ?: "اتغيّرت الصورة ✅", android.widget.Toast.LENGTH_LONG).show() } }
    }

    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box {
            Avatar(me?.avatarFileId, me?.displayName.orEmpty().ifBlank { me?.phone.orEmpty() }, 110.dp)
            IconButton(onClick = { avatarPicker.launch("image/*") }, modifier = Modifier.align(Alignment.BottomEnd)) {
                Icon(AIcons.CameraAlt, "تغيير الصورة", tint = MaterialTheme.colorScheme.primary)
            }
        }
        Text(me?.displayName?.ifBlank { "اكتب اسمك من «الحساب»" } ?: "", style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(top = 10.dp))
        Text(me?.about.orEmpty(), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    HorizontalDivider()
    NavRow(AIcons.Person, "الحساب", "الاسم والحالة والصورة") { go(Page.Account) }
    NavRow(AIcons.Lock, "الخصوصية والأمان", "آخر ظهور، المكالمات، منع لقطات الشاشة") { go(Page.Privacy) }
    NavRow(AIcons.Lock, "المساحة الخاصة", if (com.binarybeast.chatapp.data.SpaceStore.enabled) "مفعّلة" else "مساحة مخفية برقم سري") { go(Page.Space) }
    NavRow(AIcons.Call, "الأجهزة المرتبطة", "ربط أكتر من جهاز بنفس الحساب (QR) ومزامنة P2P") { go(Page.Devices) }
    NavRow(AIcons.AutoAwesome, "ميزات إضافية", "وقت ١٢/٢٤، اهتزاز، إيموجي كبيرة، AMOLED، أدوات…") { go(Page.Extras) }
    NavRow(AIcons.Star, "إحصائياتي", "رسايلك، أكتر وقت، أكتر محادثات، رسم أسبوعي") { go(Page.Stats) }
    NavRow(AIcons.AutoAwesome, "الحركات", "٥٠+ أنيميشن • تشغيل/إيقاف ومعرض") { go(Page.Anim) }
    NavRow(AIcons.Chat, "الرسايل المميّزة", "كل الرسايل اللي حطيت عليها نجمة") { go(Page.Starred) }
    NavRow(AIcons.AutoAwesome, "نمط التصميم", "${styleOf(AppSettings.now.uiStyle).name} • ٧ أنماط للتطبيق كله") { go(Page.Style) }
    NavRow(AIcons.Chat, "الشات", "الثيم، حجم الخط، زر الإدخال") { go(Page.Chats) }
    NavRow(AIcons.Notifications, "الإشعارات", "الرسايل والمكالمات والمعاينة") { go(Page.Notifications) }
    NavRow(AIcons.Storage, "التخزين والبيانات", "التحميل التلقائي وجودة الرفع") { go(Page.Storage) }
    NavRow(AIcons.Call, "المكالمات", "توفير البيانات وإلغاء الضوضاء") { go(Page.Calls) }
    NavRow(AIcons.Public, "المتصفح", "فتح الروابط داخل التطبيق") { go(Page.Browser) }
    NavRow(AIcons.Block, "المحظورين", "${AppSettings.now.blocked.size} محظور") { go(Page.Blocked) }
    NavRow(AIcons.Info, "عن التطبيق", "الإصدار وملاحظات التشفير") { go(Page.About) }
    TeamBadge(Modifier.fillMaxWidth().padding(vertical = 28.dp))
}

// ============================================================ الحساب

@Composable
private fun AccountPage(session: SessionVm) {
    val me by session.me.collectAsState()
    var name by remember(me) { mutableStateOf(me?.displayName.orEmpty()) }
    var about by remember(me) { mutableStateOf(me?.about.orEmpty()) }
    var confirmLogout by remember { mutableStateOf(false) }
    var uname by remember(me) { mutableStateOf(me?.username.orEmpty()) }
    var unameMsg by remember { mutableStateOf<String?>(null) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val ctxA = LocalContext.current

    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AccountsSection(me?.id)
        HorizontalDivider()
        OutlinedTextField(uname, { uname = it.lowercase().filter { c -> c.isLetterOrDigit() || c == '_' }.take(20) },
            label = { Text("اليوزر نيم") }, prefix = { Text("@") }, singleLine = true,
            supportingText = { Text(unameMsg ?: "الناس تقدر تدوّر عليك بيه (3–20: a-z و 0-9 و _)") },
            modifier = Modifier.fillMaxWidth())
        OutlinedButton(onClick = { scope.launch { unameMsg = session.saveUsername(uname) ?: "اتحفظ ✅" } },
            enabled = uname != me?.username.orEmpty(), modifier = Modifier.fillMaxWidth()) { Text("حفظ اليوزر نيم") }
        OutlinedTextField(name, { name = it.take(100) }, label = { Text("الاسم") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(about, { about = it.take(500) }, label = { Text("الحالة") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField("+" + me?.phone.orEmpty().removePrefix("+"), {}, label = { Text("رقم الهاتف (مؤكَّد عن طريق تيليجرام)") },
            readOnly = true, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedButton(onClick = { session.saveProfile(name.trim(), about.trim()) }, modifier = Modifier.fillMaxWidth()) { Text("حفظ") }
        me?.let { LinkRow("لينك حسابي (أي حد يفتحه يبدأ معاك محادثة)", com.binarybeast.chatapp.data.Invites.user(it)) }
        HorizontalDivider()
        OutlinedButton(onClick = { confirmLogout = true }, modifier = Modifier.fillMaxWidth()) {
            Text("تسجيل الخروج", color = MaterialTheme.colorScheme.error)
        }
        Text(
            "تسجيل الخروج بيمسح الرسايل المحفوظة على الجهاز ده (مفيش نسخة احتياطية).",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    if (confirmLogout) AlertDialog(
        onDismissRequest = { confirmLogout = false },
        title = { Text("تسجيل الخروج؟") },
        text = { Text("هتتمسح كل الرسايل المحفوظة على الجهاز ده ومش هتقدر ترجّعها.") },
        confirmButton = { TextButton(onClick = { confirmLogout = false; session.signOut(ctxA) }) { Text("خروج ومسح") } },
        dismissButton = { TextButton(onClick = { confirmLogout = false }) { Text("إلغاء") } },
    )
}

// ============================================================ الخصوصية

@Composable
private fun PrivacyPage(go: (Page) -> Unit) {
    val p by AppSettings.prefs.collectAsState()
    var pick by remember { mutableStateOf(false) }
    var pinDialog by remember { mutableStateOf(false) }
    var invPick by remember { mutableStateOf(false) }
    var lockPick by remember { mutableStateOf(false) }
    var wipeAsk by remember { mutableStateOf(false) }
    var discoverable by remember { mutableStateOf(true) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    androidx.compose.runtime.LaunchedEffect(Unit) {
        runCatching { ProfileRepository.me() }.getOrNull()?.let { discoverable = it.discoverable }
    }

    ValueRow("قفل التطبيق (PIN)", if (p.pinHash.isNotEmpty()) "مفعّل" else "معطّل") { pinDialog = true }
    SwitchRow("إظهار آخر ظهور", "لو قفلته، آخر ظهور بيتمسح من بروفايلك", p.lastSeenVisible) {
        AppSettings.update { s -> s.copy(lastSeenVisible = it) }
    }
    ValueRow("مين يقدر يتصل بيا", if (p.whoCanCall == "nobody") "محدش" else "الكل") { pick = true }
    SwitchRow("منع لقطات الشاشة", "بيخفي محتوى التطبيق في الصور وفي قايمة التطبيقات الأخيرة", p.screenSecurity) {
        AppSettings.update { s -> s.copy(screenSecurity = it) }
    }
    SwitchRow("إيصالات القراءة والفتح", "بيبلّغ الطرف التاني إنك قريت رسايله وفتحت ميديا المرة الواحدة. لو قفلته مش هتشوف إيصالاتهم كمان", p.readReceipts) {
        AppSettings.update { s -> s.copy(readReceipts = it) }
    }
    SwitchRow("إظهار «بيكتب…»", "لو قفلته، محدش هيشوفك بتكتب", p.typingVisible) {
        AppSettings.update { s -> s.copy(typingVisible = it) }
    }
    SwitchRow("ممكن حد يلاقيني برقم تليفوني", "لو قفلته، محدش يقدر يضيفك بالرقم؛ بس باليوزر نيم (رقمك مخفي عن الكل في كل الأحوال)", discoverable) {
        discoverable = it
        scope.launch { runCatching { ProfileRepository.setDiscoverable(it) } }
    }
    SwitchRow("تجاهل الغرباء", "رسايل اللي ماليش معاهم محادثة سابقة بتتجاهل ومش بتظهرلك", p.blockUnknown) {
        AppSettings.update { s -> s.copy(blockUnknown = it) }
    }
    ValueRow("مين يضيفني في مجموعات", when (p.groupInvites) { "nobody" -> "محدش"; "contacts" -> "اللي ليا معاهم محادثة"; else -> "الكل" }) { invPick = true }
    ValueRow("القفل التلقائي", when (p.autoLockSec) { 0 -> "فوري"; 15 -> "بعد 15 ثانية"; 60 -> "بعد دقيقة"; else -> "بعد 5 دقايق" }) { lockPick = true }
    SwitchRow("إخفاء آخر رسالة في القايمة", "بتظهر «••••» بدل نص آخر رسالة", p.hideListPreview) {
        AppSettings.update { s -> s.copy(hideListPreview = it) }
    }
    SwitchRow("إخفاء اسم المرسل في الإشعار", "الإشعار بيظهر باسم التطبيق بس", p.hideNotifSender) {
        AppSettings.update { s -> s.copy(hideNotifSender = it) }
    }
    SwitchRow("إخفاء محتوى الإشعارات", "بيظهر «رسالة جديدة» من غير النص", !p.notifPreview) {
        AppSettings.update { s -> s.copy(notifPreview = !it) }
    }
    NavRow(AIcons.Block, "المحظورين", "${p.blocked.size} محظور") { go(Page.Blocked) }
    OutlinedButton(onClick = { wipeAsk = true }, modifier = Modifier.fillMaxWidth().padding(16.dp)) {
        Text("مسح كل الرسايل من الجهاز ده", color = MaterialTheme.colorScheme.error)
    }
    Hint("رقم هاتفك مخفي عن باقي المستخدمين على مستوى الداتابيز. الصور اللي بتتعدّل جوه التطبيق بتتبعت من غير بيانات الموقع (EXIF)، لكن الملفات اللي بتتبعت كـ «ملف» بتتبعت زي ما هي.")
    Hint("الحظر بيتنفّذ على جهازك: رسايل ومكالمات المحظور بتتجاهل والطرف التاني مبيعرفش.")

    if (pinDialog) {
        var newPin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pinDialog = false },
            title = { Text("قفل التطبيق") },
            text = {
                Column {
                    Text("رقم سري 4 إلى 8 أرقام. التطبيق بيتقفل لما تفتحه أو ترجعله بعد 15 ثانية. لو نسيته مفيش استرجاع: هتضطر تمسح بيانات التطبيق من إعدادات النظام.")
                    OutlinedTextField(
                        newPin, { newPin = it.filter(Char::isDigit).take(8) }, singleLine = true,
                        label = { Text("الرقم السري الجديد") },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword),
                    )
                }
            },
            confirmButton = { TextButton(enabled = newPin.length >= 4, onClick = { AppLock.setPin(newPin); pinDialog = false }) { Text("تفعيل") } },
            dismissButton = {
                if (p.pinHash.isNotEmpty()) TextButton(onClick = { AppLock.setPin(null); pinDialog = false }) { Text("إلغاء القفل") }
                else TextButton(onClick = { pinDialog = false }) { Text("إلغاء") }
            },
        )
    }

    if (invPick) ChoiceDialog(
        "مين يضيفني في مجموعات", listOf("everyone" to "الكل", "contacts" to "اللي ليا معاهم محادثة", "nobody" to "محدش"), p.groupInvites,
        { v -> AppSettings.update { s -> s.copy(groupInvites = v) } }, { invPick = false },
    )
    if (lockPick) ChoiceDialog(
        "القفل التلقائي (محتاج PIN)", listOf("0" to "فوري", "15" to "بعد 15 ثانية", "60" to "بعد دقيقة", "300" to "بعد 5 دقايق"), p.autoLockSec.toString(),
        { v -> AppSettings.update { s -> s.copy(autoLockSec = v.toInt()) } }, { lockPick = false },
    )
    if (wipeAsk) AlertDialog(
        onDismissRequest = { wipeAsk = false },
        title = { Text("مسح كل الرسايل؟") },
        text = { Text("هتتمسح كل المحادثات والمجموعات من الجهاز ده ومش هتتسترجع. حسابك هيفضل زي ما هو.") },
        confirmButton = { TextButton(onClick = { wipeAsk = false; scope.launch { com.binarybeast.chatapp.data.ChatEngine.clearAllMessages() } }) { Text("مسح") } },
        dismissButton = { TextButton(onClick = { wipeAsk = false }) { Text("إلغاء") } },
    )
    if (pick) ChoiceDialog(
        "مين يقدر يتصل بيا", listOf("everyone" to "الكل", "nobody" to "محدش"), p.whoCanCall,
        { v -> AppSettings.update { s -> s.copy(whoCanCall = v) } }, { pick = false },
    )
}

// ============================================================ الشات

@Composable
private fun ChatsPage() {
    val p by AppSettings.prefs.collectAsState()
    var theme by remember { mutableStateOf(false) }
    var font by remember { mutableStateOf(false) }
    var accent by remember { mutableStateOf(false) }
    var wall by remember { mutableStateOf(false) }
    var langDlg by remember { mutableStateOf(false) }

    ValueRow("اللغة", if (p.language == "auto") "تلقائي (حسب الجهاز)" else Lang.LANGS.firstOrNull { it.first == p.language }?.second ?: p.language) { langDlg = true }
    ValueRow("لون التطبيق", ACCENTS.firstOrNull { it.first == p.accent }?.second?.first ?: "لون النمط") { accent = true }
    ValueRow("خلفية الشات", when (p.wallpaper) { "aurora" -> "أورورا"; "dots" -> "نقط"; "plain" -> "سادة"; else -> "رسومات" }) { wall = true }
    ValueRow("الثيم", when (p.darkMode) { "dark" -> "داكن"; "light" -> "فاتح"; else -> "زي الجهاز" }) { theme = true }
    ValueRow("حجم الخط", when (p.fontScale) { 0.9f -> "صغير"; 1.15f -> "كبير"; 1.3f -> "كبير جدًا"; else -> "عادي" }) { font = true }
    SwitchRow("زر Enter يبعت الرسالة", "لو مقفول، Enter بينزل سطر جديد", p.enterToSend) {
        AppSettings.update { s -> s.copy(enterToSend = it) }
    }
    if (langDlg) ChoiceDialog(
        "اللغة", listOf("auto" to "تلقائي (حسب الجهاز)") + Lang.LANGS, p.language,
        { v -> AppSettings.update { s -> s.copy(language = v) } }, { langDlg = false },
    )
    if (wall) ChoiceDialog(
        "خلفية الشات", listOf("doodle" to "رسومات (SVG)", "aurora" to "أورورا نيون", "dots" to "نقط", "plain" to "سادة"), p.wallpaper,
        { v -> AppSettings.update { s -> s.copy(wallpaper = v) } }, { wall = false },
    )
    if (accent) ChoiceDialog(
        "لون التطبيق", ACCENTS.map { it.first to it.second.first }, p.accent,
        { v -> AppSettings.update { s -> s.copy(accent = v) } }, { accent = false },
    )
    if (theme) ChoiceDialog(
        "الثيم", listOf("system" to "زي الجهاز", "light" to "فاتح", "dark" to "داكن"), p.darkMode,
        { v -> AppSettings.update { s -> s.copy(darkMode = v) } }, { theme = false },
    )
    if (font) ChoiceDialog(
        "حجم الخط", listOf(0.9f to "صغير", 1f to "عادي", 1.15f to "كبير", 1.3f to "كبير جدًا"), p.fontScale,
        { v -> AppSettings.update { s -> s.copy(fontScale = v) } }, { font = false },
    )
}

// ============================================================ الإشعارات

@Composable
private fun NotificationsPage() {
    val p by AppSettings.prefs.collectAsState()
    val ctx = LocalContext.current
    SwitchRow("إشعارات الرسايل", null, p.notifMessages) { AppSettings.update { s -> s.copy(notifMessages = it) } }
    SwitchRow("أصوات التطبيق", "صوت الإرسال والرد والمنشن داخل التطبيق", p.appSounds) { AppSettings.update { s -> s.copy(appSounds = it) } }
    SwitchRow("ساعات الهدوء", "من غير إشعارات رسايل في الفترة اللي تحددها", p.quietOn) { AppSettings.update { s -> s.copy(quietOn = it) } }
    if (p.quietOn) {
        var qFrom by remember { mutableStateOf(false) }
        var qTo by remember { mutableStateOf(false) }
        val hours = (0..23).map { it.toString() to "%02d:00".format(it) }
        ValueRow("من الساعة", "%02d:00".format(p.quietFrom)) { qFrom = true }
        ValueRow("لحد الساعة", "%02d:00".format(p.quietTo)) { qTo = true }
        if (qFrom) ChoiceDialog("من الساعة", hours, p.quietFrom.toString(), { v -> AppSettings.update { s -> s.copy(quietFrom = v.toInt()) } }, { qFrom = false })
        if (qTo) ChoiceDialog("لحد الساعة", hours, p.quietTo.toString(), { v -> AppSettings.update { s -> s.copy(quietTo = v.toInt()) } }, { qTo = false })
    }
    SwitchRow("معاينة الرسالة في الإشعار", "لو مقفول، الإشعار بيقول «رسالة جديدة» من غير النص", p.notifPreview) {
        AppSettings.update { s -> s.copy(notifPreview = it) }
    }
    SwitchRow("إشعارات المكالمات", "لو مقفول، المكالمة بتظهر بس والتطبيق مفتوح", p.notifCalls) {
        AppSettings.update { s -> s.copy(notifCalls = it) }
    }
    SwitchRow("استقبال في الخلفية (من غير Firebase)", "خدمة صغيرة بتفضل متصلة علشان الرسايل والمكالمات توصل والتطبيق مقفول. بتظهر إشعار صامت.", p.keepAlive) {
        AppSettings.update { s -> s.copy(keepAlive = it) }
        if (it) com.binarybeast.chatapp.KeepAliveService.start(ctx) else com.binarybeast.chatapp.KeepAliveService.stop(ctx)
    }
    ValueRow("البوتات", "بوتاتك + بحث بيوزرنيم البوت (أو @BotMakerBot لإنشاء بوت)") { NavStore.botsOpen = true }
    var showDiag by remember { mutableStateOf(false) }
    ValueRow("حالة الاتصال", "لو الرسايل مش بتوصل، افتحها وصوّرها وابعتها") { showDiag = true }
    if (showDiag) {
        val lines by com.binarybeast.chatapp.data.ChatEngine.diag.collectAsState()
        val scopeD = rememberCoroutineScope()
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showDiag = false },
            title = { Text("حالة الاتصال") },
            text = {
                Column {
                    Text(if (lines.isEmpty()) "مفيش أحداث لسه. دوس «فحص الآن»." else lines.joinToString("\n"))
                    com.binarybeast.chatapp.CrashLog.last()?.let { c ->
                        androidx.compose.material3.Text("\nآخر عطل:\n" + c.take(900), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = { androidx.compose.material3.TextButton(onClick = {
                scopeD.launch {
                    val ce = com.binarybeast.chatapp.data.ChatEngine
                    ce.note("فحص يدوي…")
                    ce.start()
                    ce.drainMailbox()
                    ce.note(if (com.binarybeast.chatapp.data.AuthRepository.currentUserId != null) "الحساب مسجّل ✓" else "مفيش حساب مسجّل!")
                }
            }) { Text("فحص الآن") } },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { showDiag = false }) { Text("إغلاق") } },
        )
    }
    ValueRow("السماح بالعمل في الخلفية", "اختار «بدون قيود» علشان النظام ميقفلش الخدمة") {
        runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
    ValueRow("إعدادات إشعارات النظام", "الصوت والاهتزاز") {
        ctx.startActivity(
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

// ============================================================ التخزين والبيانات

@Composable
private fun StoragePage() {
    val p by AppSettings.prefs.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var quality by remember { mutableStateOf(false) }
    var confirmChats by remember { mutableStateOf(false) }
    var cleared by remember { mutableStateOf(false) }
    var limitPick by remember { mutableStateOf(false) }
    var daysPick by remember { mutableStateOf(false) }

    SwitchRow("توفير البيانات", "بيقفل التحميل التلقائي، وبيخلّي رفع الصور/الفيديو بأقل جودة، والمكالمات بجودة منخفضة", p.dataSaver) {
        AppSettings.update { s ->
            if (it) s.copy(dataSaver = true, autoDownloadImages = false, uploadQuality = "data", lowDataCalls = true)
            else s.copy(dataSaver = false, autoDownloadImages = true, uploadQuality = "standard", lowDataCalls = false)
        }
    }
    SwitchRow("تحميل الصور تلقائيًا", "لو مقفول، الصورة بتتحمّل لما تضغط عليها", p.autoDownloadImages) {
        AppSettings.update { s -> s.copy(autoDownloadImages = it) }
    }
    ValueRow("جودة الصور والفيديو المرفوعة", when (p.uploadQuality) { "data" -> "توفير بيانات"; "high" -> "عالية"; else -> "عادية" }) { quality = true }
    Hint("الميديا مبتتحفظش في المعرض ولا الملفات: بتتحمّل كاش مؤقت جوه التطبيق (زي تيليجرام) وبتتمسح تلقائي، وأصلها على السحابة.")
    ValueRow("أقصى حجم للكاش", if (p.cacheLimitMb < 0) "من غير حد" else if (p.cacheLimitMb >= 1024) "${p.cacheLimitMb / 1024} جيجا" else "${p.cacheLimitMb} ميجا") { limitPick = true }
    ValueRow("مسح الميديا المحمّلة تلقائيًا", if (p.cacheDays == 0) "أبدًا" else "بعد ${p.cacheDays} يوم") { daysPick = true }
    ValueRow("مسح الكاش الآن", if (cleared) "اتمسح ✓" else "المستخدم حاليًا: ${"%.1f".format(com.binarybeast.chatapp.data.TelegramStorage.cacheSize() / 1048576.0)} ميجا") {
        scope.launch {
            coil.Coil.imageLoader(ctx).apply { diskCache?.clear(); memoryCache?.clear() }
            com.binarybeast.chatapp.data.TelegramStorage.clearCache()
            cleared = true
        }
    }
    if (limitPick) ChoiceDialog("أقصى حجم للكاش", listOf(100 to "100 ميجا", 500 to "500 ميجا", 2048 to "2 جيجا", -1 to "من غير حد"), p.cacheLimitMb,
        { v -> AppSettings.update { s -> s.copy(cacheLimitMb = v) }; com.binarybeast.chatapp.data.TelegramStorage.trim() }, { limitPick = false })
    if (daysPick) ChoiceDialog("مسح الميديا بعد", listOf(1 to "يوم", 7 to "7 أيام", 30 to "30 يوم", 0 to "أبدًا"), p.cacheDays,
        { v -> AppSettings.update { s -> s.copy(cacheDays = v) }; com.binarybeast.chatapp.data.TelegramStorage.trim() }, { daysPick = false })
    ValueRow("مسح كل الرسايل من الجهاز", "مش بترجع") { confirmChats = true }

    if (quality) ChoiceDialog(
        "جودة الرفع", listOf("data" to "توفير بيانات", "standard" to "عادية", "high" to "عالية"), p.uploadQuality,
        { v -> AppSettings.update { s -> s.copy(uploadQuality = v) } }, { quality = false },
    )
    if (confirmChats) AlertDialog(
        onDismissRequest = { confirmChats = false },
        title = { Text("مسح كل الرسايل؟") },
        text = { Text("الرسايل محفوظة على الجهاز ده بس، ومفيش نسخة تانية. مش هتقدر ترجّعها.") },
        confirmButton = { TextButton(onClick = { confirmChats = false; scope.launch { ChatEngine.dao.clear() } }) { Text("مسح") } },
        dismissButton = { TextButton(onClick = { confirmChats = false }) { Text("إلغاء") } },
    )
}

// ============================================================ المكالمات

@Composable
private fun CallsPage() {
    val p by AppSettings.prefs.collectAsState()
    SwitchRow("توفير البيانات في المكالمات", "فيديو بدقة 480p و15 إطار بدل 720p و30", p.lowDataCalls) {
        AppSettings.update { s -> s.copy(lowDataCalls = it) }
    }
    SwitchRow("إلغاء الضوضاء", "بيتطبّق على المكالمات الجاية", p.noiseSuppression) {
        AppSettings.update { s -> s.copy(noiseSuppression = it) }
    }
}

// ============================================================ المتصفح

@Composable
private fun BrowserPage() {
    val p by AppSettings.prefs.collectAsState()
    val ctx = LocalContext.current
    var cleared by remember { mutableStateOf(false) }
    SwitchRow("فتح الروابط داخل التطبيق", "لو مقفول، الروابط بتفتح في متصفح الجهاز", p.browserInApp) {
        AppSettings.update { s -> s.copy(browserInApp = it) }
    }
    SwitchRow("وضع الكمبيوتر كافتراضي", "بيطلب نسخة سطح المكتب من المواقع", p.browserDesktop) {
        AppSettings.update { s -> s.copy(browserDesktop = it) }
    }
    ValueRow("مسح بيانات التصفح", if (cleared) "اتمسحت ✓" else "الكوكيز والكاش والتخزين") {
        CookieManager.getInstance().removeAllCookies(null)
        WebStorage.getInstance().deleteAllData()
        runCatching { WebView(ctx).apply { clearCache(true); clearHistory(); destroy() } }
        cleared = true
    }
}

// ============================================================ المحظورين

@Composable
private fun BlockedPage() {
    val p by AppSettings.prefs.collectAsState()
    var profiles by remember { mutableStateOf<List<Profile>>(emptyList()) }
    LaunchedEffect(p.blocked) { profiles = runCatching { ProfileRepository.byIds(p.blocked) }.getOrDefault(emptyList()) }

    if (p.blocked.isEmpty()) Hint("مفيش حد محظور. تقدر تحظر حد من القايمة (⋮) جوه المحادثة.")
    profiles.forEach { u ->
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(u.avatarFileId, u.displayName.ifBlank { u.phone }, 44.dp)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(u.displayName.ifBlank { u.phone }, fontWeight = FontWeight.SemiBold)
                Text(u.username?.let { "@$it" } ?: "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = { AppSettings.unblock(u.id) }) { Text("إلغاء الحظر") }
        }
    }
}

// ============================================================ عن التطبيق

@Composable
private fun AboutPage() {
    ValueRow("الإصدار", "1.0")
    ValueRow("تطوير", "BINARY Beast") { }
    Hint(
        "• الرسايل مشفّرة بين الطرفين (ECDH + AES-GCM) وبتتحفظ على جهازك بس.\n" +
            "• الشات والمكالمات P2P؛ لو الطرف التاني مقفول بتستنى مشفّرة في صندوق مؤقت وتتمسح من السيرفر أول ما توصل.\n" +
            "• التشفير ده مش Signal Protocol: مفيش forward secrecy ولا تحقق من هوية المفاتيح.\n" +
            "• الصور والستوريز مخزّنة على تيليجرام وبتتحمّل عن طريق السيرفر بتاعك."
    )
}

// ============================================================ مكوّنات مشتركة

@Composable
private fun NavRow(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().enterSlideEnd(key = "nav:" + title).pressEffect(PressKind.Dip, role = null, onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().enterFade(key = "sw:" + title).clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title)
            subtitle?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun ValueRow(title: String, value: String, onClick: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().let { if (onClick != null) it.clickable(onClick = onClick) else it }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, Modifier.weight(1f))
        Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun Hint(text: String) {
    Text(text, Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
internal fun <T> ChoiceDialog(title: String, options: List<Pair<T, String>>, current: T, onPick: (T) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                options.forEach { (value, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(value); onDismiss() },
                        verticalAlignment = Alignment.CenterVertically,
                    ) { RadioButton(current == value, { onPick(value); onDismiss() }); Text(label) }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } },
    )
}


// ============================================================ نمط التصميم

@Composable
private fun StylePage() {
    val p by AppSettings.prefs.collectAsState()
    val dark = LocalDark.current
    Text(
        "اختار شكل التطبيق كله: الأزرار والشرايط والفقاعات والألوان. تقدر تغيّره في أي وقت.",
        Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    STYLES.forEach { st ->
        val pal = if (dark) st.dark else st.light
        val sel = p.uiStyle == st.key
        val shape = androidx.compose.foundation.shape.RoundedCornerShape(st.radius.coerceAtMost(26.dp))
        Box(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                .clip(shape)
                .background(pal.bg)
                .border(if (sel) 3.dp else maxOf(st.border, 1.dp), if (sel) pal.accent else pal.line, shape)
                .clickable { AppSettings.update { s -> s.copy(uiStyle = st.key) } }
                .padding(14.dp),
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(st.name, color = pal.text, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text(st.desc, color = pal.textDim, style = MaterialTheme.typography.bodySmall)
                    }
                    if (sel) Box(Modifier.size(26.dp).clip(androidx.compose.foundation.shape.CircleShape).background(pal.accent), contentAlignment = Alignment.Center) {
                        Icon(AIcons.Done, null, Modifier.size(16.dp), tint = pal.onAccent)
                    } else if (st.key == "clay") Text("الافتراضي", color = pal.textDim, style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(10.dp))
                val bs = androidx.compose.foundation.shape.RoundedCornerShape(st.bubbleRadius.coerceAtMost(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.clip(bs).background(pal.bubbleOut).padding(horizontal = 12.dp, vertical = 6.dp)) { Text("أهلا 👋", color = pal.onBubbleOut, style = MaterialTheme.typography.bodySmall) }
                    Box(Modifier.clip(bs).background(pal.bubbleIn).border(1.dp, pal.line.copy(alpha = 0.6f), bs).padding(horizontal = 12.dp, vertical = 6.dp)) { Text("اتفقنا", color = pal.text, style = MaterialTheme.typography.bodySmall) }
                    Box(Modifier.size(34.dp).clip(androidx.compose.foundation.shape.CircleShape).background(pal.accent), contentAlignment = Alignment.Center) {
                        Icon(AIcons.Send, null, Modifier.size(17.dp), tint = pal.onAccent)
                    }
                }
            }
        }
    }
    Text("لون التطبيق", Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 4.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        ACCENTS.forEach { (k, v) ->
            val sel = p.accent == k || (k == "auto" && accentOverride(p.accent) == null)
            Box(
                Modifier.size(44.dp).clip(androidx.compose.foundation.shape.CircleShape)
                    .background(if (k == "auto") MaterialTheme.colorScheme.surfaceVariant else v.second)
                    .border(if (sel) 3.dp else 1.dp, if (sel) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline, androidx.compose.foundation.shape.CircleShape)
                    .clickable { AppSettings.update { s -> s.copy(accent = k) } },
                contentAlignment = Alignment.Center,
            ) { if (k == "auto") Text("A", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold) }
        }
    }
}


@Composable
private fun SpacePage(session: SessionVm) {
    val SS = com.binarybeast.chatapp.data.SpaceStore
    var tick by remember { mutableStateOf(0) }
    val spaces = remember(tick) { SS.list() }
    var adding by remember { mutableStateOf(false) }
    var changing by remember { mutableStateOf<String?>(null) }
    var removing by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<String?>(null) }
    fun publish() { session.setSettings(SS.publishPatch()); tick++ }

    Text(
        "مساحات مخفية بالكامل (لحد ${SS.MAX}): مبتظهرش في قايمة الشات ولا في البحث العادي. كل مساحة ليها رقم سري مختلف، ولما تكتبه في البحث بتفتحلك المساحة دي بس. " +
            "أي حد يعرف الرقم ويدوّر عليه يقدر يبعتلك رسالة، وإنت بس اللي بتشوفها. الإشعار بيبقى «وصلك رسالة مهمة» من غير اسم ولا محتوى، " +
            "ولقطات الشاشة وتسجيلها ممنوعين جوه المساحة.",
        Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    spaces.forEach { sp ->
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
            Text("🔒 " + com.binarybeast.chatapp.ui.Lang.raw(sp.name), fontWeight = FontWeight.SemiBold)
            Row {
                TextButton(onClick = { renaming = sp.id }) { Text("تسمية") }
                TextButton(onClick = { changing = sp.id }) { Text("تغيير الرقم") }
                TextButton(onClick = { removing = sp.id }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            }
        }
        HorizontalDivider()
    }
    if (spaces.size < SS.MAX) Button(onClick = { adding = true }, Modifier.padding(16.dp)) {
        Text(if (spaces.isEmpty()) "تفعيل المساحة الخاصة" else "➕ مساحة جديدة")
    }
    Hint("الرقم السري من ${SS.MIN_NEW} لـ 15 رقم، عشوائي ومش متسلسل ولا متكرر. الرقم نفسه مبيتخزّنش في أي مكان: على جهازك بصمة PBKDF2-SHA256 بملح عشوائي ومتشفّرة بمفتاح الجهاز.")
    Hint("تغيير الرقم أو حذف المساحة بيطلبوا الرقم الحالي. لو حذفت مساحة، محادثاتها اللي نقلتها بترجع للشات، ومحادثات الرقم السري بتفضل على جهازك مخفية.")
    Hint("تنبيه صريح: بصمة منشورة في بروفايلك (من غير الرقم) علشان الناس توصلك. أي حد ياخد البصمة دي ممكن يجرّب يخمّن الرقم، فكل ما الرقم أطول وأعشوائي كل ما كان أأمن.")

    var f1 by remember { mutableStateOf("") }
    var f2 by remember { mutableStateOf("") }
    var f3 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val kb = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword)
    val pw = androidx.compose.ui.text.input.PasswordVisualTransformation()
    fun reset() { f1 = ""; f2 = ""; f3 = ""; err = null }
    val scopeS = androidx.compose.runtime.rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    if (adding) androidx.compose.material3.AlertDialog(
        onDismissRequest = { adding = false; reset() },
        title = { Text("مساحة جديدة") },
        text = { Column {
            OutlinedTextField(f1, { f1 = it.take(30) }, label = { Text("اسم المساحة (يظهر ليك بس)") }, singleLine = true)
            OutlinedTextField(f2, { f2 = it.filter(Char::isDigit).take(15); err = null }, label = { Text("الرقم السري (${SS.MIN_NEW}–15 رقم)") }, singleLine = true, keyboardOptions = kb, visualTransformation = pw)
            OutlinedTextField(f3, { f3 = it.filter(Char::isDigit).take(15); err = null }, label = { Text("أعد كتابة الرقم") }, singleLine = true, keyboardOptions = kb, visualTransformation = pw)
            err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        } },
        confirmButton = { TextButton(enabled = !busy, onClick = {
            if (f2 != f3) { err = "الرقمين مش زي بعض"; return@TextButton }
            busy = true
            scopeS.launch {
                val e = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { SS.add(f1, f2) }
                busy = false
                if (e != null) err = e else { adding = false; reset(); publish() }
            }
        }) { Text(if (busy) "…" else "تفعيل") } },
        dismissButton = { TextButton(onClick = { adding = false; reset() }) { Text("إلغاء") } },
    )
    changing?.let { id -> androidx.compose.material3.AlertDialog(
        onDismissRequest = { changing = null; reset() },
        title = { Text("تغيير الرقم السري") },
        text = { Column {
            OutlinedTextField(f1, { f1 = it.filter(Char::isDigit).take(15); err = null }, label = { Text("الرقم الحالي") }, singleLine = true, keyboardOptions = kb, visualTransformation = pw)
            OutlinedTextField(f2, { f2 = it.filter(Char::isDigit).take(15); err = null }, label = { Text("الرقم الجديد (${SS.MIN_NEW}–15 رقم)") }, singleLine = true, keyboardOptions = kb, visualTransformation = pw)
            OutlinedTextField(f3, { f3 = it.filter(Char::isDigit).take(15); err = null }, label = { Text("أعد كتابة الجديد") }, singleLine = true, keyboardOptions = kb, visualTransformation = pw)
            err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        } },
        confirmButton = { TextButton(enabled = !busy, onClick = {
            if (f2 != f3) { err = "الرقمين الجدد مش زي بعض"; return@TextButton }
            busy = true
            scopeS.launch {
                val e = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { SS.change(id, f1, f2) }
                busy = false
                if (e != null) err = e else { changing = null; reset(); publish() }
            }
        }) { Text(if (busy) "…" else "تغيير") } },
        dismissButton = { TextButton(onClick = { changing = null; reset() }) { Text("إلغاء") } },
    ) }
    removing?.let { id -> androidx.compose.material3.AlertDialog(
        onDismissRequest = { removing = null; reset() },
        title = { Text("حذف المساحة؟") },
        text = { Column {
            Text("اكتب الرقم السري للمساحة علشان تأكّد.")
            OutlinedTextField(f1, { f1 = it.filter(Char::isDigit).take(15); err = null }, label = { Text("الرقم السري") }, singleLine = true, keyboardOptions = kb, visualTransformation = pw)
            err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        } },
        confirmButton = { TextButton(enabled = !busy, onClick = {
            busy = true
            scopeS.launch {
                val e = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { SS.remove(id, f1) }
                busy = false
                if (e != null) err = e else { removing = null; reset(); publish(); NavStore.spaceOpen = false }
            }
        }) { Text(if (busy) "…" else "حذف", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = { removing = null; reset() }) { Text("إلغاء") } },
    ) }
    renaming?.let { id -> androidx.compose.material3.AlertDialog(
        onDismissRequest = { renaming = null; reset() },
        title = { Text("اسم المساحة") },
        text = { OutlinedTextField(f1, { f1 = it.take(30) }, singleLine = true, label = { Text("الاسم الجديد") }) },
        confirmButton = { TextButton(onClick = { SS.rename(id, f1); renaming = null; reset(); tick++ }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = { renaming = null; reset() }) { Text("إلغاء") } },
    ) }
}


@Composable
private fun StarredPage() {
    var rows by remember { mutableStateOf<List<com.binarybeast.chatapp.data.local.LocalMessage>>(emptyList()) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    androidx.compose.runtime.LaunchedEffect(Unit) { rows = runCatching { com.binarybeast.chatapp.data.ChatEngine.dao.starredAll() }.getOrDefault(emptyList()) }
    if (rows.isEmpty()) Text("مفيش رسايل مميّزة لسه. اضغط ضغطة طويلة على أي رسالة واختار «نجمة».", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    val f = remember { java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()) }
    rows.forEach { m ->
        Column(
            Modifier.fillMaxWidth().clickable {
                scope.launch { com.binarybeast.chatapp.data.ChatEngine.peerProfile(m.peerId)?.let { NavStore.peer = it } }
            }.padding(horizontal = 16.dp, vertical = 10.dp),
        ) {
            Text(f.format(java.util.Date(m.createdAt)) + (if (m.mine) " · أنا" else ""), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            Text(m.previewText(), maxLines = 3)
        }
        HorizontalDivider()
    }
}


/** الحسابات المحفوظة على الجهاز: تبديل / إضافة / نسيان. */
@Composable
private fun AccountsSection(myId: String?) {
    val ctx = LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var tick by remember { mutableStateOf(0) }
    val accts = remember(tick, myId) { com.binarybeast.chatapp.data.Accounts.list() }
    var confirmSwitch by remember { mutableStateOf<com.binarybeast.chatapp.data.Accounts.Acct?>(null) }
    var confirmForget by remember { mutableStateOf<com.binarybeast.chatapp.data.Accounts.Acct?>(null) }
    var confirmAdd by remember { mutableStateOf(false) }
    Text("الحسابات", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
    accts.forEach { a ->
        val cur = a.id == myId
        Row(
            Modifier.fillMaxWidth().clickable(enabled = !cur) { confirmSwitch = a }.padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(Lang.raw(a.name.ifBlank { "حساب" }) + if (cur) "  ✓" else "", fontWeight = FontWeight.SemiBold)
                if (a.phone.isNotBlank()) Text("+" + a.phone.removePrefix("+"), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (!cur) TextButton(onClick = { confirmForget = a }) { Text("نسيان", color = MaterialTheme.colorScheme.error) }
        }
    }
    OutlinedButton(onClick = { confirmAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("➕ إضافة حساب") }
    Text(
        "كل حساب ليه رسايله ومفاتيحه وستيكراته لوحده. الرسايل بتوصل للحساب اللي شغّال دلوقتي، والحسابات التانية بتستلم اللي فاتها أول ما تبدّل لها.",
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    confirmSwitch?.let { a ->
        AlertDialog(
            onDismissRequest = { confirmSwitch = null },
            title = { Text("التبديل للحساب ده؟") },
            text = { Text("التطبيق هيتقفل ويفتح تاني على الحساب اللي اخترته.") },
            confirmButton = { TextButton(onClick = { confirmSwitch = null; scope.launch { com.binarybeast.chatapp.data.Accounts.switchTo(a, ctx) } }) { Text("تبديل") } },
            dismissButton = { TextButton(onClick = { confirmSwitch = null }) { Text("إلغاء") } },
        )
    }
    confirmForget?.let { a ->
        AlertDialog(
            onDismissRequest = { confirmForget = null },
            title = { Text("نسيان الحساب؟") },
            text = { Text("هيتمسح الحساب ورسايله من الجهاز ده بس. تقدر تدخله تاني بأي وقت.") },
            confirmButton = { TextButton(onClick = { confirmForget = null; scope.launch { com.binarybeast.chatapp.data.Accounts.removeAndSwitch(a.id, ctx); tick++ } }) { Text("نسيان", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmForget = null }) { Text("إلغاء") } },
        )
    }
    if (confirmAdd) AlertDialog(
        onDismissRequest = { confirmAdd = false },
        title = { Text("إضافة حساب جديد") },
        text = { Text("هتدخل برقم تاني عن طريق تيليجرام. حسابك الحالي هيفضل محفوظ وتقدر ترجعله من نفس المكان.") },
        confirmButton = { TextButton(onClick = { confirmAdd = false; scope.launch { com.binarybeast.chatapp.data.Accounts.beginAdd(ctx) } }) { Text("متابعة") } },
        dismissButton = { TextButton(onClick = { confirmAdd = false }) { Text("إلغاء") } },
    )
}
