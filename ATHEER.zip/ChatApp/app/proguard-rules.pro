# WebRTC
-keep class org.webrtc.** { *; }
# kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**

# --- R8 rules (الكود لسه متبنّاش فعليًا؛ لو ظهر crash/خطأ R8 ابعتلي الصورة) ---
-dontwarn **
-keep class kotlinx.serialization.** { *; }
-keepclassmembers class **$$serializer { *; }
-keepclasseswithmembers class com.binarybeast.chatapp.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.binarybeast.chatapp.**$$serializer { *; }
-keepclassmembers class com.binarybeast.chatapp.** { *** Companion; }
-keep @kotlinx.serialization.Serializable class * { *; }
-keep class io.github.jan.supabase.** { *; }
-keep class io.ktor.** { *; }
-keep class com.google.mlkit.** { *; }
-keep class com.google.android.gms.internal.mlkit_** { *; }
-keep class androidx.room.** { *; }
-keep class * extends androidx.room.RoomDatabase
-keep class com.binarybeast.chatapp.data.local.** { *; }
-keep class com.binarybeast.chatapp.data.** { *; }
