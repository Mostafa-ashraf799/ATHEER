# بوتات ATHEER 🐝

Bot API متوافق مع تيليجرام. كل مكتبات تيليجرام بتشتغل بتغيير الـ base URL بس.

- **Base URL:** `https://<PROJECT>.supabase.co/functions/v1/bot-api/bot`  (التوكن بيتحط بعده زي تيليجرام)
- **إنشاء بوت:** من التطبيق: الشات ← «البوتات» ← «إنشاء بوت» (زي BotFather). اليوزرنيم لازم يخلص بـ `bot`. التوكن بيظهر مرة واحدة.
- **البوت المدمج:** `@QwenBot` («Qwen Bot» ملكة النحل 🐝👑). الردود الذكية محتاجة سر `QWEN_API_KEY` في Supabase (Edge Functions → Secrets). من غيره البوت بيشتغل بس بيقول إن الذكاء الاصطناعي مش متفعّل.

## الدوال المدعومة
`getMe` `getUpdates` (long polling حتى 25 ثانية) `setWebhook` `deleteWebhook` `getWebhookInfo` `sendMessage` `sendPhoto` (رابط https) `editMessageText` `editMessageCaption` `editMessageReplyMarkup` `deleteMessage` `answerCallbackQuery` `setMyCommands` `getMyCommands` `deleteMyCommands` `setMyName` `setMyDescription` `getChat` `getChatMember` `sendChatAction`

- `reply_markup`: `inline_keyboard` (callback_data / url) و `keyboard` (reply keyboard) و `remove_keyboard`.
- `parse_mode`: HTML و MarkdownV2 (تنسيق: عريض/مائل/تحته خط/مشطوب/كود/روابط).
- التحديثات: `message` و `callback_query` و `my_chat_member` (لما البوت يتضاف لقناة).
- الـ webhook لازم يكون https على دومين عام (مفيش IP ولا localhost).

## مش مدعوم (لسه)
رفع ملفات/صور من جهازك (sendPhoto بروابط https بس)، inline mode، المجموعات (المجموعات مشفّرة end-to-end على الأجهزة، فالبوت مينفعش يقراها)، payments.

## أمثلة
**python-telegram-bot**
```python
from telegram.ext import Application, CommandHandler, CallbackQueryHandler
from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as M

async def start(update, ctx):
    await update.message.reply_text("أهلاً 🐝", reply_markup=M([[B("اضغط", callback_data="hi")]]))
async def cb(update, ctx):
    await update.callback_query.answer("وصلت!")
    await update.callback_query.edit_message_text("اتضغط ✅")

app = (Application.builder().token("<TOKEN>")
       .base_url("https://<PROJECT>.supabase.co/functions/v1/bot-api/bot").build())
app.add_handler(CommandHandler("start", start)); app.add_handler(CallbackQueryHandler(cb))
app.run_polling()
```
**aiogram 3**
```python
from aiogram import Bot, Dispatcher
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.client.telegram import TelegramAPIServer
session = AiohttpSession(api=TelegramAPIServer(base="https://<PROJECT>.supabase.co/functions/v1/bot-api/bot{token}/{method}",
                                              file="https://<PROJECT>.supabase.co/functions/v1/bot-api/file/bot{token}/{path}"))
bot = Bot("<TOKEN>", session=session)
```
**pyTelegramBotAPI**
```python
import telebot
telebot.apihelper.API_URL = "https://<PROJECT>.supabase.co/functions/v1/bot-api/bot{0}/{1}"
bot = telebot.TeleBot("<TOKEN>")
```

## الخصوصية
محادثات البوت بتعدّي على السيرفر (البوت لازم يقرأ الرسالة) فهي **مش end-to-end** زي الشات العادي. Qwen Bot بيبعت نص رسايلك لخدمة الذكاء الاصطناعي علشان يرد (بس رسايلك له هو، مش أي شات تاني).

---

## BotMaker (زي BotFather) — المرحلة التانية

ابحث باليوزرنيم عن **@BotMakerBot** واكتب `/help`. الأوامر:

| المجموعة | الأوامر |
|---|---|
| بوتات | `/newbot` `/mybots` `/token` `/revoke` `/deletebot` |
| تعديل | `/setname` `/setdescription` `/setabouttext` `/setuserpic` (رابط https) `/setcommands` |
| إعدادات | `/setinline` `/setinlinegeo` `/setinlinefeedback` (بتتحفظ بس — inline queries مش مدعومة) `/setjoingroups` `/setprivacy` |
| Web Apps | `/myapps` `/newapp` `/listapps` `/editapp` `/deleteapp` |
| Games | `/mygames` `/newgame` `/listgames` `/editgame` `/deletegame` |

- الـ Web App بيتبعت بزرار `web_app: {url}` والـ Game بـ `sendGame` (بيتحوّلوا لزرار رابط بيفتح في المتصفح الداخلي).
- التوكن متولّد بـ HMAC من مفتاح سيرفر (`app_settings.bot_token_key`) — `/token` بيرجّع نفس التوكن و`/revoke` بيغيّره.

## البوتات مخفية
مفيش قايمة بوتات. البوت بيظهر بس لو بحثت باليوزرنيم بالظبط (RPC `find_bot`)، أو لو بدأت معاه محادثة (بيظهر في قايمة الشات). ده بينطبق على **Qwen Bot** كمان.

## بوتات المجموعات
من قايمة المجموعة ⋮ ← «🤖 بوتات المجموعة» ابحث باليوزرنيم وضيف. البوت (زي تيليجرام مع Privacy Mode):
- مفعّل الخصوصية (الافتراضي): بيشوف الأوامر `/cmd` والإشارات `@bot` والردود على رسايله بس.
- متعطّل: بيشوف كل رسايل المجموعة اللي جهازك بيبعتها له.
- رسايل المجموعة العادية بتفضل E2E؛ بس الرسايل المؤهّلة للبوت بتتبعت للسيرفر.
- chat_id المجموعة في Bot API = `-chat_num` (بيبدأ من 3000000000001).
- حدّ معروف: المجموعات مفيهاش سيرفر مركزي فمفيش تحقق إن اللي بيضيف البوت عضو فعلاً.

## مفتاح Qwen من جوه التطبيق (للأدمن)
في شات Qwen Bot: `/qwenkey المفتاح` (رسالة المفتاح بتتمسح فورًا) — `/qwenmodel` — `/qwenbase` — `/qwenstatus`. بتتخزن في `app_settings` (RLS من غير policies = service role بس). الأدمن = صف في جدول `app_admins`:
```sql
insert into app_admins(user_id) select id from profiles where display_name = 'اسم الشخص';
```
