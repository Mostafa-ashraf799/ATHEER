#!/usr/bin/env python3
"""
Professional app UI sound set - deterministic synthesis.
Same "sonic brand" engine across all four sounds: warm additive/FM core,
fast attack, exponential decay, click-free edges.

  1. Aurora Ring   - incoming call ringtone (12s, seamless loop)
  2. Nimbus Notify - new message notification (~0.95s)
  3. Swift Send    - message sent confirmation (~0.32s)
  4. Vivid Mention - @mention alert (~0.75s)
"""
import math
import struct
import wave
from array import array

SR = 44100
OUT = "/workspace/app_sounds"


# ---------------------------------------------------------------- utilities
def buf(dur):
    return array("d", [0.0]) * int(round(dur * SR))


def env_exp(n, tau, attack=0.004, curve=1.0):
    """Fast linear attack then exponential decay - click-free."""
    a = max(1, int(attack * SR))
    out = array("d", [0.0]) * n
    for i in range(n):
        t = i / SR
        e = math.exp(-t / tau)
        at = i / a if i < a else 1.0
        out[i] = e * at
    if curve != 1.0:
        out = array("d", [v ** curve for v in out])
    return out


def env_ad(n, atk, dec, sus_lvl, rel):
    a = max(1, int(atk * SR))
    d = max(1, int(dec * SR))
    r = max(1, int(rel * SR))
    s = max(0, n - a - d - r)
    out = array("d", [0.0]) * n
    i = 0
    for k in range(min(a, n)):
        out[i] = k / a
        i += 1
    for k in range(min(d, n - i)):
        out[i] = 1.0 + (sus_lvl - 1.0) * (k / d)
        i += 1
    for _ in range(min(s, n - i)):
        out[i] = sus_lvl
        i += 1
    rem = n - i
    if rem > 0:
        for k in range(rem):
            out[i] = sus_lvl * (1.0 - k / rem) ** 1.6
            i += 1
    return out


def onepole_lp(x, cutoff):
    """One-pole lowpass. cutoff in Hz."""
    a = math.exp(-2.0 * math.pi * cutoff / SR)
    y = array("d", [0.0]) * len(x)
    z = 0.0
    for i in range(len(x)):
        z = (1.0 - a) * x[i] + a * z
        y[i] = z
    return y


def onepole_hp(x, cutoff):
    lp = onepole_lp(x, cutoff)
    return array("d", [x[i] - lp[i] for i in range(len(x))])


def add(dst, src, offset=0.0, gain=1.0, pan=0.0):
    """Mix mono src into stereo dst. pan -1 hard left .. +1 hard right."""
    off = int(offset * SR)
    n = len(src)
    if off >= len(dst[0]):
        return
    n = min(n, len(dst[0]) - off)
    gl = gain * math.sqrt(max(0.0, (1.0 - pan) * 0.5)) * math.sqrt(2.0)
    gr = gain * math.sqrt(max(0.0, (1.0 + pan) * 0.5)) * math.sqrt(2.0)
    L, R = dst
    for i in range(n):
        v = src[i]
        L[off + i] += v * gl
        R[off + i] += v * gr


def write_wav(name, stereo, peak=0.89):
    L, R = stereo
    n = len(L)
    m = max(1e-12, max(max(abs(v) for v in L), max(abs(v) for v in R)))
    g = peak / m
    frames = bytearray()
    for i in range(n):
        a = int(max(-1.0, min(1.0, L[i] * g)) * 32767)
        b = int(max(-1.0, min(1.0, R[i] * g)) * 32767)
        frames += struct.pack("<hh", a, b)
    path = f"{OUT}/{name}"
    w = wave.open(path, "wb")
    w.setnchannels(2)
    w.setsampwidth(2)
    w.setframerate(SR)
    w.writeframes(bytes(frames))
    w.close()
    print(f"  wrote {name:20s} {n / SR:6.3f}s  peak {peak:.2f} dBFS")
    return path


def st(mono):
    return (array("d", mono), array("d", mono))


def fade_edges(mono, ms=4.0):
    n = int(ms / 1000.0 * SR)
    n = min(n, len(mono) // 2)
    for i in range(n):
        g = i / n
        mono[i] *= g
        mono[len(mono) - 1 - i] *= g
    return mono


def semi(base_hz, n):
    return base_hz * (2.0 ** (n / 12.0))


# ------------------------------------------------------- voice: FM bell core
def bell(freq, dur, tau=0.42, ratio=2.01, index=2.4, gain=1.0):
    """Crisp digital FM bell with inharmonic shimmer."""
    n = int(dur * SR)
    out = array("d", [0.0]) * n
    w = 2.0 * math.pi * freq / SR
    phase = 0.0
    for i in range(n):
        t = i / SR
        e = math.exp(-t / tau)
        mod = math.sin(w * ratio * i) * index * e
        out[i] = math.sin(w * i + mod) * e
    return array("d", [v * gain for v in out])


# --------------------------------------------------- voice: pluck / marimba
def pluck(freq, dur, gain=1.0, bright=1.0, detune=0.0):
    """Warm digital pluck (marimba-ish) with per-partial decay."""
    n = int(dur * SR)
    out = array("d", [0.0]) * n
    w = 2.0 * math.pi * freq / SR
    wd = 2.0 * math.pi * (freq * (1.0 + detune)) / SR
    partials = [(1.0, 1.00, 0.62), (2.0, 0.34, 0.38), (3.01, 0.17, 0.26),
                (4.18, 0.09, 0.18), (6.27, 0.045 * bright, 0.12)]
    for i in range(n):
        t = i / SR
        s = 0.0
        for r, amp, dec in partials:
            s += amp * math.exp(-t / (dec * 0.9)) * math.sin(r * w * i)
        s += 0.30 * math.exp(-t / 0.5) * math.sin(wd * i)
        out[i] = s * math.exp(-t / 0.70)
    lp = onepole_lp(out, 5200 + 4500 * bright)
    return array("d", [lp[i] * gain for i in range(n)])


# --------------------------------------------------------------- voice: pad
def pad(freqs, dur, gain=1.0, attack=0.35, cutoff=1500.0):
    n = int(dur * SR)
    acc = array("d", [0.0]) * n
    for f in freqs:
        for d in (-0.30, 0.0, 0.32):  # detuned stack -> width
            w = 2.0 * math.pi * (f * (1.0 + d / 100.0)) / SR
            for i in range(n):
                # mild saw-ish via limited sum of first 3 harmonics
                v = math.sin(w * i) + 0.30 * math.sin(2 * w * i) + 0.12 * math.sin(3 * w * i)
                acc[i] += v / (len(freqs) * 3.0)
    e = env_ad(n, attack, 0.4, 0.75, 0.5)
    acc = onepole_lp(acc, cutoff)
    return array("d", [acc[i] * e[i] * gain for i in range(n)])


# ======================================================================
# 3. SWIFT SEND  (message sent) - ~0.32s
# ======================================================================
def make_swift_send():
    dur = 0.32
    out = [buf(dur), buf(dur)]

    # rising sine "pop": 620 Hz -> 1240 Hz, fast
    n = int(0.16 * SR)
    body = array("d", [0.0]) * n
    f0, f1 = 620.0, 1240.0
    ph = 0.0
    for i in range(n):
        t = i / SR
        k = min(1.0, t / 0.055)
        f = f0 + (f1 - f0) * (k * k * (3 - 2 * k))
        ph += 2.0 * math.pi * f / SR
        body[i] = math.sin(ph) * math.exp(-t / 0.055)
    body = onepole_lp(body, 7000)
    add(out, body, 0.0, 0.85)

    # soft harmonic top for presence
    top = array("d", [v * 0.22 * math.exp(-(i / SR) / 0.035) for i, v in enumerate(body)])
    top = onepole_hp(top, 2000)
    add(out, top, 0.0, 0.9)

    # tiny airy click transient
    cn = int(0.012 * SR)
    click = array("d", [math.exp(-(i / SR) / 0.0022) for i in range(cn)])
    click = onepole_hp(click, 3500)
    add(out, click, 0.0, 0.28)

    # gentle body resonance settle
    sub = array("d", [math.sin(2.0 * math.pi * 310.0 * i / SR) *
                      math.exp(-(i / SR) / 0.045) for i in range(int(0.14 * SR))])
    add(out, sub, 0.0, 0.16)

    L, R = out
    return fade_edges(L, 2), fade_edges(R, 2)


# ======================================================================
# 2. NIMBUS NOTIFY  (new message) - ~0.95s
# ======================================================================
def make_nimbus_notify():
    dur = 0.95
    out = [buf(dur), buf(dur)]
    e6, b6 = 1318.51, 1975.53

    add(out, bell(e6, 0.85, tau=0.40, ratio=2.01, index=2.2, gain=0.80), 0.000, 1.0, -0.12)
    add(out, bell(b6, 0.80, tau=0.34, ratio=3.02, index=1.5, gain=0.62), 0.165, 1.0, 0.12)
    # tiny low anchor for body
    anchor = array("d", [math.sin(2.0 * math.pi * 329.63 * i / SR) *
                         math.exp(-(i / SR) / 0.20) for i in range(int(0.45 * SR))])
    add(out, anchor, 0.0, 0.13, 0.0)

    L, R = out
    L = onepole_hp(L, 140)
    R = onepole_hp(R, 140)
    return fade_edges(L, 3), fade_edges(R, 3)


# ======================================================================
# 5. ECHO REPLY  (someone replied to you) - ~0.62s
# ======================================================================
def make_echo_reply():
    """Warm mid-register 'someone replied' chirp. Pluck family, so it reads
    as a friendly follow-up rather than an alert."""
    dur = 0.62
    out = [buf(dur), buf(dur)]
    A4 = 440.0

    # D5 -> A5, gentle upward pair (warm marimba plucks, not bells)
    add(out, pluck(semi(A4, 5), 0.40, gain=0.70, bright=0.80, detune=0.004),
        0.000, 1.0, -0.16)
    add(out, pluck(semi(A4, 12), 0.48, gain=0.66, bright=0.95, detune=0.004),
        0.105, 1.0, 0.16)
    # octave shimmer on the second note
    add(out, pluck(semi(A4, 24), 0.26, gain=0.13, bright=1.35),
        0.105, 1.0, 0.16)
    # soft low body so it has weight on phone speakers
    add(out, pluck(semi(A4, -12), 0.34, gain=0.22, bright=0.30),
        0.000, 1.0, 0.0)

    L, R = out
    L = onepole_hp(L, 120)
    R = onepole_hp(R, 120)
    return fade_edges(L, 3), fade_edges(R, 3)


# ======================================================================
# 4. VIVID MENTION  (@mention) - ~0.75s
# ======================================================================
def make_vivid_mention():
    dur = 0.75
    out = [buf(dur), buf(dur)]

    def tri(freq, dur_s, tau, gain, ratio=1.0):
        n = int(dur_s * SR)
        w = 2.0 * math.pi * freq / SR
        o = array("d", [0.0]) * n
        for i in range(n):
            t = i / SR
            x = (w * i) % (2.0 * math.pi)
            tri_w = 2.0 / math.pi * math.asin(max(-1.0, min(1.0, math.sin(x))))
            o[i] = tri_w * math.exp(-t / tau)
        return array("d", [v * gain for v in o])

    # two quick sparkle blips, clearly brighter than the notification
    add(out, tri(semi(440.0, 28), 0.34, 0.085, 0.85), 0.000, 1.0, -0.18)
    add(out, tri(semi(440.0, 33), 0.36, 0.105, 0.80), 0.100, 1.0, 0.18)
    # shimmer top-octave
    add(out, tri(semi(440.0, 40), 0.30, 0.070, 0.22), 0.100, 1.0, 0.18)
    add(out, tri(semi(440.0, 35), 0.28, 0.060, 0.18), 0.000, 1.0, -0.18)
    # soft thump for weight
    thump = array("d", [math.sin(2.0 * math.pi * 196.0 * i / SR) *
                        math.exp(-(i / SR) / 0.055) for i in range(int(0.2 * SR))])
    add(out, thump, 0.0, 0.18)

    L, R = out
    L = onepole_hp(L, 200)
    R = onepole_hp(R, 200)
    return fade_edges(L, 3), fade_edges(R, 3)


# ======================================================================
# 1. AURORA RING  (incoming call ringtone) - 12s seamless loop
# ======================================================================
def make_aurora_ring():
    beats = 0.25                     # 120 BPM eighth notes
    cycles = 6
    total = beats * 8 * cycles      # 12.0 s
    out = [buf(total + 1.0), buf(total + 1.0)]

    A4 = 440.0
    # motif: A5 E5 F#5 C#6 | A5 E5 G#5 E5   (8 eighth-note slots)
    motif = [(0, 12), (1, 7), (2, 9), (3, 16), (4, 12), (5, 7), (6, 11), (7, 7)]
    accents = [1.0, 0.62, 0.66, 0.86, 0.92, 0.58, 0.70, 0.58]

    for c in range(cycles):
        t0 = c * beats * 8
        for (slot, sn), acc in zip(motif, accents):
            f = semi(A4, sn)
            pan = -0.28 if slot % 2 == 0 else 0.28
            dur = 0.62 if acc > 0.8 else 0.42
            v = pluck(f, dur, gain=0.40 * acc, bright=1.0 if acc > 0.7 else 0.75,
                      detune=0.004)
            add(out, v, t0 + slot * beats, 1.0, pan)
            # octave sparkle on strong beats
            if acc > 0.85:
                v2 = pluck(semi(A4, sn + 12), 0.34, gain=0.10 * acc, bright=1.4)
                add(out, v2, t0 + slot * beats, 1.0, -pan * 0.7)

        # bass: A2 / E2
        add(out, pluck(semi(A4, -24), 0.70, gain=0.26, bright=0.35, detune=-0.003),
            t0 + 0.0, 1.0, 0.0)
        add(out, pluck(semi(A4, -29), 0.70, gain=0.22, bright=0.30, detune=-0.003),
            t0 + 4 * beats, 1.0, 0.0)
        # off-bass push before the second half
        add(out, pluck(semi(A4, -22), 0.40, gain=0.13, bright=0.4),
            t0 + 6 * beats, 1.0, 0.22)

        # warm pad chord per 2s cycle
        p = pad([A4 * 0.5, A4 * 0.5 * (2 ** (4 / 12)), A4 * 0.5 * (2 ** (7 / 12))],
                beats * 8 + 0.3, gain=0.15, attack=0.30, cutoff=1250.0)
        add(out, p, t0, 1.0, 0.0)

    # final downbeat so the loop's last cycle doesn't tail off
    add(out, pluck(semi(A4, 12), 0.75, gain=0.40, bright=1.0), total - beats * 8 + 0.0,
        1.0, 0.0)

    L, R = out
    # trim to exactly 12.0s and kill the loop seam click with a short tail fade
    n = int(total * SR)
    L = L[:n]
    R = R[:n]
    tn = int(0.015 * SR)          # 15ms - inaudible, removes the seam click
    for i in range(tn):
        g = (i + 1) / tn            # last sample -> ~0, tn samples back -> 1.0
        L[n - 1 - i] *= g
        R[n - 1 - i] *= g
    return L, R


# ======================================================================
if __name__ == "__main__":
    print("Synthesizing professional app sound set ...")
    write_wav("aurora_ring.wav", make_aurora_ring(), peak=0.80)
    write_wav("nimbus_notify.wav", make_nimbus_notify(), peak=0.89)
    write_wav("swift_send.wav", make_swift_send(), peak=0.89)
    write_wav("vivid_mention.wav", make_vivid_mention(), peak=0.89)
    write_wav("echo_reply.wav", make_echo_reply(), peak=0.89)
    print("done.")
