-- جهات الاتصال المحفوظة: (1) استعادتها بعد مسح التطبيق (الشات نفسه لا) (2) شرط ظهور الستوري: صاحبها لازم يكون حافظ المشاهد.
create table if not exists public.contacts (
  owner uuid not null references auth.users(id) on delete cascade,
  contact uuid not null references auth.users(id) on delete cascade,
  backup boolean not null default true,
  created_at timestamptz not null default now(),
  primary key (owner, contact),
  check (owner <> contact)
);
alter table public.contacts enable row level security;
create policy contacts_select_own on public.contacts for select to authenticated using (owner = (select auth.uid()));
create policy contacts_insert_own on public.contacts for insert to authenticated with check (owner = (select auth.uid()));
create policy contacts_update_own on public.contacts for update to authenticated using (owner = (select auth.uid())) with check (owner = (select auth.uid()));
create policy contacts_delete_own on public.contacts for delete to authenticated using (owner = (select auth.uid()));
grant select, insert, update, delete on public.contacts to authenticated;

create or replace function public.has_saved(p_owner uuid, p_viewer uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.contacts c where c.owner = p_owner and c.contact = p_viewer)
$$;
revoke all on function public.has_saved(uuid, uuid) from public, anon;
grant execute on function public.has_saved(uuid, uuid) to authenticated;

alter policy stories_select on public.stories
  using (user_id = (select auth.uid()) or (expires_at > now() and public.has_saved(user_id, (select auth.uid()))));
