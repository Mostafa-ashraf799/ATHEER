-- إصلاح "infinite recursion detected in policy for relation stories" عند نشر ستوري.
create or replace function public.active_story_count(p_uid uuid)
returns int language sql stable security definer set search_path = public as $$
  select count(*)::int from public.stories s where s.user_id = p_uid and s.expires_at > now()
$$;
revoke all on function public.active_story_count(uuid) from public, anon;
grant execute on function public.active_story_count(uuid) to authenticated;

alter policy stories_insert on public.stories
  with check (
    user_id = (select auth.uid())
    and expires_at > now()
    and expires_at <= now() + interval '30 days'
    and public.active_story_count((select auth.uid())) < 5
  );
