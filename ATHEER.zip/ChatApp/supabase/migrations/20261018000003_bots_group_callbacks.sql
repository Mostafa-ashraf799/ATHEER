alter table public.bot_callbacks add column if not exists group_id text;
update public.bots set join_groups = false where lower(username) = 'botmakerbot';
