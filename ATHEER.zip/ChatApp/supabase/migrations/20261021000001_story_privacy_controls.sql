-- تحكمات الستوري: وضع الخصوصية (contacts | selected | nobody) + إخفاء/سماح لكل شخص.
alter table public.contacts add column if not exists hide_stories boolean not null default false;
alter table public.contacts add column if not exists allow_stories boolean not null default false;

create table if not exists public.story_prefs (
  owner uuid primary key references auth.users(id) on delete cascade,
  mode text not null default 'contacts' check (mode in ('contacts','selected','nobody'))
);
alter table public.story_prefs enable row level security;
create policy story_prefs_select_own on public.story_prefs for select to authenticated using (owner = (select auth.uid()));
create policy story_prefs_insert_own on public.story_prefs for insert to authenticated with check (owner = (select auth.uid()));
create policy story_prefs_update_own on public.story_prefs for update to authenticated using (owner = (select auth.uid())) with check (owner = (select auth.uid()));
grant select, insert, update on public.story_prefs to authenticated;

create or replace function public.can_view_story(p_owner uuid, p_viewer uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.contacts c
    left join public.story_prefs sp on sp.owner = c.owner
    where c.owner = p_owner and c.contact = p_viewer
      and case coalesce(sp.mode, 'contacts')
            when 'contacts' then not c.hide_stories
            when 'selected' then c.allow_stories
            else false end
  )
$$;
revoke all on function public.can_view_story(uuid, uuid) from public, anon;
grant execute on function public.can_view_story(uuid, uuid) to authenticated;

alter policy stories_select on public.stories
  using (user_id = (select auth.uid()) or (expires_at > now() and public.can_view_story(user_id, (select auth.uid()))));
