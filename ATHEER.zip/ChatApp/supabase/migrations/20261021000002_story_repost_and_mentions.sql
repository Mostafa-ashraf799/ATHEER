-- إعادة نشر الستوري (بإذن صاحبها) + الإشارة لأشخاص/مجموعات (المجموعة بتتفرد لأعضائها في التطبيق).
alter table public.stories add column if not exists allow_repost boolean not null default false;
alter table public.stories add column if not exists repost_of bigint references public.stories(id) on delete set null;
alter table public.stories add column if not exists orig_user uuid references auth.users(id) on delete set null;

create table if not exists public.story_mentions (
  story_id bigint not null references public.stories(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  via_group text,
  primary key (story_id, user_id)
);
alter table public.story_mentions enable row level security;
grant select, insert, delete on public.story_mentions to authenticated;

create or replace function public.story_owner(p_story bigint) returns uuid
language sql stable security definer set search_path = public as $$ select user_id from public.stories where id = p_story $$;
create or replace function public.is_mentioned(p_story bigint, p_uid uuid) returns boolean
language sql stable security definer set search_path = public as $$ select exists (select 1 from public.story_mentions m where m.story_id = p_story and m.user_id = p_uid) $$;
create or replace function public.mention_count(p_story bigint) returns int
language sql stable security definer set search_path = public as $$ select count(*)::int from public.story_mentions m where m.story_id = p_story $$;
create or replace function public.can_repost_story(p_src bigint, p_viewer uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.stories s
    where s.id = p_src and s.allow_repost and s.expires_at > now()
      and s.user_id <> p_viewer
      and (public.can_view_story(s.user_id, p_viewer) or public.is_mentioned(s.id, p_viewer))
  )
$$;
revoke all on function public.story_owner(bigint), public.is_mentioned(bigint, uuid), public.mention_count(bigint), public.can_repost_story(bigint, uuid) from public, anon;
grant execute on function public.story_owner(bigint), public.is_mentioned(bigint, uuid), public.mention_count(bigint), public.can_repost_story(bigint, uuid) to authenticated;

create policy story_mentions_select on public.story_mentions for select to authenticated
  using (user_id = (select auth.uid()) or public.story_owner(story_id) = (select auth.uid()));
create policy story_mentions_insert on public.story_mentions for insert to authenticated
  with check (public.story_owner(story_id) = (select auth.uid()) and user_id <> (select auth.uid()) and public.mention_count(story_id) < 60);
create policy story_mentions_delete on public.story_mentions for delete to authenticated
  using (public.story_owner(story_id) = (select auth.uid()));

alter policy stories_select on public.stories
  using (user_id = (select auth.uid()) or (expires_at > now() and (public.can_view_story(user_id, (select auth.uid())) or public.is_mentioned(id, (select auth.uid())))));

alter policy stories_insert on public.stories
  with check (
    user_id = (select auth.uid())
    and expires_at > now() and expires_at <= now() + interval '30 days'
    and public.active_story_count((select auth.uid())) < 5
    and (repost_of is null or (public.can_repost_story(repost_of, (select auth.uid())) and orig_user = public.story_owner(repost_of)))
    and (repost_of is not null or orig_user is null)
  );
