alter table public.bot_messages add column if not exists parse_mode text;
alter table public.channel_posts add column if not exists parse_mode text;

create table if not exists public.bot_user_state (
  bot_id uuid not null references public.bots(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  state jsonb not null default '{}'::jsonb,
  primary key (bot_id, user_id)
);
alter table public.bot_user_state enable row level security;
revoke all on public.bot_user_state from anon, authenticated;
