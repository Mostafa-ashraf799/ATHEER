// Supabase Edge Function: bot-api
// بوتات ATHEER — Bot API متوافق مع تيليجرام + بوابة التطبيق + بوت Qwen المدمج.
//
// 1) للمطورين (مكتبات تيليجرام): نفس الشكل  /bot<TOKEN>/<method>
//    base URL:  https://<PROJECT>.supabase.co/functions/v1/bot-api/bot
//    مثال python-telegram-bot:  Application.builder().token(T).base_url("https://<PROJECT>.supabase.co/functions/v1/bot-api/bot").build()
// 2) للتطبيق: POST  /gateway  (JWT بتاع المستخدم) — إرسال لبوت، ضغط زر، إنشاء بوت، إضافة لقناة.
//
// مفتاح Qwen: بيتحط من جوه التطبيق بواسطة الأدمن (أمر /qwenkey في شات Qwen Bot) وبيتخزّن في جدول app_settings
// (محمي بـ RLS من غير policies = service role بس). لسه ممكن تستخدم الأسرار القديمة كـ fallback:
//   QWEN_API_KEY / QWEN_MODEL (الافتراضي qwen-plus) / QWEN_BASE_URL
// توكنات البوتات متولّدة بـ HMAC من مفتاح سيرفر في app_settings (مش متخزّنة) — /token بيرجّع نفس التوكن، و/revoke بيغيّره.
// SUPABASE_URL و SUPABASE_SERVICE_ROLE_KEY بيتحقنوا تلقائيًا من Supabase (مش في ملفات المشروع).

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const ENV_QWEN_KEY = Deno.env.get("QWEN_API_KEY") ?? "";
const ENV_QWEN_MODEL = Deno.env.get("QWEN_MODEL") ?? "qwen-plus";
const ENV_QWEN_BASE = (Deno.env.get("QWEN_BASE_URL") ?? "https://dashscope-intl.aliyuncs.com/compatible-mode/v1").replace(/\/$/, "");

const admin = createClient(SUPABASE_URL, SERVICE_KEY, { auth: { persistSession: false } });

const CH_BASE = 1_000_000_000_000; // chat_id القناة = -(CH_BASE + channel.id) زي تيليجرام
const GRP_MIN = 3_000_000_000_001; // chat_id المجموعة = -chat_num (chat_num يبدأ من هنا)
const QWEN_USER = "qwenbot", MAKER_USER = "botmakerbot";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const reply = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });

class TgError extends Error {
  constructor(public code: number, public desc: string) { super(desc); }
}
const bad = (d: string) => new TgError(400, "Bad Request: " + d);

// ------------------------------------------------------------------ أدوات

async function sha256(s: string) {
  const h = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return Array.from(new Uint8Array(h), (x) => x.toString(16).padStart(2, "0")).join("");
}
function randomSecret(len = 35) {
  const abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-";
  const a = new Uint8Array(len);
  crypto.getRandomValues(a);
  return Array.from(a, (x) => abc[x % abc.length]).join("");
}

const _sc = new Map<string, { v: string; t: number }>();
async function getSetting(k: string): Promise<string> {
  const c = _sc.get(k);
  if (c && Date.now() - c.t < 20_000) return c.v;
  const { data } = await admin.from("app_settings").select("value").eq("key", k).maybeSingle();
  const v = (data?.value as string) ?? "";
  _sc.set(k, { v, t: Date.now() });
  return v;
}
async function putSetting(k: string, v: string) {
  await admin.from("app_settings").upsert({ key: k, value: v, updated_at: new Date().toISOString() });
  _sc.set(k, { v, t: Date.now() });
}
async function isAdmin(uid: string) {
  const { data } = await admin.from("app_admins").select("user_id").eq("user_id", uid).maybeSingle();
  return !!data;
}
let _tk: string | null = null;
async function tokenKey(): Promise<string> {
  if (_tk) return _tk;
  let v = await getSetting("bot_token_key");
  if (!v) {
    await admin.from("app_settings").upsert({ key: "bot_token_key", value: randomSecret(48) }, { onConflict: "key", ignoreDuplicates: true });
    _sc.delete("bot_token_key");
    v = await getSetting("bot_token_key");
  }
  _tk = v;
  return v;
}
async function deriveToken(b: { id: string; num_id: number; token_version?: number }) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(await tokenKey()), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`${b.id}:${b.token_version ?? 0}`)));
  let bin = ""; sig.forEach((x) => (bin += String.fromCharCode(x)));
  const b64 = btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  return `${b.num_id}:${b64.slice(0, 35)}`;
}
const escH = (s: string) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const epoch = (iso?: string) => Math.floor((iso ? new Date(iso).getTime() : Date.now()) / 1000);
const chanChatId = (cid: number) => -(CH_BASE + cid);

type Bot = {
  id: string; num_id: number; owner_id: string | null; username: string; name: string; about: string;
  kind: "builtin" | "external"; token_hash: string | null; webhook_url: string | null; webhook_secret: string | null;
  commands: { command: string; description: string }[];
  description: string; avatar_url: string | null; inline_mode: boolean; inline_geo: boolean; inline_feedback: string;
  join_groups: boolean; group_privacy: boolean; token_version: number;
};
type Prof = { id: string; num_id: number; display_name: string; username: string | null };

const botUser = (b: Bot) => ({
  id: b.num_id, is_bot: true, first_name: b.name, username: b.username,
  can_join_groups: !!b.join_groups, can_read_all_group_messages: !b.group_privacy, supports_inline_queries: !!b.inline_mode,
});
const userObj = (p: Prof) => ({ id: p.num_id, is_bot: false, first_name: p.display_name || "User", ...(p.username ? { username: p.username } : {}) });
const privChat = (p: Prof) => ({ id: p.num_id, type: "private", first_name: p.display_name || "User", ...(p.username ? { username: p.username } : {}) });

async function profById(id: string): Promise<Prof | null> {
  const { data } = await admin.from("profiles").select("id,num_id,display_name,username").eq("id", id).maybeSingle();
  return data as Prof | null;
}
async function profByNum(n: number): Promise<Prof | null> {
  const { data } = await admin.from("profiles").select("id,num_id,display_name,username").eq("num_id", n).maybeSingle();
  return data as Prof | null;
}
async function channelById(id: number) {
  const { data } = await admin.from("channels").select("id,owner_id,handle,name,description").eq("id", id).maybeSingle();
  return data as { id: number; owner_id: string; handle: string; name: string; description: string } | null;
}
const chanChat = (c: { id: number; handle: string; name: string }) => ({ id: chanChatId(c.id), type: "channel", title: c.name, username: c.handle });

type Grp = { group_id: string; chat_num: number; title: string };
const grpChat = (g: Grp) => ({ id: -g.chat_num, type: "supergroup", title: g.title || "Group" });
async function groupById(gid: string): Promise<Grp | null> {
  const { data } = await admin.from("group_bot_chats").select("group_id,chat_num,title").eq("group_id", gid).maybeSingle();
  return data as Grp | null;
}
function msgFromGroup(bot: Bot | null, g: Grp, r: any, sender?: Prof | null) {
  const m: any = { message_id: r.id, date: epoch(r.created_at), chat: grpChat(g) };
  if (r.from_bot && bot) m.from = botUser(bot);
  else if (sender) m.from = userObj(sender);
  else m.from = { id: 0, is_bot: false, first_name: r.sender_name || "User" };
  if (r.text != null) m.text = r.text;
  if (r.reply_markup?.inline_keyboard) m.reply_markup = { inline_keyboard: r.reply_markup.inline_keyboard };
  if (typeof r.text === "string" && !r.from_bot && r.text.startsWith("/")) {
    const mm = r.text.match(/^\/[A-Za-z0-9_]+(@[A-Za-z0-9_]+)?/);
    if (mm) m.entities = [{ type: "bot_command", offset: 0, length: mm[0].length }];
  }
  return m;
}

// ------------------------------------------------------------------ تنظيف الأزرار (reply_markup)

function cleanMarkup(m: any): any | null {
  if (m == null || m === "") return null;
  if (typeof m === "string") { try { m = JSON.parse(m); } catch { throw bad("can't parse reply keyboard markup JSON object"); } }
  if (typeof m !== "object") throw bad("reply_markup must be an object");
  if (m.inline_keyboard) {
    if (!Array.isArray(m.inline_keyboard)) throw bad("inline_keyboard must be an array");
    let n = 0;
    const rows = m.inline_keyboard.slice(0, 12).map((row: any) => {
      if (!Array.isArray(row)) throw bad("inline keyboard row must be an array");
      return row.slice(0, 8).map((b: any) => {
        const text = String(b?.text ?? "").slice(0, 64);
        if (!text) throw bad("inline keyboard button text is empty");
        if (++n > 60) throw bad("too many buttons");
        const out: any = { text };
        if (b.callback_data != null) {
          const cd = String(b.callback_data);
          if (new TextEncoder().encode(cd).length > 64) throw bad("BUTTON_DATA_INVALID");
          out.callback_data = cd;
        } else if (b.url != null) {
          const u = String(b.url);
          if (!/^https?:\/\//i.test(u) || u.length > 512) throw bad("wrong HTTP URL");
          out.url = u;
        } else if (b.web_app?.url != null) {
          const u = String(b.web_app.url);
          if (!/^https?:\/\//i.test(u) || u.length > 512) throw bad("wrong HTTP URL");
          out.url = u; out.web_app = true;
        } else if (b.callback_game != null) {
          out.callback_data = "game"; out.game = true;
        } else throw bad("inline button must have callback_data, url or web_app");
        return out;
      });
    });
    return { inline_keyboard: rows };
  }
  if (m.keyboard) {
    if (!Array.isArray(m.keyboard)) throw bad("keyboard must be an array");
    const rows = m.keyboard.slice(0, 12).map((row: any) =>
      (Array.isArray(row) ? row : [row]).slice(0, 8).map((b: any) => ({ text: String(typeof b === "string" ? b : b?.text ?? "").slice(0, 64) }))
    );
    return { keyboard: rows, resize_keyboard: !!m.resize_keyboard, one_time_keyboard: !!m.one_time_keyboard, input_field_placeholder: m.input_field_placeholder ? String(m.input_field_placeholder).slice(0, 64) : undefined };
  }
  if (m.remove_keyboard) return { remove_keyboard: true };
  if (m.force_reply) return { force_reply: true };
  return null;
}
const parseMode = (p: any): string | null => {
  const s = String(p ?? "").toLowerCase();
  return s === "html" ? "HTML" : s === "markdown" || s === "markdownv2" ? "MarkdownV2" : null;
};

// ------------------------------------------------------------------ بناء كائنات تيليجرام

function msgFromRow(bot: Bot, user: Prof, r: any) {
  const m: any = {
    message_id: r.id, date: epoch(r.created_at), chat: privChat(user),
    from: r.from_bot ? botUser(bot) : userObj(user),
  };
  if (r.text != null) m.text = r.text;
  if (r.photo_url) m.photo = [{ file_id: r.photo_url, file_unique_id: String(r.id), width: 0, height: 0 }];
  if (r.reply_markup?.inline_keyboard) m.reply_markup = { inline_keyboard: r.reply_markup.inline_keyboard };
  if (typeof r.text === "string" && !r.from_bot && r.text.startsWith("/")) {
    const mm = r.text.match(/^\/[A-Za-z0-9_]+(@[A-Za-z0-9_]+)?/);
    if (mm) m.entities = [{ type: "bot_command", offset: 0, length: mm[0].length }];
  }
  return m;
}
function msgFromPost(bot: Bot, ch: any, r: any) {
  const m: any = { message_id: r.id, date: epoch(r.created_at), chat: chanChat(ch), sender_chat: chanChat(ch), author_signature: bot.name };
  if (r.body != null) m.text = r.body;
  if (r.reply_markup?.inline_keyboard) m.reply_markup = { inline_keyboard: r.reply_markup.inline_keyboard };
  return m;
}

// ------------------------------------------------------------------ تسليم التحديثات للبوت

function safeWebhook(u: string) {
  let url: URL;
  try { url = new URL(u); } catch { return false; }
  if (url.protocol !== "https:") return false;
  const h = url.hostname.toLowerCase();
  if (h === "localhost" || h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".localhost")) return false;
  if (/^[\d.]+$/.test(h) || h.includes(":") || h.startsWith("[")) return false; // IP literals ممنوعة
  return true;
}

async function pushUpdate(bot: Bot, update: Record<string, unknown>) {
  if (bot.kind === "builtin") { await builtinUpdate(bot, update); return; }
  if (bot.webhook_url && safeWebhook(bot.webhook_url)) {
    const body = { update_id: Date.now(), ...update };
    try {
      const ctl = new AbortController();
      const t = setTimeout(() => ctl.abort(), 8000);
      const r = await fetch(bot.webhook_url, {
        method: "POST", signal: ctl.signal,
        headers: { "Content-Type": "application/json", ...(bot.webhook_secret ? { "X-Telegram-Bot-Api-Secret-Token": bot.webhook_secret } : {}) },
        body: JSON.stringify(body),
      });
      clearTimeout(t);
      if (r.ok) return;
    } catch { /* هنخزّنه في الطابور */ }
  }
  await admin.from("bot_updates").insert({ bot_id: bot.id, payload: update });
}

// ------------------------------------------------------------------ Bot API

async function getParams(req: Request): Promise<Record<string, any>> {
  const url = new URL(req.url);
  const out: Record<string, any> = {};
  url.searchParams.forEach((v, k) => (out[k] = v));
  const ct = req.headers.get("content-type") ?? "";
  if (req.method === "POST") {
    try {
      if (ct.includes("application/json")) Object.assign(out, await req.json());
      else if (ct.includes("application/x-www-form-urlencoded")) new URLSearchParams(await req.text()).forEach((v, k) => (out[k] = v));
      else if (ct.includes("multipart/form-data")) (await req.formData()).forEach((v, k) => { if (typeof v === "string") out[k] = v; });
    } catch { /* body فاضي */ }
  }
  return out;
}

async function resolveChat(bot: Bot, chatId: any): Promise<{ user?: Prof; channel?: any; group?: Grp }> {
  const n = Number(chatId);
  if (!Number.isFinite(n) || n === 0) throw bad("chat not found");
  if (n > 0) {
    const user = await profByNum(n);
    if (!user) throw bad("chat not found");
    return { user };
  }
  if (-n >= GRP_MIN) {
    const { data: g } = await admin.from("group_bot_chats").select("group_id,chat_num,title").eq("chat_num", -n).maybeSingle();
    if (!g) throw bad("chat not found");
    const { data: gb } = await admin.from("group_bots").select("bot_id").eq("group_id", g.group_id).eq("bot_id", bot.id).maybeSingle();
    if (!gb) throw new TgError(403, "Forbidden: bot is not a member of the group chat");
    return { group: g as Grp };
  }
  const cid = -n - CH_BASE;
  if (cid <= 0) throw bad("chat not found");
  const ch = await channelById(cid);
  if (!ch) throw bad("chat not found");
  const { data } = await admin.from("channel_bots").select("bot_id").eq("channel_id", cid).eq("bot_id", bot.id).maybeSingle();
  if (!data) throw new TgError(403, "Forbidden: bot is not a member of the channel chat");
  return { channel: ch };
}

async function userStartedBot(bot: Bot, userId: string) {
  const { data } = await admin.from("bot_messages").select("id").eq("bot_id", bot.id).eq("user_id", userId).eq("from_bot", false).limit(1);
  return !!data?.length;
}

async function botMethod(bot: Bot, method: string, p: Record<string, any>): Promise<unknown> {
  const m = method.toLowerCase();
  switch (m) {
    case "getme": return { ...botUser(bot) };
    case "logout": case "close": return true;

    case "getupdates": {
      const offset = Number(p.offset ?? 0);
      const limit = Math.min(Math.max(Number(p.limit ?? 100), 1), 100);
      const timeout = Math.min(Math.max(Number(p.timeout ?? 0), 0), 25);
      if (bot.webhook_url) throw new TgError(409, "Conflict: can't use getUpdates method while webhook is active; use deleteWebhook to delete the webhook first");
      if (offset > 0) await admin.from("bot_updates").delete().eq("bot_id", bot.id).lt("update_id", offset);
      if (Math.random() < 0.05) await admin.from("bot_updates").delete().lt("created_at", new Date(Date.now() - 2 * 86400_000).toISOString());
      const t0 = Date.now();
      for (;;) {
        const { data } = await admin.from("bot_updates").select("update_id,payload").eq("bot_id", bot.id)
          .gte("update_id", offset).order("update_id").limit(limit);
        if (data?.length) return data.map((r: any) => ({ update_id: r.update_id, ...r.payload }));
        if (Date.now() - t0 >= timeout * 1000) return [];
        await new Promise((r) => setTimeout(r, 1000));
      }
    }

    case "setwebhook": {
      const url = String(p.url ?? "");
      if (!url) { await admin.from("bots").update({ webhook_url: null, webhook_secret: null }).eq("id", bot.id); return true; }
      if (!safeWebhook(url)) throw bad("bad webhook: HTTPS url must be provided for webhook");
      await admin.from("bots").update({ webhook_url: url, webhook_secret: p.secret_token ? String(p.secret_token).slice(0, 256) : null }).eq("id", bot.id);
      return true;
    }
    case "deletewebhook": await admin.from("bots").update({ webhook_url: null, webhook_secret: null }).eq("id", bot.id); return true;
    case "getwebhookinfo": {
      const { count } = await admin.from("bot_updates").select("update_id", { count: "exact", head: true }).eq("bot_id", bot.id);
      return { url: bot.webhook_url ?? "", has_custom_certificate: false, pending_update_count: count ?? 0 };
    }

    case "setmycommands": {
      let cmds = p.commands;
      if (typeof cmds === "string") { try { cmds = JSON.parse(cmds); } catch { throw bad("can't parse commands"); } }
      if (!Array.isArray(cmds) || cmds.length > 100) throw bad("commands must be an array (max 100)");
      const clean = cmds.map((c: any) => {
        const command = String(c?.command ?? "").toLowerCase();
        if (!/^[a-z0-9_]{1,32}$/.test(command)) throw bad("BOT_COMMAND_INVALID");
        return { command, description: String(c?.description ?? "").slice(0, 256) };
      });
      await admin.from("bots").update({ commands: clean }).eq("id", bot.id);
      return true;
    }
    case "getmycommands": return bot.commands ?? [];
    case "deletemycommands": await admin.from("bots").update({ commands: [] }).eq("id", bot.id); return true;
    case "setmyname": { const n = String(p.name ?? "").trim(); if (n) await admin.from("bots").update({ name: n.slice(0, 64) }).eq("id", bot.id); return true; }
    case "setmyshortdescription":
      await admin.from("bots").update({ about: String(p.short_description ?? "").slice(0, 120) }).eq("id", bot.id); return true;
    case "setmydescription":
      await admin.from("bots").update({ description: String(p.description ?? "").slice(0, 512) }).eq("id", bot.id); return true;
    case "getmydescription": return { description: bot.description ?? "" };
    case "getmyshortdescription": return { short_description: bot.about ?? "" };
    case "getmyname": return { name: bot.name };
    case "setchatmenubutton": case "setmydefaultadministratorrights": return true;
    case "getchatmenubutton": return { type: "default" };
    case "leavechat": {
      const { group } = await resolveChat(bot, p.chat_id);
      if (!group) throw bad("method is available only for groups");
      await admin.from("group_bots").delete().eq("group_id", group.group_id).eq("bot_id", bot.id);
      return true;
    }

    case "sendchataction": return true;

    case "getchat": {
      const { user, channel, group } = await resolveChat(bot, p.chat_id);
      if (user) return { ...privChat(user), accept_reactions: false };
      if (group) return grpChat(group);
      return chanChat(channel);
    }
    case "getchatmember": {
      const { channel, group } = await resolveChat(bot, p.chat_id);
      if (group) {
        if (Number(p.user_id) === bot.num_id) return { status: "member", user: botUser(bot) };
        const u = await profByNum(Number(p.user_id));
        if (u) return { status: "member", user: userObj(u) };
        throw bad("user not found");
      }
      if (channel && Number(p.user_id) === bot.num_id)
        return { status: "administrator", user: botUser(bot), can_post_messages: true, can_edit_messages: true, can_delete_messages: true };
      if (channel) {
        const owner = await profById(channel.owner_id);
        if (owner && owner.num_id === Number(p.user_id)) return { status: "creator", user: userObj(owner), is_anonymous: false };
      }
      throw bad("user not found");
    }

    case "sendgame": {
      const short = String(p.game_short_name ?? "");
      const { data: gm } = await admin.from("bot_games").select("title,description,url").eq("bot_id", bot.id).eq("short_name", short).maybeSingle();
      if (!gm) throw bad("game not found");
      return await botMethod(bot, "sendmessage", {
        chat_id: p.chat_id, text: `🎮 ${gm.title}${gm.description ? "\n" + gm.description : ""}`,
        reply_markup: { inline_keyboard: [[{ text: "🎮 العب " + gm.title, url: gm.url }]] },
      });
    }
    case "sendmessage": case "sendphoto": {
      const isPhoto = m === "sendphoto";
      let text = String(isPhoto ? p.caption ?? "" : p.text ?? "");
      const photo = isPhoto ? String(p.photo ?? "") : "";
      if (isPhoto && !/^https:\/\//i.test(photo)) throw bad("only HTTPS photo URLs are supported");
      if (!isPhoto && !text.trim()) throw bad("message text is empty");
      if (text.length > 4096) throw bad("message is too long");
      const markup = cleanMarkup(p.reply_markup);
      const pm = parseMode(p.parse_mode);
      const { user, channel, group } = await resolveChat(bot, p.chat_id);
      if (group) {
        const { data, error } = await admin.from("group_bot_messages").insert({
          group_id: group.group_id, bot_id: bot.id, from_bot: true, text: text || photo || null, parse_mode: pm,
          reply_markup: markup, reply_to: p.reply_to_message_id ? Number(p.reply_to_message_id) : null,
        }).select().single();
        if (error) throw new TgError(500, "Internal Server Error");
        return msgFromGroup(bot, group, data);
      }
      if (user) {
        if (!(await userStartedBot(bot, user.id))) throw new TgError(403, "Forbidden: bot can't initiate conversation with a user");
        const { data, error } = await admin.from("bot_messages").insert({
          bot_id: bot.id, user_id: user.id, from_bot: true, text: text || null, photo_url: photo || null,
          reply_markup: markup, reply_to: p.reply_to_message_id ? Number(p.reply_to_message_id) : null, parse_mode: pm,
        }).select().single();
        if (error) throw new TgError(500, "Internal Server Error");
        return msgFromRow(bot, user, data);
      }
      const { data, error } = await admin.from("channel_posts").insert({
        channel_id: channel.id, author_id: channel.owner_id, body: text || (photo ? photo : null), bot_id: bot.id,
        reply_markup: markup, parse_mode: pm, media_type: photo ? "image_url" : null, media_file_id: photo || null,
      }).select().single();
      if (error) throw new TgError(500, "Internal Server Error");
      return msgFromPost(bot, channel, data);
    }

    case "editmessagetext": case "editmessagecaption": case "editmessagereplymarkup": {
      const { user, channel, group } = await resolveChat(bot, p.chat_id);
      const mid = Number(p.message_id);
      if (!mid) throw bad("message_id is required (inline messages are not supported)");
      const patch: any = {};
      if (m !== "editmessagereplymarkup") {
        const t = String(p.text ?? p.caption ?? "");
        if (!t.trim()) throw bad("message text is empty");
        if (t.length > 4096) throw bad("message is too long");
        patch[channel ? "body" : "text"] = t;
        patch.parse_mode = parseMode(p.parse_mode);
      }
      if ("reply_markup" in p || m === "editmessagereplymarkup") patch.reply_markup = cleanMarkup(p.reply_markup);
      if (group) {
        const { data, error } = await admin.from("group_bot_messages").update(patch)
          .eq("id", mid).eq("bot_id", bot.id).eq("group_id", group.group_id).eq("from_bot", true).select().maybeSingle();
        if (error || !data) throw bad("message to edit not found");
        return msgFromGroup(bot, group, data);
      }
      if (user) {
        const { data, error } = await admin.from("bot_messages").update({ ...patch, edited: true })
          .eq("id", mid).eq("bot_id", bot.id).eq("user_id", user.id).eq("from_bot", true).select().maybeSingle();
        if (error || !data) throw bad("message to edit not found");
        return msgFromRow(bot, user, data);
      }
      const { data, error } = await admin.from("channel_posts").update(patch)
        .eq("id", mid).eq("bot_id", bot.id).eq("channel_id", channel.id).select().maybeSingle();
      if (error || !data) throw bad("message to edit not found");
      return msgFromPost(bot, channel, data);
    }

    case "deletemessage": {
      const { user, channel, group } = await resolveChat(bot, p.chat_id);
      const mid = Number(p.message_id);
      if (group) {
        const { data } = await admin.from("group_bot_messages").delete().eq("id", mid).eq("bot_id", bot.id).eq("group_id", group.group_id).eq("from_bot", true).select("id");
        if (!data?.length) throw bad("message to delete not found");
      } else if (user) {
        const { data } = await admin.from("bot_messages").delete().eq("id", mid).eq("bot_id", bot.id).eq("user_id", user.id).eq("from_bot", true).select("id");
        if (!data?.length) throw bad("message to delete not found");
      } else {
        const { data } = await admin.from("channel_posts").delete().eq("id", mid).eq("bot_id", bot.id).eq("channel_id", channel.id).select("id");
        if (!data?.length) throw bad("message to delete not found");
      }
      return true;
    }

    case "answercallbackquery": {
      const id = String(p.callback_query_id ?? "");
      if (!/^[0-9a-f-]{36}$/i.test(id)) throw bad("query is too old and response timeout expired or query ID is invalid");
      const { data } = await admin.from("bot_callbacks").update({
        answered: true, answer_text: p.text ? String(p.text).slice(0, 200) : null,
        answer_alert: p.show_alert === true || p.show_alert === "true",
      }).eq("id", id).eq("bot_id", bot.id).select("id");
      if (!data?.length) throw bad("query is too old and response timeout expired or query ID is invalid");
      return true;
    }
  }
  throw new TgError(404, "Not Found: method not supported by ATHEER Bot API");
}

async function handleBotApi(req: Request, token: string, method: string) {
  const [numStr] = token.split(":");
  const { data: b } = await admin.from("bots").select("*").eq("num_id", Number(numStr)).eq("kind", "external").maybeSingle();
  const bot = b as Bot | null;
  const tokOk = !!bot && ((bot.token_hash && bot.token_hash !== "derived" && bot.token_hash === (await sha256(token))) || (await deriveToken(bot)) === token);
  if (!bot || !tokOk) return reply({ ok: false, error_code: 401, description: "Unauthorized" }, 401);
  try {
    const result = await botMethod(bot, method, await getParams(req));
    return reply({ ok: true, result });
  } catch (e) {
    if (e instanceof TgError) return reply({ ok: false, error_code: e.code, description: e.desc }, e.code);
    console.error(e);
    return reply({ ok: false, error_code: 500, description: "Internal Server Error" }, 500);
  }
}

// ------------------------------------------------------------------ بوت Qwen المدمج

const BEE = "🐝";
const START_KB = {
  inline_keyboard: [
    [{ text: "🐝 اسأل Qwen", callback_data: "ask" }, { text: "📋 القائمة", callback_data: "menu" }],
    [{ text: "🎭 نمط الرد", callback_data: "style" }, { text: "ℹ️ عن البوت", callback_data: "about" }],
    [{ text: "🧹 امسح السياق", callback_data: "clear" }],
  ],
};
const MENU_KB = {
  inline_keyboard: [
    [{ text: "🐝 اسأل Qwen", callback_data: "ask" }, { text: "🎭 نمط الرد", callback_data: "style" }],
    [{ text: "🧹 امسح السياق", callback_data: "clear" }, { text: "ℹ️ عن البوت", callback_data: "about" }],
    [{ text: "◀️ رجوع", callback_data: "start" }],
  ],
};
const STYLE_KB = (cur: string) => ({
  inline_keyboard: [
    [{ text: (cur === "short" ? "✅ " : "") + "مختصر", callback_data: "style:short" }, { text: (cur === "normal" ? "✅ " : "") + "عادي", callback_data: "style:normal" }, { text: (cur === "long" ? "✅ " : "") + "مفصّل", callback_data: "style:long" }],
    [{ text: "◀️ رجوع", callback_data: "menu" }],
  ],
});
const WELCOME = `${BEE}👑 أهلاً! أنا *Qwen Bot* — ملكة النحل.\nاكتب أي سؤال وأنا أجاوبك، أو استخدم الأزرار.\n\n_ملاحظة: رسايلك هنا بتتبعت للسيرفر وخدمة الذكاء الاصطناعي علشان أرد عليك (مش مشفّرة end-to-end زي الشات العادي)._`;
const HELP = `${BEE} *الأوامر*\n/start — ابدأ\n/menu — القائمة\n/ask سؤالك — اسأل Qwen\n/clear — امسح سياق المحادثة\n/help — المساعدة`;
const ABOUT = `${BEE}👑 *Qwen Bot*\nبوت مساعد ذكي جوه ATHEER بيشتغل بنموذج Qwen. بيفتكر آخر ${10} رسايل في المحادثة (تقدر تمسحهم بـ /clear).`;

async function getState(bot: Bot, userId: string): Promise<Record<string, any>> {
  const { data } = await admin.from("bot_user_state").select("state").eq("bot_id", bot.id).eq("user_id", userId).maybeSingle();
  return (data?.state as Record<string, any>) ?? {};
}
async function setState(bot: Bot, userId: string, patch: Record<string, any>) {
  const cur = await getState(bot, userId);
  await admin.from("bot_user_state").upsert({ bot_id: bot.id, user_id: userId, state: { ...cur, ...patch } });
}
async function say(bot: Bot, userId: string, text: string, markup: any = null, pm: string | null = "MarkdownV2") {
  const { data } = await admin.from("bot_messages").insert({ bot_id: bot.id, user_id: userId, from_bot: true, text, reply_markup: markup, parse_mode: pm }).select("id").single();
  return data?.id as number;
}
async function editPriv(bot: Bot, userId: string, mid: number, text: string, markup: any) {
  await admin.from("bot_messages").update({ text, reply_markup: markup, parse_mode: "MarkdownV2", edited: true })
    .eq("id", mid).eq("bot_id", bot.id).eq("user_id", userId);
}

async function qwenAnswer(bot: Bot, userId: string, question: string, ctxless = false): Promise<string> {
  const QWEN_KEY = (await getSetting("qwen_key")) || ENV_QWEN_KEY;
  const QWEN_MODEL = (await getSetting("qwen_model")) || ENV_QWEN_MODEL;
  const QWEN_BASE = ((await getSetting("qwen_base")) || ENV_QWEN_BASE).replace(/\/$/, "");
  if (!QWEN_KEY) return `${BEE} الذكاء الاصطناعي لسه مش متفعّل. أدمن التطبيق يقدر يفعّله من الشات ده بأمر /qwenkey (المفتاح الخاص بك).`;
  const st = ctxless ? {} : await getState(bot, userId);
  const since = Number(st.ctx_from ?? 0);
  const { data: hist } = ctxless ? { data: [] as any[] } : await admin.from("bot_messages").select("id,from_bot,text").eq("bot_id", bot.id).eq("user_id", userId)
    .gt("id", since).not("text", "is", null).order("id", { ascending: false }).limit(12);
  const style = st.style === "short" ? "Answer very briefly (1-3 sentences)." : st.style === "long" ? "Answer in detail with clear structure." : "Answer clearly and concisely.";
  const msgs: any[] = [{
    role: "system",
    content: `You are Qwen Bot, a friendly helpful assistant inside the ATHEER messenger. Your persona is a wise queen bee 🐝👑 (use a bee/crown emoji occasionally, not every line). Reply in the same language and dialect as the user. ${style} Use plain text with minimal formatting (no tables, no headings).`,
  }];
  for (const h of (hist ?? []).reverse()) {
    if (!h.text || (h.from_bot && h.text.startsWith(BEE + "👑 أهلاً"))) continue;
    msgs.push({ role: h.from_bot ? "assistant" : "user", content: String(h.text).slice(0, 2000) });
  }
  // آخر رسالة المستخدم موجودة في الـ hist بالفعل؛ لو لأ نضيفها
  if (!msgs.length || msgs[msgs.length - 1].role !== "user") msgs.push({ role: "user", content: question });
  try {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 50_000);
    const r = await fetch(`${QWEN_BASE}/chat/completions`, {
      method: "POST", signal: ctl.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${QWEN_KEY}` },
      body: JSON.stringify({ model: QWEN_MODEL, messages: msgs, max_tokens: 900 }),
    });
    clearTimeout(t);
    if (!r.ok) return `${BEE} تعذّر الوصول لخدمة الذكاء الاصطناعي دلوقتي (${r.status}). جرّب كمان شوية.`;
    const j = await r.json();
    return String(j?.choices?.[0]?.message?.content ?? "").trim() || `${BEE} ما قدرتش أطلّع إجابة. جرّب صياغة تانية.`;
  } catch {
    return `${BEE} الخدمة اتأخرت. جرّب تاني.`;
  }
}

// MarkdownV2 escaping للنص الحر اللي بييجي من النموذج
const esc = (s: string) => s.replace(/([_*\[\]()~`>#+\-=|{}.!\\])/g, "\\$1");

const say0 = (bot: Bot, userId: string, t: string) => say(bot, userId, t, null, null);
async function qwenAdminCmd(bot: Bot, userId: string, cmd: string, arg: string, mid: number | null): Promise<boolean> {
  if (!["qwenkey", "qwenmodel", "qwenbase", "qwenstatus"].includes(cmd)) return false;
  if (!(await isAdmin(userId))) return false; // للغير أدمن الأمر "مش معروف"
  const del = async () => { if (mid) await admin.from("bot_messages").delete().eq("id", mid).eq("bot_id", bot.id).eq("user_id", userId); };
  if (cmd === "qwenkey") {
    await del(); // نمسح رسالة المفتاح فورًا
    if (!arg) { await say0(bot, userId, `${BEE} الاستخدام: /qwenkey المفتاح — أو /qwenkey off لإيقافه. (رسالة المفتاح بتتمسح تلقائيًا)`); return true; }
    if (arg.toLowerCase() === "off") { await putSetting("qwen_key", ""); await say0(bot, userId, `${BEE} اتمسح المفتاح. الذكاء الاصطناعي اتقفل.`); return true; }
    if (arg.length < 10 || /\s/.test(arg)) { await say0(bot, userId, `${BEE} المفتاح شكله غلط.`); return true; }
    await putSetting("qwen_key", arg);
    await say0(bot, userId, `${BEE} ✅ اتحفظ مفتاح Qwen (آخره …${arg.slice(-4)}). جرّب اسأل أي سؤال. رسالة المفتاح اتمسحت من الشات.`);
    return true;
  }
  if (cmd === "qwenmodel") {
    if (!arg) { await say0(bot, userId, `${BEE} الموديل الحالي: ${(await getSetting("qwen_model")) || ENV_QWEN_MODEL}`); return true; }
    if (!/^[A-Za-z0-9._:-]{2,64}$/.test(arg)) { await say0(bot, userId, `${BEE} اسم موديل غير صالح.`); return true; }
    await putSetting("qwen_model", arg); await say0(bot, userId, `${BEE} ✅ الموديل: ${arg}`); return true;
  }
  if (cmd === "qwenbase") {
    if (!arg) { await say0(bot, userId, `${BEE} العنوان الحالي: ${(await getSetting("qwen_base")) || ENV_QWEN_BASE}`); return true; }
    if (!/^https:\/\/[A-Za-z0-9.-]+\.[A-Za-z]{2,}(\/[\w./-]*)?$/.test(arg)) { await say0(bot, userId, `${BEE} لازم رابط https صحيح.`); return true; }
    await putSetting("qwen_base", arg.replace(/\/$/, "")); await say0(bot, userId, `${BEE} ✅ اتحدّث العنوان.`); return true;
  }
  const hasKey = !!((await getSetting("qwen_key")) || ENV_QWEN_KEY);
  await say0(bot, userId, `${BEE} الحالة: المفتاح ${hasKey ? "موجود ✅" : "مش موجود ❌"}\nالموديل: ${(await getSetting("qwen_model")) || ENV_QWEN_MODEL}`);
  return true;
}

async function builtinText(bot: Bot, userId: string, text: string, mid: number | null = null) {
  const mm = text.match(/^\/([A-Za-z0-9_]+)(?:@\w+)?\s*([\s\S]*)$/);
  if (mm) {
    const cmd = mm[1].toLowerCase(), arg = mm[2].trim();
    if (await qwenAdminCmd(bot, userId, cmd, arg, mid)) return;
    if (cmd === "start") { await say(bot, userId, WELCOME, START_KB); return; }
    if (cmd === "menu") { await say(bot, userId, `${BEE} *القائمة*`, MENU_KB); return; }
    if (cmd === "help") { await say(bot, userId, HELP); return; }
    if (cmd === "clear") { const { data } = await admin.from("bot_messages").select("id").eq("bot_id", bot.id).eq("user_id", userId).order("id", { ascending: false }).limit(1); await setState(bot, userId, { ctx_from: data?.[0]?.id ?? 0 }); await say(bot, userId, `🧹 اتمسح سياق المحادثة. ابدأ من جديد ${BEE}`); return; }
    if (cmd === "ask") { if (!arg) { await say(bot, userId, `${BEE} اكتب سؤالك بعد الأمر، مثلًا: /ask إيه هي الجاذبية؟`); return; } text = arg; }
    else { await say(bot, userId, `${BEE} الأمر ده مش معروف. جرّب /help`); return; }
  }
  const ans = await qwenAnswer(bot, userId, text);
  await say(bot, userId, esc(ans), null, "MarkdownV2");
}

async function builtinCallback(bot: Bot, cb: { id: string; data: string; messageId: number | null; channelId: number | null }, userId: string) {
  const answer = async (text?: string, alert = false) => { await admin.from("bot_callbacks").update({ answered: true, answer_text: text ?? null, answer_alert: alert }).eq("id", cb.id); };
  const d = cb.data;
  // ضغطة من قناة: نرد على المستخدم في الخاص
  if (cb.channelId) {
    await say(bot, userId, d === "ch_menu" ? `${BEE} *القائمة*` : `${BEE} أهلًا! اكتب سؤالك هنا وأنا أجاوبك.`, d === "ch_menu" ? MENU_KB : START_KB);
    await answer("بعتلك في الخاص 🐝");
    return;
  }
  const mid = cb.messageId;
  const st = await getState(bot, userId);
  if (d === "ask") { await say(bot, userId, `${BEE} اكتب سؤالك دلوقتي.`); await answer(); return; }
  if (d === "menu" && mid) { await editPriv(bot, userId, mid, `${BEE} *القائمة*`, MENU_KB); await answer(); return; }
  if (d === "start" && mid) { await editPriv(bot, userId, mid, WELCOME, START_KB); await answer(); return; }
  if (d === "about" && mid) { await editPriv(bot, userId, mid, ABOUT, { inline_keyboard: [[{ text: "◀️ رجوع", callback_data: "menu" }]] }); await answer(); return; }
  if (d === "style" && mid) { await editPriv(bot, userId, mid, `${BEE} *نمط الرد*`, STYLE_KB(st.style ?? "normal")); await answer(); return; }
  if (d.startsWith("style:") && mid) {
    const s = d.slice(6); if (["short", "normal", "long"].includes(s)) { await setState(bot, userId, { style: s }); await editPriv(bot, userId, mid, `${BEE} *نمط الرد*`, STYLE_KB(s)); await answer("تم ✅"); return; }
  }
  if (d === "clear") { const { data } = await admin.from("bot_messages").select("id").eq("bot_id", bot.id).eq("user_id", userId).order("id", { ascending: false }).limit(1); await setState(bot, userId, { ctx_from: data?.[0]?.id ?? 0 }); await answer("اتمسح السياق 🧹"); return; }
  await answer();
}

async function builtinUpdate(bot: Bot, u: Record<string, any>) {
  const isMaker = bot.username.toLowerCase() === MAKER_USER;
  const chatType = (u.message ?? u.callback_query?.message)?.chat?.type;
  if (chatType === "supergroup") { await builtinGroupUpdate(bot, u); return; }
  if (isMaker) { await makerUpdate(bot, u); return; }
  if (u.message?.text != null) {
    const user = await profByNum(u.message.from.id);
    if (user) await builtinText(bot, user.id, u.message.text, u.message.message_id ?? null);
  } else if (u.callback_query) {
    const c = u.callback_query;
    const user = await profByNum(c.from.id);
    if (user) await builtinCallback(bot, { id: c.id, data: c.data ?? "", messageId: c.message?.chat?.type === "private" ? c.message.message_id : null, channelId: c.message?.chat?.type === "channel" ? -c.message.chat.id - CH_BASE : null }, user.id);
  }
}

// ------------------------------------------------------------------ BotMaker (زي BotFather)

const KB = (rows: any[][]) => ({ inline_keyboard: rows });
const btn = (text: string, d: string) => ({ text, callback_data: d });
const sayH = (bot: Bot, uid: string, text: string, markup: any = null) => say(bot, uid, text, markup, "HTML");
async function editH(bot: Bot, uid: string, mid: number, text: string, markup: any) {
  await admin.from("bot_messages").update({ text, reply_markup: markup, parse_mode: "HTML", edited: true }).eq("id", mid).eq("bot_id", bot.id).eq("user_id", uid);
}
type Ctx = { bot: Bot; uid: string; mid: number | null };
async function out(c: Ctx, text: string, markup: any = null) {
  if (c.mid) await editH(c.bot, c.uid, c.mid, text, markup); else await sayH(c.bot, c.uid, text, markup);
}
const setMk = (c: Ctx, mk: any) => setState(c.bot, c.uid, { mk });

const MK_HELP = `<b>BotMaker 🤖</b> — بوت إدارة البوتات (زي BotFather).

<b>البوتات</b>
/newbot — إنشاء بوت جديد
/mybots — بوتاتك وإعداداتها
/token — توكن بوت
/revoke — توكن جديد (القديم يتلغي)
/deletebot — حذف بوت

<b>التعديل</b>
/setname — الاسم
/setdescription — الوصف
/setabouttext — النبذة
/setuserpic — صورة البوت (رابط https)
/setcommands — قائمة الأوامر

<b>الإعدادات</b>
/setinline — وضع inline (بيتحفظ بس)
/setinlinegeo — موقع inline (بيتحفظ بس)
/setinlinefeedback — inline feedback (بيتحفظ بس)
/setjoingroups — السماح بالانضمام للمجموعات
/setprivacy — وضع خصوصية المجموعات

<b>تطبيقات الويب</b>
/myapps /newapp /listapps /editapp /deleteapp

<b>الألعاب</b>
/mygames /newgame /listgames /editgame /deletegame

/cancel — إلغاء العملية الحالية`;

const CMD_ALIASES: Record<string, string> = {
  myapps: "appsmenu", mygames: "gamesmenu",
};
const PICK_CMDS = new Set(["token", "revoke", "setname", "setdescription", "setabouttext", "setuserpic", "setcommands", "deletebot",
  "setinline", "setinlinegeo", "setinlinefeedback", "setjoingroups", "setprivacy",
  "newapp", "listapps", "editapp", "deleteapp", "newgame", "listgames", "editgame", "deletegame", "appsmenu", "gamesmenu", "menu"]);

async function ownedBots(uid: string): Promise<Bot[]> {
  const { data } = await admin.from("bots").select("*").eq("owner_id", uid).eq("kind", "external").order("created_at");
  return (data ?? []) as Bot[];
}
async function ownedBot(uid: string, num: number): Promise<Bot | null> {
  const { data } = await admin.from("bots").select("*").eq("owner_id", uid).eq("kind", "external").eq("num_id", num).maybeSingle();
  return (data as Bot) ?? null;
}

async function createBotFor(uid: string, name: string, username: string): Promise<{ bot: Bot; token: string }> {
  name = name.trim().slice(0, 64);
  username = username.trim().replace(/^@/, "");
  if (!name) throw bad("اكتب اسم البوت");
  if (!/^[A-Za-z][A-Za-z0-9_]{2,30}[Bb][Oo][Tt]$/.test(username)) throw bad("يوزرنيم البوت لازم يخلص بـ bot (حروف إنجليزي وأرقام و _)");
  const { count } = await admin.from("bots").select("id", { count: "exact", head: true }).eq("owner_id", uid);
  if ((count ?? 0) >= 20) throw bad("وصلت للحد الأقصى (20 بوت)");
  const { data: ex } = await admin.from("bots").select("username").ilike("username", username);
  if (ex?.some((x: any) => String(x.username).toLowerCase() === username.toLowerCase())) throw bad("اليوزرنيم ده مأخوذ");
  const { data: nb, error } = await admin.from("bots").insert({ owner_id: uid, username, name, kind: "external", token_hash: "derived" }).select("*").single();
  if (error || !nb) throw new TgError(500, "تعذّر إنشاء البوت");
  return { bot: nb as Bot, token: await deriveToken(nb as Bot) };
}

function botHead(b: Bot) { return `<b>${escH(b.name)}</b> @${escH(b.username)}`; }
const backRow = (n: number) => [btn("◀️ رجوع للبوت", `m:${n}`)];

function botMenu(b: Bot) {
  const n = b.num_id;
  return {
    text: `${botHead(b)}\nإيه اللي عايز تعمله في البوت ده؟`,
    markup: KB([
      [btn("🔑 API Token", `pk:token:${n}`), btn("✏️ تعديل", `ed:${n}`)],
      [btn("⚙️ الإعدادات", `bs:${n}`), btn("🧩 Web Apps", `pk:appsmenu:${n}`)],
      [btn("🎮 الألعاب", `pk:gamesmenu:${n}`), btn("🗑 حذف البوت", `pk:deletebot:${n}`)],
      [btn("◀️ بوتاتي", "list")],
    ]),
  };
}

async function showList(c: Ctx) {
  const bots = await ownedBots(c.uid);
  if (!bots.length) { await out(c, "معندكش بوتات لسه. استخدم /newbot علشان تعمل أول بوت."); return; }
  await out(c, "اختار بوت:", KB(bots.map((b) => [btn("@" + b.username, `m:${b.num_id}`)])));
}

async function showPicker(c: Ctx, cmd: string) {
  const bots = await ownedBots(c.uid);
  if (!bots.length) { await out(c, "معندكش بوتات لسه. استخدم /newbot علشان تعمل أول بوت."); return; }
  await out(c, "اختار البوت:", KB(bots.map((b) => [btn("@" + b.username, `pk:${cmd}:${b.num_id}`)])));
}

async function itemsOf(kind: "a" | "g", botId: string) {
  const { data } = await admin.from(kind === "a" ? "bot_webapps" : "bot_games").select("*").eq("bot_id", botId).order("created_at");
  return (data ?? []) as any[];
}
const KN = (k: string) => (k === "a" ? "تطبيق ويب" : "لعبة");

async function runCmd(c: Ctx, cmd: string, num: number) {
  const b = await ownedBot(c.uid, num);
  if (!b) { await out(c, "البوت ده مش موجود أو مش بتاعك."); return; }
  const n = b.num_id;
  switch (cmd) {
    case "menu": { const m = botMenu(b); await out(c, m.text, m.markup); return; }
    case "token": {
      const tok = await deriveToken(b);
      await out(c, `${botHead(b)}\nالتوكن:\n<code>${escH(tok)}</code>\n\n⚠️ التوكن زي الباسورد — متبعتوش لحد. لو اتسرّب استخدم /revoke.`, KB([[btn("♻️ توكن جديد", `pk:revoke:${n}`)], backRow(n)]));
      return;
    }
    case "revoke": {
      await admin.from("bots").update({ token_version: (b.token_version ?? 0) + 1, token_hash: "derived", webhook_url: b.webhook_url }).eq("id", b.id);
      const tok = await deriveToken({ ...b, token_version: (b.token_version ?? 0) + 1 });
      await out(c, `${botHead(b)}\n✅ اتعمل توكن جديد والقديم بطل يشتغل:\n<code>${escH(tok)}</code>`, KB([backRow(n)]));
      return;
    }
    case "setname": await setMk(c, { step: "name", n }); await out(c, `${botHead(b)}\nابعتلي الاسم الجديد للبوت.\n(/cancel للإلغاء)`); return;
    case "setdescription": await setMk(c, { step: "desc", n }); await out(c, `${botHead(b)}\nابعتلي الوصف الجديد (لحد 512 حرف) — بيظهر لما حد يفتح البوت.\n/empty لمسحه — /cancel للإلغاء`); return;
    case "setabouttext": await setMk(c, { step: "about", n }); await out(c, `${botHead(b)}\nابعتلي النبذة القصيرة (لحد 120 حرف).\n/empty لمسحها — /cancel للإلغاء`); return;
    case "setuserpic": await setMk(c, { step: "pic", n }); await out(c, `${botHead(b)}\nابعتلي رابط https لصورة البوت (jpg/png).\n/empty لمسحها — /cancel للإلغاء`); return;
    case "setcommands":
      await setMk(c, { step: "cmds", n });
      await out(c, `${botHead(b)}\nابعتلي الأوامر، سطر لكل أمر بالشكل:\n<code>start - ابدأ\nhelp - مساعدة</code>\n/empty لمسحها — /cancel للإلغاء`);
      return;
    case "deletebot":
      await setMk(c, { step: "del", n });
      await out(c, `${botHead(b)}\n⚠️ حذف البوت نهائي (مع كل الرسايل والتطبيقات). لو متأكد ابعت بالظبط:\n<code>Yes, I am totally sure.</code>\nأو /cancel.`);
      return;
    case "setinline": case "setinlinegeo": {
      const geo = cmd === "setinlinegeo"; const cur = geo ? b.inline_geo : b.inline_mode; const k = geo ? "ig" : "im";
      await out(c, `${botHead(b)}\n${geo ? "موقع inline" : "وضع inline"}: <b>${cur ? "شغّال" : "مقفول"}</b>\n<i>ملحوظة: الإعداد بيتحفظ بس — استعلامات inline لسه مش شغّالة في ATHEER.</i>`,
        KB([[btn(cur ? "إيقاف" : "تشغيل", `st:${k}:${n}:${cur ? 0 : 1}`)], backRow(n)]));
      return;
    }
    case "setinlinefeedback": {
      const cur = b.inline_feedback || "disabled";
      await out(c, `${botHead(b)}\nInline feedback: <b>${escH(cur)}</b>\n<i>بيتحفظ بس.</i>`,
        KB([["disabled", "10%", "25%", "50%", "100%"].map((v) => btn((v === cur ? "✅ " : "") + v, `st:fb:${n}:${v}`)), backRow(n)]));
      return;
    }
    case "setjoingroups":
      await out(c, `${botHead(b)}\nالسماح بإضافة البوت للمجموعات: <b>${b.join_groups ? "مسموح" : "ممنوع"}</b>`,
        KB([[btn(b.join_groups ? "منع" : "السماح", `st:jg:${n}:${b.join_groups ? 0 : 1}`)], backRow(n)]));
      return;
    case "setprivacy":
      await out(c, `${botHead(b)}\nوضع الخصوصية في المجموعات: <b>${b.group_privacy ? "مفعّل" : "متعطّل"}</b>\n• مفعّل: البوت بيشوف الأوامر والإشارات (@) والردود عليه بس.\n• متعطّل: البوت بيشوف كل رسايل المجموعة.`,
        KB([[btn(b.group_privacy ? "تعطيل (يشوف كل حاجة)" : "تفعيل", `st:gp:${n}:${b.group_privacy ? 0 : 1}`)], backRow(n)]));
      return;
    case "appsmenu": case "gamesmenu": {
      const k = cmd === "appsmenu" ? "a" : "g"; const items = await itemsOf(k, b.id);
      const w = k === "a" ? "apps" : "games"; const W = k === "a" ? "app" : "game";
      await out(c, `${botHead(b)}\n${k === "a" ? "🧩 تطبيقات الويب" : "🎮 الألعاب"}: ${items.length}`, KB([
        [btn("➕ جديد", `pk:new${W}:${n}`), btn("📋 القائمة", `pk:list${w}:${n}`)],
        [btn("✏️ تعديل", `pk:edit${W}:${n}`), btn("🗑 حذف", `pk:delete${W}:${n}`)], backRow(n)]));
      return;
    }
    case "newapp": case "newgame": {
      const k = cmd === "newapp" ? "a" : "g";
      await setMk(c, { step: "n_title", n, k, d: {} });
      await out(c, `${botHead(b)}\n${k === "a" ? "تطبيق ويب" : "لعبة"} جديد — ابعتلي العنوان (Title).\n/cancel للإلغاء`);
      return;
    }
    case "listapps": case "listgames": {
      const k = cmd === "listapps" ? "a" : "g"; const items = await itemsOf(k, b.id);
      const body = items.length ? items.map((i, x) => `${x + 1}. <b>${escH(i.title)}</b> — <code>${escH(i.short_name)}</code>\n${escH(i.url)}`).join("\n\n") : "مفيش لسه.";
      await out(c, `${botHead(b)}\n${k === "a" ? "🧩 تطبيقات الويب" : "🎮 الألعاب"}:\n\n${body}`, KB([backRow(n)]));
      return;
    }
    case "editapp": case "editgame": case "deleteapp": case "deletegame": {
      const k = cmd.endsWith("app") ? "a" : "g"; const del = cmd.startsWith("delete"); const items = await itemsOf(k, b.id);
      if (!items.length) { await out(c, `${botHead(b)}\nمفيش حاجة تتعدّل/تتحذف.`, KB([backRow(n)])); return; }
      await out(c, `${botHead(b)}\nاختار ${KN(k)}:`, KB([...items.slice(0, 20).map((i) => [btn(i.title, `${del ? "di" : "ei"}:${k}:${i.id}`)]), backRow(n)]));
      return;
    }
  }
  await out(c, "أمر غير معروف. /help");
}

async function setBotField(c: Ctx, b: Bot, patch: Record<string, any>, okMsg: string) {
  await admin.from("bots").update(patch).eq("id", b.id);
  await setMk(c, null);
  await sayH(c.bot, c.uid, `${botHead(b)}\n✅ ${okMsg}`, KB([backRow(b.num_id)]));
}

async function makerStep(c: Ctx, mk: any, text: string): Promise<void> {
  const t = text.trim(); const empty = t === "/empty";
  if (mk.step === "nb_name") {
    if (!t || t.length > 64) { await sayH(c.bot, c.uid, "الاسم لازم يكون من 1 لـ 64 حرف. ابعته تاني."); return; }
    await setMk(c, { step: "nb_user", name: t });
    await sayH(c.bot, c.uid, `تمام. دلوقتي اختار <b>يوزرنيم</b> للبوت. لازم يخلص بـ <code>bot</code> (مثلًا <code>TetrisBot</code> أو <code>tetris_bot</code>).`);
    return;
  }
  if (mk.step === "nb_user") {
    try {
      const { bot: nb, token } = await createBotFor(c.uid, mk.name, t);
      await setMk(c, null);
      await sayH(c.bot, c.uid, `✅ تم إنشاء البوت <b>${escH(nb.name)}</b> @${escH(nb.username)}.\n\nالتوكن بتاعك:\n<code>${escH(token)}</code>\n\n⚠️ متشاركوش مع حد.\nالـ base URL للمكتبات:\n<code>${escH(SUPABASE_URL)}/functions/v1/bot-api/bot</code>\nالأوامر: /mybots لإدارة البوت، /setcommands لتحديد الأوامر.`, KB([[btn("⚙️ إدارة البوت", `m:${nb.num_id}`)]]));
    } catch (e) {
      await sayH(c.bot, c.uid, escH(e instanceof TgError ? e.desc.replace(/^Bad Request: /, "") : "حصل خطأ") + "\nجرّب يوزرنيم تاني (أو /cancel).");
    }
    return;
  }
  const b = mk.n ? await ownedBot(c.uid, mk.n) : null;
  if (!b) { await setMk(c, null); await sayH(c.bot, c.uid, "البوت مش موجود."); return; }
  switch (mk.step) {
    case "name": if (!t || t.length > 64 || t.startsWith("/")) { await sayH(c.bot, c.uid, "الاسم لازم يكون من 1 لـ 64 حرف."); return; } await setBotField(c, b, { name: t }, "اتغيّر الاسم."); return;
    case "desc": if (t.length > 512) { await sayH(c.bot, c.uid, "الوصف طويل (الحد 512)."); return; } await setBotField(c, b, { description: empty ? "" : t }, "اتحدّث الوصف."); return;
    case "about": if (t.length > 120) { await sayH(c.bot, c.uid, "النبذة طويلة (الحد 120)."); return; } await setBotField(c, b, { about: empty ? "" : t }, "اتحدّثت النبذة."); return;
    case "pic":
      if (!empty && !/^https:\/\/[^\s]{4,500}$/i.test(t)) { await sayH(c.bot, c.uid, "ابعت رابط https مباشر للصورة."); return; }
      await setBotField(c, b, { avatar_url: empty ? null : t }, "اتحدّثت الصورة."); return;
    case "cmds": {
      let clean: any[] = [];
      if (!empty) {
        for (const line of t.split(/\r?\n/).map((x) => x.trim()).filter(Boolean)) {
          const m = line.match(/^\/?([A-Za-z0-9_]{1,32})\s*(?:[-–—:]\s*)?(.*)$/);
          if (!m) { await sayH(c.bot, c.uid, `سطر غلط: <code>${escH(line)}</code>\nالشكل: <code>command - وصف</code>`); return; }
          clean.push({ command: m[1].toLowerCase(), description: m[2].slice(0, 256) });
        }
        if (clean.length > 100) { await sayH(c.bot, c.uid, "الحد 100 أمر."); return; }
      }
      await setBotField(c, b, { commands: clean }, clean.length ? `اتحفظ ${clean.length} أمر.` : "اتمسحت الأوامر."); return;
    }
    case "del":
      if (t !== "Yes, I am totally sure.") { await sayH(c.bot, c.uid, "مش متطابق — اتلغى الحذف. (ابعت /deletebot لو عايز تحاول تاني)"); await setMk(c, null); return; }
      await admin.from("bots").delete().eq("id", b.id); await setMk(c, null);
      await sayH(c.bot, c.uid, `🗑 اتحذف البوت @${escH(b.username)}.`); return;
    case "n_title": if (!t || t.length > 64) { await sayH(c.bot, c.uid, "العنوان من 1 لـ 64 حرف."); return; } await setMk(c, { ...mk, step: "n_desc", d: { title: t } }); await sayH(c.bot, c.uid, "ابعتلي الوصف (أو /empty)."); return;
    case "n_desc": if (t.length > 255) { await sayH(c.bot, c.uid, "الوصف طويل (255)."); return; } await setMk(c, { ...mk, step: "n_url", d: { ...mk.d, description: empty ? "" : t } }); await sayH(c.bot, c.uid, "ابعتلي رابط الـ " + KN(mk.k) + " (https)."); return;
    case "n_url": if (!/^https:\/\/[^\s]{4,500}$/i.test(t)) { await sayH(c.bot, c.uid, "لازم رابط https صحيح."); return; } await setMk(c, { ...mk, step: "n_short", d: { ...mk.d, url: t } }); await sayH(c.bot, c.uid, "آخر حاجة: <b>short name</b> (حروف إنجليزي وأرقام و _، من 3 لـ 32)."); return;
    case "n_short": {
      if (!/^[A-Za-z0-9_]{3,32}$/.test(t)) { await sayH(c.bot, c.uid, "short name غلط (3-32 حرف إنجليزي/رقم/_)."); return; }
      const tbl = mk.k === "a" ? "bot_webapps" : "bot_games";
      const { data: ex } = await admin.from(tbl).select("id").eq("bot_id", b.id).ilike("short_name", t.replace(/_/g, "\\_")).maybeSingle();
      if (ex) { await sayH(c.bot, c.uid, "الاسم ده مستخدم في البوت. جرّب غيره."); return; }
      const { count } = await admin.from(tbl).select("id", { count: "exact", head: true }).eq("bot_id", b.id);
      if ((count ?? 0) >= 20) { await setMk(c, null); await sayH(c.bot, c.uid, "وصلت للحد (20)."); return; }
      await admin.from(tbl).insert({ bot_id: b.id, short_name: t, ...mk.d });
      await setMk(c, null);
      await sayH(c.bot, c.uid, `✅ اتضاف ${KN(mk.k)} <b>${escH(mk.d.title)}</b>.\n${mk.k === "a" ? `ابعته بزرار <code>web_app</code> في reply_markup` : `ابعته بـ <code>sendGame</code> (game_short_name=<code>${escH(t)}</code>)`}.`, KB([backRow(b.num_id)]));
      return;
    }
    case "e_field": {
      const tbl = mk.k === "a" ? "bot_webapps" : "bot_games"; const f = mk.f as string; let v = t;
      if (f === "title" && (!t || t.length > 64)) { await sayH(c.bot, c.uid, "العنوان من 1 لـ 64 حرف."); return; }
      if (f === "description") v = empty ? "" : t.slice(0, 255);
      if (f === "url" && !/^https:\/\/[^\s]{4,500}$/i.test(t)) { await sayH(c.bot, c.uid, "لازم رابط https صحيح."); return; }
      if (f === "short_name") {
        if (!/^[A-Za-z0-9_]{3,32}$/.test(t)) { await sayH(c.bot, c.uid, "short name غلط."); return; }
        const { data: ex } = await admin.from(tbl).select("id").eq("bot_id", b.id).neq("id", mk.id).ilike("short_name", t.replace(/_/g, "\\_")).maybeSingle();
        if (ex) { await sayH(c.bot, c.uid, "الاسم ده مستخدم."); return; }
      }
      await admin.from(tbl).update({ [f]: v }).eq("id", mk.id).eq("bot_id", b.id);
      await setMk(c, null); await sayH(c.bot, c.uid, "✅ اتحدّث.", KB([backRow(b.num_id)])); return;
    }
  }
  await setMk(c, null);
}

async function makerCommand(c: Ctx, cmd: string, arg: string) {
  cmd = cmd.toLowerCase();
  if (cmd === "start" || cmd === "help") { await setMk(c, null); await sayH(c.bot, c.uid, cmd === "start" ? `أهلاً! أنا <b>BotMaker</b> 🤖 — بعمل ويدير بوتات ATHEER زي BotFather بالظبط.\n\n` + MK_HELP : MK_HELP); return; }
  if (cmd === "cancel") { await setMk(c, null); await sayH(c.bot, c.uid, "تمام، اتلغت العملية."); return; }
  if (cmd === "newbot") { await setMk(c, { step: "nb_name" }); await sayH(c.bot, c.uid, "تمام، هنعمل بوت جديد. ابعتلي <b>اسم</b> للبوت (بيظهر في المحادثات)."); return; }
  if (cmd === "mybots") { await setMk(c, null); await showList(c); return; }
  const key = CMD_ALIASES[cmd] ?? cmd;
  if (PICK_CMDS.has(key) && key !== "menu") { await setMk(c, null); await showPicker(c, key); return; }
  await sayH(c.bot, c.uid, "الأمر ده مش معروف. جرّب /help");
}

async function makerUpdate(bot: Bot, u: Record<string, any>) {
  if (u.message?.text != null) {
    const user = await profByNum(u.message.from.id);
    if (!user) return;
    const c: Ctx = { bot, uid: user.id, mid: null };
    const text: string = u.message.text;
    const mm = text.match(/^\/([A-Za-z0-9_]+)(?:@\w+)?\s*([\s\S]*)$/);
    const mk = (await getState(bot, user.id)).mk;
    if (mm && !(mk && mm[1].toLowerCase() === "empty")) { await makerCommand(c, mm[1], mm[2].trim()); return; }
    if (mk?.step) { await makerStep(c, mk, text); return; }
    await sayH(bot, user.id, "مش فاهم 🤔 اكتب /help علشان تشوف الأوامر.");
  } else if (u.callback_query) {
    const q = u.callback_query;
    const user = await profByNum(q.from.id);
    if (!user) return;
    const mid = q.message?.chat?.type === "private" ? q.message.message_id : null;
    const c: Ctx = { bot, uid: user.id, mid };
    const answer = async (t?: string) => { await admin.from("bot_callbacks").update({ answered: true, answer_text: t ?? null }).eq("id", q.id); };
    const d = String(q.data ?? ""); const p = d.split(":");
    try {
      if (d === "list") { await showList(c); }
      else if (p[0] === "m") { await setMk(c, null); await runCmd(c, "menu", Number(p[1])); }
      else if (p[0] === "pk" && PICK_CMDS.has(p[1])) { await runCmd(c, p[1], Number(p[2])); }
      else if (p[0] === "ed") {
        const b = await ownedBot(user.id, Number(p[1])); if (!b) { await answer("مش موجود"); return; }
        const n = b.num_id;
        await out(c, `${botHead(b)}\nتعديل:`, KB([[btn("الاسم", `pk:setname:${n}`), btn("الوصف", `pk:setdescription:${n}`)], [btn("النبذة", `pk:setabouttext:${n}`), btn("الصورة", `pk:setuserpic:${n}`)], [btn("الأوامر", `pk:setcommands:${n}`)], backRow(n)]));
      } else if (p[0] === "bs") {
        const b = await ownedBot(user.id, Number(p[1])); if (!b) { await answer("مش موجود"); return; }
        const n = b.num_id;
        await out(c, `${botHead(b)}\nالإعدادات:`, KB([[btn("Inline", `pk:setinline:${n}`), btn("Inline geo", `pk:setinlinegeo:${n}`)], [btn("Inline feedback", `pk:setinlinefeedback:${n}`)], [btn("السماح بالمجموعات", `pk:setjoingroups:${n}`), btn("خصوصية المجموعات", `pk:setprivacy:${n}`)], backRow(n)]));
      } else if (p[0] === "st") {
        const b = await ownedBot(user.id, Number(p[2])); if (!b) { await answer("مش موجود"); return; }
        const v = p[3];
        const map: Record<string, [string, any, string]> = {
          im: ["inline_mode", v === "1", "setinline"], ig: ["inline_geo", v === "1", "setinlinegeo"],
          jg: ["join_groups", v === "1", "setjoingroups"], gp: ["group_privacy", v === "1", "setprivacy"],
          fb: ["inline_feedback", ["disabled", "10%", "25%", "50%", "100%"].includes(v) ? v : "disabled", "setinlinefeedback"],
        };
        const e = map[p[1]]; if (!e) { await answer(); return; }
        await admin.from("bots").update({ [e[0]]: e[1] }).eq("id", b.id);
        await runCmd(c, e[2], b.num_id); await answer("تم ✅"); return;
      } else if (p[0] === "ei" || p[0] === "di" || p[0] === "dy") {
        const k = p[1] === "g" ? "g" : "a"; const tbl = k === "a" ? "bot_webapps" : "bot_games";
        const { data: it } = await admin.from(tbl).select("*").eq("id", p[2]).maybeSingle();
        const b = it ? await botByIdFull(it.bot_id).catch(() => null) : null;
        if (!it || !b || b.owner_id !== user.id) { await answer("مش موجود"); return; }
        if (p[0] === "ei") {
          await out(c, `${botHead(b)}\n<b>${escH(it.title)}</b> — تعدّل إيه؟`, KB([[btn("العنوان", `ef:${k}:${it.id}:title`), btn("الوصف", `ef:${k}:${it.id}:description`)], [btn("الرابط", `ef:${k}:${it.id}:url`), btn("Short name", `ef:${k}:${it.id}:short_name`)], backRow(b.num_id)]));
        } else if (p[0] === "di") {
          await out(c, `${botHead(b)}\nتحذف <b>${escH(it.title)}</b>؟`, KB([[btn("🗑 أيوه احذف", `dy:${k}:${it.id}`), btn("إلغاء", `m:${b.num_id}`)]]));
        } else {
          await admin.from(tbl).delete().eq("id", it.id); await out(c, `🗑 اتحذف.`, KB([backRow(b.num_id)]));
        }
      } else if (p[0] === "ef") {
        const k = p[1] === "g" ? "g" : "a"; const tbl = k === "a" ? "bot_webapps" : "bot_games"; const f = p[3];
        if (!["title", "description", "url", "short_name"].includes(f)) { await answer(); return; }
        const { data: it } = await admin.from(tbl).select("*").eq("id", p[2]).maybeSingle();
        const b = it ? await botByIdFull(it.bot_id).catch(() => null) : null;
        if (!it || !b || b.owner_id !== user.id) { await answer("مش موجود"); return; }
        await setMk(c, { step: "e_field", n: b.num_id, k, id: it.id, f });
        await out(c, `${botHead(b)}\nابعتلي القيمة الجديدة لـ <b>${escH(f)}</b>${f === "description" ? " (أو /empty)" : ""}. /cancel للإلغاء`);
      }
      await answer();
    } catch (e) {
      console.error(e); await answer("حصل خطأ");
    }
  }
}

// ------------------------------------------------------------------ Qwen داخل المجموعات

async function builtinGroupUpdate(bot: Bot, u: Record<string, any>) {
  const chatId = (u.message ?? u.callback_query?.message)?.chat?.id as number;
  const g = await admin.from("group_bot_chats").select("group_id,chat_num,title").eq("chat_num", -chatId).maybeSingle().then((r: any) => r.data as Grp | null);
  if (!g) return;
  const post = async (text: string, replyTo: number | null, markup: any = null) =>
    await admin.from("group_bot_messages").insert({ group_id: g.group_id, bot_id: bot.id, from_bot: true, text, parse_mode: "MarkdownV2", reply_markup: markup, reply_to: replyTo });
  if (u.callback_query) {
    await admin.from("bot_callbacks").update({ answered: true, answer_text: "اكتب سؤالك في الجروب بـ /ask@" + bot.username }).eq("id", u.callback_query.id);
    return;
  }
  const msg = u.message; let text = String(msg.text ?? "").trim();
  const uname = bot.username;
  const cm = text.match(/^\/([A-Za-z0-9_]+)(?:@\w+)?\s*([\s\S]*)$/);
  if (cm) {
    const cmd = cm[1].toLowerCase(), arg = cm[2].trim();
    if (cmd === "start" || cmd === "help") { await post(`${BEE}👑 أنا *Qwen Bot*\\. اسألني بـ /ask@${esc(uname)} سؤالك، أو اعمللي @ منشن، أو رد على رسالتي\\.`, msg.message_id); return; }
    if (cmd === "ask") { if (!arg) { await post(`${BEE} اكتب سؤالك بعد الأمر\\.`, msg.message_id); return; } text = arg; }
    else return;
  } else {
    text = text.replace(new RegExp("@" + uname, "ig"), "").trim();
    if (!text) return;
  }
  const ans = await qwenAnswer(bot, "", text, true);
  await post(esc(ans), msg.message_id);
}

// ------------------------------------------------------------------ بوابة التطبيق

const bg = (p: Promise<unknown>) => {
  const er = (globalThis as any).EdgeRuntime;
  const q = p.catch((e) => console.error(e));
  if (er?.waitUntil) er.waitUntil(q);
  return q;
};
function qualifies(bot: Bot, text: string, replyBotId: string | null): boolean {
  const uname = bot.username.toLowerCase();
  const t = text.trim();
  const cm = t.match(/^\/[A-Za-z0-9_]+(?:@([A-Za-z0-9_]+))?/);
  if (cm) return !cm[1] || cm[1].toLowerCase() === uname || !bot.group_privacy;
  if (!bot.group_privacy) return true;
  if (replyBotId === bot.id) return true;
  return t.toLowerCase().includes("@" + uname);
}
async function authUser(req: Request): Promise<string> {
  const jwt = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
  if (!jwt) throw new TgError(401, "Unauthorized");
  const { data, error } = await admin.auth.getUser(jwt);
  if (error || !data.user) throw new TgError(401, "Unauthorized");
  return data.user.id;
}
async function botByIdFull(id: string): Promise<Bot> {
  const { data } = await admin.from("bots").select("*").eq("id", id).maybeSingle();
  if (!data) throw bad("bot not found");
  return data as Bot;
}

async function gateway(req: Request) {
  const uid = await authUser(req);
  const body = await req.json().catch(() => ({}));
  const action = String(body.action ?? "");
  const me = await profById(uid);
  if (!me) throw new TgError(403, "profile required");

  switch (action) {
    case "send": {
      const bot = await botByIdFull(String(body.bot_id));
      const text = String(body.text ?? "").trim();
      if (!text) throw bad("empty");
      if (text.length > 4096) throw bad("message too long");
      const since = new Date(Date.now() - 10_000).toISOString();
      const { count } = await admin.from("bot_messages").select("id", { count: "exact", head: true }).eq("user_id", uid).eq("from_bot", false).gte("created_at", since);
      if ((count ?? 0) >= 8) throw new TgError(429, "Too Many Requests: slow down");
      const { data: row, error } = await admin.from("bot_messages").insert({ bot_id: bot.id, user_id: uid, from_bot: false, text, reply_to: body.reply_to ? Number(body.reply_to) : null }).select().single();
      if (error) throw new TgError(500, "insert failed");
      const upd = pushUpdate(bot, { message: msgFromRow(bot, me, row) });
      if (bot.kind === "builtin") await bg(upd); else await upd;
      return { ok: true, id: row.id };
    }

    case "press": {
      const bot = await botByIdFull(String(body.bot_id));
      const data = String(body.data ?? "");
      const channelId = body.channel_id ? Number(body.channel_id) : null;
      const mid = Number(body.message_id);
      let msg: any, markup: any;
      if (channelId) {
        const { data: r } = await admin.from("channel_posts").select("*").eq("id", mid).eq("channel_id", channelId).eq("bot_id", bot.id).maybeSingle();
        if (!r) throw bad("message not found");
        const ch = await channelById(channelId);
        if (!ch) throw bad("channel not found");
        markup = r.reply_markup; msg = msgFromPost(bot, ch, r);
      } else {
        const { data: r } = await admin.from("bot_messages").select("*").eq("id", mid).eq("bot_id", bot.id).eq("user_id", uid).eq("from_bot", true).maybeSingle();
        if (!r) throw bad("message not found");
        markup = r.reply_markup; msg = msgFromRow(bot, me, r);
      }
      // لازم الزرار يكون فعلًا موجود في الرسالة (منع تزوير callback_data)
      const ok = (markup?.inline_keyboard ?? []).some((row: any[]) => row.some((b) => b.callback_data === data));
      if (!ok) throw bad("button not found");
      const { data: cbRow } = await admin.from("bot_callbacks").insert({ bot_id: bot.id, user_id: uid, message_id: mid, channel_id: channelId, data }).select("id").single();
      await pushUpdate(bot, { callback_query: { id: cbRow!.id, from: userObj(me), message: msg, chat_instance: String(channelId ? chanChatId(channelId) : me.num_id), data } });
      return { ok: true, callback_id: cbRow!.id };
    }

    case "create_bot": {
      const { bot: nb, token } = await createBotFor(uid, String(body.name ?? ""), String(body.username ?? ""));
      return { ok: true, bot_id: nb.id, token, username: nb.username, name: nb.name };
    }
    case "get_token": {
      const bot = await botByIdFull(String(body.bot_id));
      if (bot.owner_id !== uid) throw new TgError(403, "Forbidden");
      return { ok: true, token: await deriveToken(bot) };
    }
    case "rotate_token": {
      const bot = await botByIdFull(String(body.bot_id));
      if (bot.owner_id !== uid) throw new TgError(403, "Forbidden");
      const v = (bot.token_version ?? 0) + 1;
      await admin.from("bots").update({ token_version: v, token_hash: "derived" }).eq("id", bot.id);
      return { ok: true, token: await deriveToken({ ...bot, token_version: v }) };
    }
    case "delete_bot": {
      const bot = await botByIdFull(String(body.bot_id));
      if (bot.owner_id !== uid) throw new TgError(403, "Forbidden");
      await admin.from("bots").delete().eq("id", bot.id);
      return { ok: true };
    }
    case "my_bots": {
      const { data } = await admin.from("bots").select("id,num_id,owner_id,username,name,about,description,avatar_url,kind,commands,webhook_url,join_groups,group_privacy").eq("owner_id", uid).order("created_at");
      return { ok: true, bots: (data ?? []).map((b: any) => ({ ...b, webhook_url: undefined, webhook: !!b.webhook_url })) };
    }

    case "add_to_channel": case "remove_from_channel": {
      const bot = await botByIdFull(String(body.bot_id));
      const ch = await channelById(Number(body.channel_id));
      if (!ch || ch.owner_id !== uid) throw new TgError(403, "بس صاحب القناة يقدر يضيف بوت");
      if (action === "remove_from_channel") {
        await admin.from("channel_bots").delete().eq("channel_id", ch.id).eq("bot_id", bot.id);
        return { ok: true };
      }
      // بوت صاحبه شخص تاني مينفعش يتضاف إلا بإذنه: البوت العام (المدمج) أو بوتاتك إنت
      if (!bot.join_groups) throw new TgError(403, "البوت ده مش بيسمح بإضافته للقنوات/المجموعات");
      const { error } = await admin.from("channel_bots").insert({ channel_id: ch.id, bot_id: bot.id, added_by: uid });
      if (error && !String(error.message).includes("duplicate")) throw new TgError(500, "تعذّرت الإضافة");
      if (bot.kind === "builtin") {
        await admin.from("channel_posts").insert({
          channel_id: ch.id, author_id: ch.owner_id, bot_id: bot.id, parse_mode: "MarkdownV2",
          body: `${BEE}👑 *Qwen Bot* اتضاف للقناة\\. دوس على الزرار وهبعتلك في الخاص\\.`,
          reply_markup: { inline_keyboard: [[{ text: "🐝 اسأل Qwen", callback_data: "ch_ask" }, { text: "📋 القائمة", callback_data: "ch_menu" }]] },
        });
      } else {
        await pushUpdate(bot, { my_chat_member: { chat: chanChat(ch), from: userObj(me), date: epoch(), old_chat_member: { user: botUser(bot), status: "left" }, new_chat_member: { user: botUser(bot), status: "administrator", can_post_messages: true, can_edit_messages: true, can_delete_messages: true, is_anonymous: false } } });
      }
      return { ok: true, chat_id: chanChatId(ch.id) };
    }

    case "group_add_bot": {
      const bot = await botByIdFull(String(body.bot_id));
      const gid = String(body.group_id ?? "");
      if (!gid || gid.length > 80) throw bad("group_id");
      if (!bot.join_groups) throw new TgError(403, "البوت ده مش بيسمح بإضافته للمجموعات");
      const title = String(body.title ?? "").slice(0, 100);
      let g = await groupById(gid);
      if (!g) {
        await admin.from("group_bot_chats").insert({ group_id: gid, title });
        g = await groupById(gid);
      } else if (title && title !== g.title) await admin.from("group_bot_chats").update({ title }).eq("group_id", gid);
      if (!g) throw new TgError(500, "failed");
      const { count } = await admin.from("group_bots").select("bot_id", { count: "exact", head: true }).eq("group_id", gid);
      if ((count ?? 0) >= 20) throw bad("max 20 bots per group");
      const { error } = await admin.from("group_bots").insert({ group_id: gid, bot_id: bot.id, added_by: uid });
      if (error && !String(error.message).includes("duplicate")) throw new TgError(500, "تعذّرت الإضافة");
      if (!error) {
        if (bot.kind === "builtin") {
          await admin.from("group_bot_messages").insert({ group_id: gid, bot_id: bot.id, from_bot: true, parse_mode: "MarkdownV2",
            text: `${BEE}👑 *Qwen Bot* اتضاف للمجموعة\\. اسألني بـ /ask@${esc(bot.username)} سؤالك، أو اعمللي منشن، أو رد على رسالتي\\.` });
        } else {
          await bg(pushUpdate(bot, { my_chat_member: { chat: grpChat(g), from: userObj(me), date: epoch(), old_chat_member: { user: botUser(bot), status: "left" }, new_chat_member: { user: botUser(bot), status: "member" } } }));
        }
      }
      return { ok: true, chat_id: -g.chat_num };
    }
    case "group_remove_bot": {
      const gid = String(body.group_id ?? ""); const botId = String(body.bot_id ?? "");
      const { data: gb } = await admin.from("group_bots").select("added_by,bot_id").eq("group_id", gid).eq("bot_id", botId).maybeSingle();
      if (!gb) return { ok: true };
      const bot = await botByIdFull(botId);
      if (gb.added_by !== uid && bot.owner_id !== uid) throw new TgError(403, "اللي ضاف البوت أو صاحبه بس يشيله");
      await admin.from("group_bots").delete().eq("group_id", gid).eq("bot_id", botId);
      return { ok: true };
    }
    case "group_bots": {
      const gid = String(body.group_id ?? "");
      const { data } = await admin.from("group_bots").select("bot_id,added_by,bots(id,num_id,username,name,avatar_url,kind,commands,group_privacy,description,about)").eq("group_id", gid);
      return { ok: true, bots: (data ?? []).map((r: any) => ({ ...r.bots, added_by_me: r.added_by === uid })).filter((b: any) => b.id) };
    }
    case "group_send": {
      const gid = String(body.group_id ?? "");
      const text = String(body.text ?? "").trim();
      if (!text || text.length > 4096) throw bad("text");
      const g = await groupById(gid);
      if (!g) return { ok: true, delivered: 0 };
      const { data: gbs } = await admin.from("group_bots").select("bots(*)").eq("group_id", gid);
      const bots = (gbs ?? []).map((r: any) => r.bots as Bot).filter(Boolean);
      const replyBot = body.reply_bot_id ? String(body.reply_bot_id) : null;
      const targets = bots.filter((b) => qualifies(b, text, replyBot));
      if (!targets.length) return { ok: true, delivered: 0 };
      const since = new Date(Date.now() - 10_000).toISOString();
      const { count } = await admin.from("group_bot_messages").select("id", { count: "exact", head: true }).eq("sender_id", uid).gte("created_at", since);
      if ((count ?? 0) >= 8) throw new TgError(429, "Too Many Requests: slow down");
      const { data: row, error } = await admin.from("group_bot_messages").insert({
        group_id: gid, from_bot: false, sender_id: uid, sender_name: me.display_name, text, reply_to: body.reply_to ? Number(body.reply_to) : null,
      }).select().single();
      if (error) throw new TgError(500, "insert failed");
      const m = msgFromGroup(null, g, row, me);
      await Promise.all(targets.map((b) => bg(pushUpdate(b, { message: m }))));
      return { ok: true, delivered: targets.length, id: row.id };
    }
    case "group_fetch": {
      const gid = String(body.group_id ?? "");
      const { data } = await admin.from("group_bot_messages").select("id,bot_id,text,parse_mode,reply_markup,reply_to,created_at").eq("group_id", gid).eq("from_bot", true).order("id", { ascending: false }).limit(40);
      return { ok: true, messages: (data ?? []).reverse() };
    }
    case "group_press": {
      const gid = String(body.group_id ?? ""); const mid = Number(body.message_id); const data = String(body.data ?? "");
      const g = await groupById(gid); if (!g) throw bad("group not found");
      const { data: r } = await admin.from("group_bot_messages").select("*").eq("id", mid).eq("group_id", gid).eq("from_bot", true).maybeSingle();
      if (!r || !r.bot_id) throw bad("message not found");
      const bot = await botByIdFull(r.bot_id);
      const ok = (r.reply_markup?.inline_keyboard ?? []).some((row: any[]) => row.some((b) => b.callback_data === data));
      if (!ok) throw bad("button not found");
      const { data: cbRow } = await admin.from("bot_callbacks").insert({ bot_id: bot.id, user_id: uid, message_id: mid, group_id: gid, data }).select("id").single();
      await bg(pushUpdate(bot, { callback_query: { id: cbRow!.id, from: userObj(me), message: msgFromGroup(bot, g, r), chat_instance: String(-g.chat_num), data } }));
      return { ok: true, callback_id: cbRow!.id };
    }

    case "clear_chat": {
      const bot = await botByIdFull(String(body.bot_id));
      await admin.from("bot_messages").delete().eq("bot_id", bot.id).eq("user_id", uid);
      return { ok: true };
    }
  }
  throw bad("unknown action");
}

// ------------------------------------------------------------------ الدخول

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const path = new URL(req.url).pathname;
  try {
    if (path.endsWith("/gateway")) return reply(await gateway(req));
    const m = path.match(/\/bot(\d+:[A-Za-z0-9_-]+)\/([A-Za-z]+)\/?$/);
    if (m) return await handleBotApi(req, m[1], m[2]);
    return reply({ ok: true, service: "ATHEER Bot API", docs: "base URL: <this-url>/bot<TOKEN>/<method>" });
  } catch (e) {
    if (e instanceof TgError) return reply({ ok: false, error_code: e.code, description: e.desc }, e.code);
    console.error(e);
    return reply({ ok: false, error_code: 500, description: "Internal Server Error" }, 500);
  }
});
